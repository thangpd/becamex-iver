<?php

define('IVER_HOTEL_VERSION', '1.0.3');
define('IVER_HOTEL_ABS_PATH', dirname(__FILE__));
define('IVER_HOTEL_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('IVER_HOTEL_URL_PATH', plugin_dir_url( __FILE__ ));
define('IVER_HOTEL_CPT_PATH', IVER_HOTEL_ABS_PATH.'/post-types');
define('IVER_HOTEL_SHORTCODES_PATH', IVER_HOTEL_ABS_PATH.'/modules/shortcodes');
define('IVER_HOTEL_ASSETS_URL_PATH', IVER_HOTEL_URL_PATH.'/assets');
define('IVER_HOTEL_MODULE_PATH', IVER_HOTEL_ABS_PATH.'/modules');
define('IVER_HOTEL_CPT_URL_PATH', IVER_HOTEL_URL_PATH.'post-types');