<?php

include_once 'const.php';

//load post-types additional
require_once 'post-types/load.php';

//load lib
include_once 'lib/helpers-functions.php';
require_once 'lib/shortcode-interface.php';
require_once 'lib/shortcode-loader.php';
require_once 'lib/shortcode-functions.php';


//load post-post-types
require_once 'lib/post-type-interface.php';
require_once 'post-types/post-types-functions.php';
require_once 'post-types/post-types-register.php'; //this has to be loaded last


//load admin
if(!function_exists('iver_hotel_load_admin')) {
    function iver_hotel_load_admin() {
        require_once 'admin/options/map.php';
    }
    add_action('iver_select_before_options_map', 'iver_hotel_load_admin');
}

//load custom styles
if(!function_exists('iver_hotel_load_custom_styles')) {
    function iver_hotel_load_custom_styles() {
        require_once 'assets/custom-styles/hotel.php';
    }
    add_action('after_setup_theme','iver_hotel_load_custom_styles');
}