<?php

if(iver_hotel_theme_installed()) {
	if(!function_exists('iver_hotel_options_map')) {

		function iver_hotel_options_map() {


			iver_select_add_admin_page(array(
				'title' => esc_html__('Hotel', 'iver-hotel'),
				'slug'  => '_hotel',
				'icon'  => 'fa fa-building-o'
			));

			// added options in post meta

			do_action('iver_hotel_room_action_single_fields');
		}


		add_action('iver_select_options_map', 'iver_hotel_options_map', 75); //one after elements
	}
}