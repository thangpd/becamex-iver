<?php

if(!function_exists('iver_hotel_activation')) {
	/**
	 * Triggers when plugin is activated. It calls flush_rewrite_rules
	 * and defines iver_hotel_on_activate action
	 */
	function iver_hotel_activation() {
		do_action('iver_hotel_on_activate');

		// IverHotel\PostTypesRegister::getInstance()->register();
		flush_rewrite_rules();
	}

	register_activation_hook(__FILE__, 'iver_hotel_activation');
}

if(!function_exists('iver_hotel_text_domain')) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function iver_hotel_text_domain() {
		load_plugin_textdomain('iver-hotel', false, IVER_HOTEL_REL_PATH.'/languages');
	}

	add_action('plugins_loaded', 'iver_hotel_text_domain');
}

if(!function_exists('iver_hotel_version_class')) {
    /**
     * Adds plugins version class to body
     * @param $classes
     * @return array
     */
    function iver_hotel_version_class($classes) {
        $classes[] = 'qodef-hotel-'.IVER_HOTEL_VERSION;

        return $classes;
    }

    add_filter('body_class', 'iver_hotel_version_class');
}

if(!function_exists('iver_hotel_single_boxed_class')) {
    /**
     * Adds plugins version class to body
     * @param $classes
     * @return array
     */
    function iver_hotel_single_boxed_class($classes) {
        $id = iver_select_get_page_id();

        $boxed_layout = iver_select_get_meta_field_intersect( 'hotel_room_boxed_single_item', $id );

        if($boxed_layout == 'yes') {
            $classes[] = 'qodef-hotel-single-item-boxed';
        }

        return $classes;
    }

    add_filter('body_class', 'iver_hotel_single_boxed_class');
}

if(!function_exists('iver_hotel_theme_installed')) {
    /**
     * Checks whether theme is installed or not
     * @return bool
     */
    function iver_hotel_theme_installed() {
        return defined('SELECT_ROOT');
    }
}

if(!function_exists('iver_hotel_is_wpml_installed')) {
	/**
	 * Function that checks if WPML plugin is installed
	 * @return bool
	 *
	 * @version 0.1
	 */
	function iver_hotel_is_wpml_installed() {
		return defined('ICL_SITEPRESS_VERSION');
	}
}

if ( ! function_exists( 'iver_hotel_woocommerce_integration_installed' ) ) {
	//is Iver Woocommerce Integration?
	function iver_hotel_woocommerce_integration_installed() {
		return defined( 'IVER_CHECKOUT_INTEGRATION' );
	}
}

if ( ! function_exists( 'iver_hotel_iver_membership_installed' ) ) {
	/**
	 * Function that checks if Iver Membership plugin installed
	 * @return bool
	 */
	function iver_hotel_iver_membership_installed() {
		return defined( 'IVER_MEMBERSHIP_VERSION' );
	}
}

if(!function_exists('iver_hotel_get_shortcode_module_template_part')) {
	/**
	 * Loads module template part.
	 *
	 * @param string $post_type name of the post type
	 * @param string $shortcode name of the shortcode folder
	 * @param string $template name of the template to load
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 * @param array $additional_params array of additional parameters to pass to template
	 *
	 * @return html
	 */
	function iver_hotel_get_shortcode_module_template_part($post_type, $shortcode,$template, $slug = '', $params = array(), $additional_params = array()) {

		//HTML Content from template
		$html = '';
		$template_path = IVER_HOTEL_CPT_PATH.'/'.$post_type.'/shortcodes/'.$shortcode.'/'.'templates';

		$temp = $template_path.'/'.$template;
		if(is_array($params) && count($params)) {
			extract($params);
		}

		if(is_array($additional_params) && count($additional_params)) {
			extract($additional_params);
		}

		$template = '';

		if (!empty($temp)) {
			if (!empty($slug)) {
				$template = "{$temp}-{$slug}.php";

				if(!file_exists($template)) {
					$template = $temp.'.php';
				}
			} else {
				$template = $temp.'.php';
			}
		}

		if ($template) {
			ob_start();
			include($template);
			$html = ob_get_clean();
		}

		return $html;
	}
}

if(!function_exists('iver_hotel_get_template_part')) {
	/**
	 * Loads template part with parameters. If file with slug parameter added exists it will load that file, else it will load file without slug added.
	 * Child theme friendly function
	 *
	 * @param string $template name of the template to load without extension
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 * @param bool $return whether to return it as a string
	 *
	 * @return mixed
	 */
	function iver_hotel_get_template_part($template, $slug = '', $params = array(), $return = false) {
		//HTML Content from template
		$html = '';
		$template_path = IVER_HOTEL_MODULE_PATH;

		$temp = $template_path.'/'.$template;
		if(is_array($params) && count($params)) {
			extract($params);
		}

		$template = '';

		if($temp !== '') {

			if($slug !== '') {
				$template = "{$temp}-{$slug}.php";

				if ( ! file_exists( $template ) ) {
					$template = $temp . '.php';
				}
			} else {
				$template = $temp . '.php';
			}
		}

		if($template) {
			if($return) {
				ob_start();
			}

			include($template);

			if($return) {
				$html = ob_get_clean();
			}

		}

		if($return) {
			return $html;
		}
	}
}


if(!function_exists('iver_hotel_get_cpt_single_module_template_part')) {
	/**
	 * Loads module template part.
	 *
	 * @param string $cpt_name name of the cpt folder
	 * @param string $template name of the template to load
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 *
	 * @return html
	 */
	function iver_hotel_get_cpt_single_module_template_part($template, $cpt_name, $slug = '', $params = array()) {

		//HTML Content from template
		$html = '';
		$template_path = IVER_HOTEL_CPT_PATH.'/'.$cpt_name;

		$temp = $template_path.'/'.$template;

		if(is_array($params) && count($params)) {
			extract($params);
		}

		$template = '';

		if (!empty($temp)) {
			if (!empty($slug)) {
				$template = "{$temp}-{$slug}.php";

				if(!file_exists($template)) {
					$template = $temp.'.php';
				}
			} else {
				$template = $temp.'.php';
			}
		}

		if (!empty($template)) {
			ob_start();
			include($template);
			$html = ob_get_clean();
		}

		print iver_select_get_module_part( $html );
	}
}

if(!function_exists('iver_hotel_return_cpt_single_module_template_part')) {
    /**
     * Loads module template part.
     *
     * @param string $cpt_name name of the cpt folder
     * @param string $template name of the template to load
     * @param string $slug
     * @param array $params array of parameters to pass to template
     *
     * @return string
     */
    function iver_hotel_return_cpt_single_module_template_part($template, $cpt_name, $slug = '', $params = array()) {

        //HTML Content from template
        $html = '';
        $template_path = IVER_HOTEL_CPT_PATH.'/'.$cpt_name;

        $temp = $template_path.'/'.$template;

        if(is_array($params) && count($params)) {
            extract($params);
        }

        $template = '';

        if (!empty($temp)) {
            if (!empty($slug)) {
                $template = "{$temp}-{$slug}.php";

                if(!file_exists($template)) {
                    $template = $temp.'.php';
                }
            } else {
                $template = $temp.'.php';
            }
        }

        if (!empty($template)) {
            ob_start();
            include($template);
            $html = ob_get_clean();
        }

        return $html;
    }
}


/**
 * Get hotel room county taxonomy values
 * return value is array in provided format.
 *
 * @param $taxonomy string - queried taxonomy
 * @param $first_empty boolean - if is true, first element in key_value return array will be empty
 * @param $return_type string - format of returned array (can be key_value, object)
 *
 * @return array
 */
if ( ! function_exists( 'iver_hotel_get_taxonomy_list' ) ) {
	function iver_hotel_get_taxonomy_list($taxonomy = '', $first_empty = false, $return_type = 'key_value') {
		$hotel_room_taxonomy_array = array();
		$hotel_room_taxonomy_array['key_value'] = array();
		$hotel_room_taxonomy_array['obj'] = array();

		if($taxonomy !== '') {

			$args = array(
				'taxonomy' => $taxonomy,
				'hide_empty' => false
			);

			$hotel_room_axonomies = get_terms($args);

			if (is_array($hotel_room_axonomies) && count($hotel_room_axonomies)) {
				if ($first_empty) {
					$hotel_room_taxonomy_array['key_value'][''] = '';
				}
				foreach ($hotel_room_axonomies as $hotel_room_axonomy) {

					$hotel_room_taxonomy_array['key_value'][$hotel_room_axonomy->term_id] = $hotel_room_axonomy->name;
					$hotel_room_taxonomy_array['obj'][] = $hotel_room_axonomy;

				}

			}
		}

		return $hotel_room_taxonomy_array[$return_type];
	}
}

if ( ! function_exists( 'iver_hotel_get_countries_list' ) ) {
	function iver_hotel_get_countries_list() {

		$countries = array(
			'AF' => esc_html__( 'Afghanistan', 'iver-hotel' ),
			'AX' => esc_html__( '&#197;land Islands', 'iver-hotel' ),
			'AL' => esc_html__( 'Albania', 'iver-hotel' ),
			'DZ' => esc_html__( 'Algeria', 'iver-hotel' ),
			'AS' => esc_html__( 'American Samoa', 'iver-hotel' ),
			'AD' => esc_html__( 'Andorra', 'iver-hotel' ),
			'AO' => esc_html__( 'Angola', 'iver-hotel' ),
			'AI' => esc_html__( 'Anguilla', 'iver-hotel' ),
			'AQ' => esc_html__( 'Antarctica', 'iver-hotel' ),
			'AG' => esc_html__( 'Antigua and Barbuda', 'iver-hotel' ),
			'AR' => esc_html__( 'Argentina', 'iver-hotel' ),
			'AM' => esc_html__( 'Armenia', 'iver-hotel' ),
			'AW' => esc_html__( 'Aruba', 'iver-hotel' ),
			'AU' => esc_html__( 'Australia', 'iver-hotel' ),
			'AT' => esc_html__( 'Austria', 'iver-hotel' ),
			'AZ' => esc_html__( 'Azerbaijan', 'iver-hotel' ),
			'BS' => esc_html__( 'Bahamas', 'iver-hotel' ),
			'BH' => esc_html__( 'Bahrain', 'iver-hotel' ),
			'BD' => esc_html__( 'Bangladesh', 'iver-hotel' ),
			'BB' => esc_html__( 'Barbados', 'iver-hotel' ),
			'BY' => esc_html__( 'Belarus', 'iver-hotel' ),
			'BE' => esc_html__( 'Belgium', 'iver-hotel' ),
			'PW' => esc_html__( 'Belau', 'iver-hotel' ),
			'BZ' => esc_html__( 'Belize', 'iver-hotel' ),
			'BJ' => esc_html__( 'Benin', 'iver-hotel' ),
			'BM' => esc_html__( 'Bermuda', 'iver-hotel' ),
			'BT' => esc_html__( 'Bhutan', 'iver-hotel' ),
			'BO' => esc_html__( 'Bolivia', 'iver-hotel' ),
			'BQ' => esc_html__( 'Bonaire, Saint Eustatius and Saba', 'iver-hotel' ),
			'BA' => esc_html__( 'Bosnia and Herzegovina', 'iver-hotel' ),
			'BW' => esc_html__( 'Botswana', 'iver-hotel' ),
			'BV' => esc_html__( 'Bouvet Island', 'iver-hotel' ),
			'BR' => esc_html__( 'Brazil', 'iver-hotel' ),
			'IO' => esc_html__( 'British Indian Ocean Territory', 'iver-hotel' ),
			'VG' => esc_html__( 'British Virgin Islands', 'iver-hotel' ),
			'BN' => esc_html__( 'Brunei', 'iver-hotel' ),
			'BG' => esc_html__( 'Bulgaria', 'iver-hotel' ),
			'BF' => esc_html__( 'Burkina Faso', 'iver-hotel' ),
			'BI' => esc_html__( 'Burundi', 'iver-hotel' ),
			'KH' => esc_html__( 'Cambodia', 'iver-hotel' ),
			'CM' => esc_html__( 'Cameroon', 'iver-hotel' ),
			'CA' => esc_html__( 'Canada', 'iver-hotel' ),
			'CV' => esc_html__( 'Cape Verde', 'iver-hotel' ),
			'KY' => esc_html__( 'Cayman Islands', 'iver-hotel' ),
			'CF' => esc_html__( 'Central African Republic', 'iver-hotel' ),
			'TD' => esc_html__( 'Chad', 'iver-hotel' ),
			'CL' => esc_html__( 'Chile', 'iver-hotel' ),
			'CN' => esc_html__( 'China', 'iver-hotel' ),
			'CX' => esc_html__( 'Christmas Island', 'iver-hotel' ),
			'CC' => esc_html__( 'Cocos (Keeling) Islands', 'iver-hotel' ),
			'CO' => esc_html__( 'Colombia', 'iver-hotel' ),
			'KM' => esc_html__( 'Comoros', 'iver-hotel' ),
			'CG' => esc_html__( 'Congo (Brazzaville)', 'iver-hotel' ),
			'CD' => esc_html__( 'Congo (Kinshasa)', 'iver-hotel' ),
			'CK' => esc_html__( 'Cook Islands', 'iver-hotel' ),
			'CR' => esc_html__( 'Costa Rica', 'iver-hotel' ),
			'HR' => esc_html__( 'Croatia', 'iver-hotel' ),
			'CU' => esc_html__( 'Cuba', 'iver-hotel' ),
			'CW' => esc_html__( 'Cura&ccedil;ao', 'iver-hotel' ),
			'CY' => esc_html__( 'Cyprus', 'iver-hotel' ),
			'CZ' => esc_html__( 'Czech Republic', 'iver-hotel' ),
			'DK' => esc_html__( 'Denmark', 'iver-hotel' ),
			'DJ' => esc_html__( 'Djibouti', 'iver-hotel' ),
			'DM' => esc_html__( 'Dominica', 'iver-hotel' ),
			'DO' => esc_html__( 'Dominican Republic', 'iver-hotel' ),
			'EC' => esc_html__( 'Ecuador', 'iver-hotel' ),
			'EG' => esc_html__( 'Egypt', 'iver-hotel' ),
			'SV' => esc_html__( 'El Salvador', 'iver-hotel' ),
			'GQ' => esc_html__( 'Equatorial Guinea', 'iver-hotel' ),
			'ER' => esc_html__( 'Eritrea', 'iver-hotel' ),
			'EE' => esc_html__( 'Estonia', 'iver-hotel' ),
			'ET' => esc_html__( 'Ethiopia', 'iver-hotel' ),
			'FK' => esc_html__( 'Falkland Islands', 'iver-hotel' ),
			'FO' => esc_html__( 'Faroe Islands', 'iver-hotel' ),
			'FJ' => esc_html__( 'Fiji', 'iver-hotel' ),
			'FI' => esc_html__( 'Finland', 'iver-hotel' ),
			'FR' => esc_html__( 'France', 'iver-hotel' ),
			'GF' => esc_html__( 'French Guiana', 'iver-hotel' ),
			'PF' => esc_html__( 'French Polynesia', 'iver-hotel' ),
			'TF' => esc_html__( 'French Southern Territories', 'iver-hotel' ),
			'GA' => esc_html__( 'Gabon', 'iver-hotel' ),
			'GM' => esc_html__( 'Gambia', 'iver-hotel' ),
			'GE' => esc_html__( 'Georgia', 'iver-hotel' ),
			'DE' => esc_html__( 'Germany', 'iver-hotel' ),
			'GH' => esc_html__( 'Ghana', 'iver-hotel' ),
			'GI' => esc_html__( 'Gibraltar', 'iver-hotel' ),
			'GR' => esc_html__( 'Greece', 'iver-hotel' ),
			'GL' => esc_html__( 'Greenland', 'iver-hotel' ),
			'GD' => esc_html__( 'Grenada', 'iver-hotel' ),
			'GP' => esc_html__( 'Guadeloupe', 'iver-hotel' ),
			'GU' => esc_html__( 'Guam', 'iver-hotel' ),
			'GT' => esc_html__( 'Guatemala', 'iver-hotel' ),
			'GG' => esc_html__( 'Guernsey', 'iver-hotel' ),
			'GN' => esc_html__( 'Guinea', 'iver-hotel' ),
			'GW' => esc_html__( 'Guinea-Bissau', 'iver-hotel' ),
			'GY' => esc_html__( 'Guyana', 'iver-hotel' ),
			'HT' => esc_html__( 'Haiti', 'iver-hotel' ),
			'HM' => esc_html__( 'Heard Island and McDonald Islands', 'iver-hotel' ),
			'HN' => esc_html__( 'Honduras', 'iver-hotel' ),
			'HK' => esc_html__( 'Hong Kong', 'iver-hotel' ),
			'HU' => esc_html__( 'Hungary', 'iver-hotel' ),
			'IS' => esc_html__( 'Iceland', 'iver-hotel' ),
			'IN' => esc_html__( 'India', 'iver-hotel' ),
			'ID' => esc_html__( 'Indonesia', 'iver-hotel' ),
			'IR' => esc_html__( 'Iran', 'iver-hotel' ),
			'IQ' => esc_html__( 'Iraq', 'iver-hotel' ),
			'IE' => esc_html__( 'Ireland', 'iver-hotel' ),
			'IM' => esc_html__( 'Isle of Man', 'iver-hotel' ),
			'IL' => esc_html__( 'Israel', 'iver-hotel' ),
			'IT' => esc_html__( 'Italy', 'iver-hotel' ),
			'CI' => esc_html__( 'Ivory Coast', 'iver-hotel' ),
			'JM' => esc_html__( 'Jamaica', 'iver-hotel' ),
			'JP' => esc_html__( 'Japan', 'iver-hotel' ),
			'JE' => esc_html__( 'Jersey', 'iver-hotel' ),
			'JO' => esc_html__( 'Jordan', 'iver-hotel' ),
			'KZ' => esc_html__( 'Kazakhstan', 'iver-hotel' ),
			'KE' => esc_html__( 'Kenya', 'iver-hotel' ),
			'KI' => esc_html__( 'Kiribati', 'iver-hotel' ),
			'KW' => esc_html__( 'Kuwait', 'iver-hotel' ),
			'KG' => esc_html__( 'Kyrgyzstan', 'iver-hotel' ),
			'LA' => esc_html__( 'Laos', 'iver-hotel' ),
			'LV' => esc_html__( 'Latvia', 'iver-hotel' ),
			'LB' => esc_html__( 'Lebanon', 'iver-hotel' ),
			'LS' => esc_html__( 'Lesotho', 'iver-hotel' ),
			'LR' => esc_html__( 'Liberia', 'iver-hotel' ),
			'LY' => esc_html__( 'Libya', 'iver-hotel' ),
			'LI' => esc_html__( 'Liechtenstein', 'iver-hotel' ),
			'LT' => esc_html__( 'Lithuania', 'iver-hotel' ),
			'LU' => esc_html__( 'Luxembourg', 'iver-hotel' ),
			'MO' => esc_html__( 'Macao S.A.R., China', 'iver-hotel' ),
			'MK' => esc_html__( 'Macedonia', 'iver-hotel' ),
			'MG' => esc_html__( 'Madagascar', 'iver-hotel' ),
			'MW' => esc_html__( 'Malawi', 'iver-hotel' ),
			'MY' => esc_html__( 'Malaysia', 'iver-hotel' ),
			'MV' => esc_html__( 'Maldives', 'iver-hotel' ),
			'ML' => esc_html__( 'Mali', 'iver-hotel' ),
			'MT' => esc_html__( 'Malta', 'iver-hotel' ),
			'MH' => esc_html__( 'Marshall Islands', 'iver-hotel' ),
			'MQ' => esc_html__( 'Martinique', 'iver-hotel' ),
			'MR' => esc_html__( 'Mauritania', 'iver-hotel' ),
			'MU' => esc_html__( 'Mauritius', 'iver-hotel' ),
			'YT' => esc_html__( 'Mayotte', 'iver-hotel' ),
			'MX' => esc_html__( 'Mexico', 'iver-hotel' ),
			'FM' => esc_html__( 'Micronesia', 'iver-hotel' ),
			'MD' => esc_html__( 'Moldova', 'iver-hotel' ),
			'MC' => esc_html__( 'Monaco', 'iver-hotel' ),
			'MN' => esc_html__( 'Mongolia', 'iver-hotel' ),
			'ME' => esc_html__( 'Montenegro', 'iver-hotel' ),
			'MS' => esc_html__( 'Montserrat', 'iver-hotel' ),
			'MA' => esc_html__( 'Morocco', 'iver-hotel' ),
			'MZ' => esc_html__( 'Mozambique', 'iver-hotel' ),
			'MM' => esc_html__( 'Myanmar', 'iver-hotel' ),
			'NA' => esc_html__( 'Namibia', 'iver-hotel' ),
			'NR' => esc_html__( 'Nauru', 'iver-hotel' ),
			'NP' => esc_html__( 'Nepal', 'iver-hotel' ),
			'NL' => esc_html__( 'Netherlands', 'iver-hotel' ),
			'NC' => esc_html__( 'New Caledonia', 'iver-hotel' ),
			'NZ' => esc_html__( 'New Zealand', 'iver-hotel' ),
			'NI' => esc_html__( 'Nicaragua', 'iver-hotel' ),
			'NE' => esc_html__( 'Niger', 'iver-hotel' ),
			'NG' => esc_html__( 'Nigeria', 'iver-hotel' ),
			'NU' => esc_html__( 'Niue', 'iver-hotel' ),
			'NF' => esc_html__( 'Norfolk Island', 'iver-hotel' ),
			'MP' => esc_html__( 'Northern Mariana Islands', 'iver-hotel' ),
			'KP' => esc_html__( 'North Korea', 'iver-hotel' ),
			'NO' => esc_html__( 'Norway', 'iver-hotel' ),
			'OM' => esc_html__( 'Oman', 'iver-hotel' ),
			'PK' => esc_html__( 'Pakistan', 'iver-hotel' ),
			'PS' => esc_html__( 'Palestinian Territory', 'iver-hotel' ),
			'PA' => esc_html__( 'Panama', 'iver-hotel' ),
			'PG' => esc_html__( 'Papua New Guinea', 'iver-hotel' ),
			'PY' => esc_html__( 'Paraguay', 'iver-hotel' ),
			'PE' => esc_html__( 'Peru', 'iver-hotel' ),
			'PH' => esc_html__( 'Philippines', 'iver-hotel' ),
			'PN' => esc_html__( 'Pitcairn', 'iver-hotel' ),
			'PL' => esc_html__( 'Poland', 'iver-hotel' ),
			'PT' => esc_html__( 'Portugal', 'iver-hotel' ),
			'PR' => esc_html__( 'Puerto Rico', 'iver-hotel' ),
			'QA' => esc_html__( 'Qatar', 'iver-hotel' ),
			'RE' => esc_html__( 'Reunion', 'iver-hotel' ),
			'RO' => esc_html__( 'Romania', 'iver-hotel' ),
			'RU' => esc_html__( 'Russia', 'iver-hotel' ),
			'RW' => esc_html__( 'Rwanda', 'iver-hotel' ),
			'BL' => esc_html__( 'Saint Barth&eacute;lemy', 'iver-hotel' ),
			'SH' => esc_html__( 'Saint Helena', 'iver-hotel' ),
			'KN' => esc_html__( 'Saint Kitts and Nevis', 'iver-hotel' ),
			'LC' => esc_html__( 'Saint Lucia', 'iver-hotel' ),
			'MF' => esc_html__( 'Saint Martin (French part)', 'iver-hotel' ),
			'SX' => esc_html__( 'Saint Martin (Dutch part)', 'iver-hotel' ),
			'PM' => esc_html__( 'Saint Pierre and Miquelon', 'iver-hotel' ),
			'VC' => esc_html__( 'Saint Vincent and the Grenadines', 'iver-hotel' ),
			'SM' => esc_html__( 'San Marino', 'iver-hotel' ),
			'ST' => esc_html__( 'S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'iver-hotel' ),
			'SA' => esc_html__( 'Saudi Arabia', 'iver-hotel' ),
			'SN' => esc_html__( 'Senegal', 'iver-hotel' ),
			'RS' => esc_html__( 'Serbia', 'iver-hotel' ),
			'SC' => esc_html__( 'Seychelles', 'iver-hotel' ),
			'SL' => esc_html__( 'Sierra Leone', 'iver-hotel' ),
			'SG' => esc_html__( 'Singapore', 'iver-hotel' ),
			'SK' => esc_html__( 'Slovakia', 'iver-hotel' ),
			'SI' => esc_html__( 'Slovenia', 'iver-hotel' ),
			'SB' => esc_html__( 'Solomon Islands', 'iver-hotel' ),
			'SO' => esc_html__( 'Somalia', 'iver-hotel' ),
			'ZA' => esc_html__( 'South Africa', 'iver-hotel' ),
			'GS' => esc_html__( 'South Georgia/Sandwich Islands', 'iver-hotel' ),
			'KR' => esc_html__( 'South Korea', 'iver-hotel' ),
			'SS' => esc_html__( 'South Sudan', 'iver-hotel' ),
			'ES' => esc_html__( 'Spain', 'iver-hotel' ),
			'LK' => esc_html__( 'Sri Lanka', 'iver-hotel' ),
			'SD' => esc_html__( 'Sudan', 'iver-hotel' ),
			'SR' => esc_html__( 'Suriname', 'iver-hotel' ),
			'SJ' => esc_html__( 'Svalbard and Jan Mayen', 'iver-hotel' ),
			'SZ' => esc_html__( 'Swaziland', 'iver-hotel' ),
			'SE' => esc_html__( 'Sweden', 'iver-hotel' ),
			'CH' => esc_html__( 'Switzerland', 'iver-hotel' ),
			'SY' => esc_html__( 'Syria', 'iver-hotel' ),
			'TW' => esc_html__( 'Taiwan', 'iver-hotel' ),
			'TJ' => esc_html__( 'Tajikistan', 'iver-hotel' ),
			'TZ' => esc_html__( 'Tanzania', 'iver-hotel' ),
			'TH' => esc_html__( 'Thailand', 'iver-hotel' ),
			'TL' => esc_html__( 'Timor-Leste', 'iver-hotel' ),
			'TG' => esc_html__( 'Togo', 'iver-hotel' ),
			'TK' => esc_html__( 'Tokelau', 'iver-hotel' ),
			'TO' => esc_html__( 'Tonga', 'iver-hotel' ),
			'TT' => esc_html__( 'Trinidad and Tobago', 'iver-hotel' ),
			'TN' => esc_html__( 'Tunisia', 'iver-hotel' ),
			'TR' => esc_html__( 'Turkey', 'iver-hotel' ),
			'TM' => esc_html__( 'Turkmenistan', 'iver-hotel' ),
			'TC' => esc_html__( 'Turks and Caicos Islands', 'iver-hotel' ),
			'TV' => esc_html__( 'Tuvalu', 'iver-hotel' ),
			'UG' => esc_html__( 'Uganda', 'iver-hotel' ),
			'UA' => esc_html__( 'Ukraine', 'iver-hotel' ),
			'AE' => esc_html__( 'United Arab Emirates', 'iver-hotel' ),
			'GB' => esc_html__( 'United Kingdom (UK)', 'iver-hotel' ),
			'US' => esc_html__( 'United States (US)', 'iver-hotel' ),
			'UM' => esc_html__( 'United States (US) Minor Outlying Islands', 'iver-hotel' ),
			'VI' => esc_html__( 'United States (US) Virgin Islands', 'iver-hotel' ),
			'UY' => esc_html__( 'Uruguay', 'iver-hotel' ),
			'UZ' => esc_html__( 'Uzbekistan', 'iver-hotel' ),
			'VU' => esc_html__( 'Vanuatu', 'iver-hotel' ),
			'VA' => esc_html__( 'Vatican', 'iver-hotel' ),
			'VE' => esc_html__( 'Venezuela', 'iver-hotel' ),
			'VN' => esc_html__( 'Vietnam', 'iver-hotel' ),
			'WF' => esc_html__( 'Wallis and Futuna', 'iver-hotel' ),
			'EH' => esc_html__( 'Western Sahara', 'iver-hotel' ),
			'WS' => esc_html__( 'Samoa', 'iver-hotel' ),
			'YE' => esc_html__( 'Yemen', 'iver-hotel' ),
			'ZM' => esc_html__( 'Zambia', 'iver-hotel' ),
			'ZW' => esc_html__( 'Zimbabwe', 'iver-hotel' )
		);

		return $countries;
	}
}



