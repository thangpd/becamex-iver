<?php
namespace IverHotel\CPT\HotelRoom;

use IverHotel\Lib;

/**
 * Class HotelRoomRegister
 * @package IverHotel\CPT\HotelRoom
 */

class HotelRoomRegister implements Lib\PostTypeInterface {
	/**
	 * @var string
	 */
	private $base;
	/**
	 * @var string
	 */
	private $taxBase;

	public function __construct() {
		$this->base    = 'hotel-room';
		$this->taxBase = 'hotel-room-category';

		add_action( 'admin_menu', array( $this, 'removeLocationTagMetaBox' ) );
		add_action( 'admin_menu', array( $this, 'removeExtraServicesTagMetaBox' ) );
		add_action( 'admin_menu', array( $this, 'removeReviewTagMetaBox' ) );

		add_filter( 'single_template', array( $this, 'registerSingleTemplate' ) );
	}

	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function register() {
		$this->registerPostType();
		$this->registerTagTax();
	}

	/**
	 * Registers hotel room single template if one does'nt exists in theme.
	 * Hooked to single_template filter
	 * @param $single string current template
	 * @return string string changed template
	 */
	public function registerSingleTemplate( $single ) {
		global $post;

		if ( isset( $post ) && $post->post_type == $this->base ) {

			if ( ! file_exists( get_template_directory() . '/single-' . $this->base . '.php' ) ) {
				return IVER_HOTEL_CPT_PATH . '/hotel-room/templates/single-' . $this->base . '.php';
			}
		}

		return $single;
	}

	/**
	 * Regsiters custom post type with WordPress
	 */
	private function registerPostType() {

		$menuPosition = 5;
		$menuIcon     = 'dashicons-palmtree';

		register_post_type($this->base,
			array(
				'labels'        => array(
					'name'          => __('Iver Hotel Room', 'iver-hotel'),
					'menu_name'     => __('Iver Hotel Room', 'iver-hotel'),
					'all_items'     => __('Iver Hotel Room Items', 'iver-hotel'),
					'add_new'       => __('Add New Hotel Room', 'iver-hotel'),
					'singular_name' => __('Iver Hotel Room', 'iver-hotel'),
					'add_item'      => __('New Hotel Room Item', 'iver-hotel'),
					'add_new_item'  => __('Add New Hotel Room Item', 'iver-hotel'),
					'edit_item'     => __('Edit Hotel Room', 'iver-hotel')
				),
				'public'        => true,
				'show_in_menu'  => true,
				'menu_position' => $menuPosition,
				'show_ui'       => true,
				'has_archive'   => false,
				'hierarchical'  => false,
				'supports'      => array('title', 'editor', 'thumbnail', 'page-attributes', 'excerpt', 'comments'),
				'menu_icon'     => $menuIcon
			)
		);
	}

	/**
	 * Registers custom tag taxonomy with WordPress
	 */
	private function registerTagTax() {
		$labels_extra_services = array(
			'name'              => esc_html__( 'Extra Services', 'iver-hotel' ),
			'singular_name'     => esc_html__( 'Extra Service', 'iver-hotel' ),
			'search_items'      => esc_html__( 'Search Extra Services', 'iver-hotel' ),
			'all_items'         => esc_html__( 'All Extra Services', 'iver-hotel' ),
			'parent_item'       => esc_html__( 'Parent Extra Service', 'iver-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Extra Services:', 'iver-hotel' ),
			'edit_item'         => esc_html__( 'Edit Extra Service', 'iver-hotel' ),
			'update_item'       => esc_html__( 'Update Extra Service', 'iver-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Extra Service', 'iver-hotel' ),
			'new_item_name'     => esc_html__( 'New Extra Service Name', 'iver-hotel' ),
			'menu_name'         => esc_html__( 'Extra Services', 'iver-hotel' )
		);

		$labels_amenities = array(
			'name'              => esc_html__( 'Amenities', 'iver-hotel' ),
			'singular_name'     => esc_html__( 'Amenity', 'iver-hotel' ),
			'search_items'      => esc_html__( 'Search Amenities', 'iver-hotel' ),
			'all_items'         => esc_html__( 'All Amenities', 'iver-hotel' ),
			'parent_item'       => esc_html__( 'Parent Amenity', 'iver-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Amenities:', 'iver-hotel' ),
			'edit_item'         => esc_html__( 'Edit Amenity', 'iver-hotel' ),
			'update_item'       => esc_html__( 'Update Amenity', 'iver-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Amenity', 'iver-hotel' ),
			'new_item_name'     => esc_html__( 'New Amenity Name', 'iver-hotel' ),
			'menu_name'         => esc_html__( 'Amenities', 'iver-hotel' )
		);

		$labels_locations = array(
			'name'              => esc_html__( 'Locations', 'iver-hotel' ),
			'singular_name'     => esc_html__( 'Location', 'iver-hotel' ),
			'search_items'      => esc_html__( 'Search Locations', 'iver-hotel' ),
			'all_items'         => esc_html__( 'All Locations', 'iver-hotel' ),
			'parent_item'       => esc_html__( 'Parent Location', 'iver-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Locations:', 'iver-hotel' ),
			'edit_item'         => esc_html__( 'Edit Location', 'iver-hotel' ),
			'update_item'       => esc_html__( 'Update Location', 'iver-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Location', 'iver-hotel' ),
			'new_item_name'     => esc_html__( 'New Location Name', 'iver-hotel' ),
			'menu_name'         => esc_html__( 'Locations', 'iver-hotel' )
		);

		$labels_review = array(
			'name'              => esc_html__('Review Criteria', 'iver-hotel'),
			'singular_name'     => esc_html__('Review Criterion', 'iver-hotel'),
			'search_items'      => esc_html__('Search Review Criteria', 'iver-hotel'),
			'all_items'         => esc_html__('All Review Criteria', 'iver-hotel'),
			'parent_item'       => esc_html__('Parent Review Criterion', 'iver-hotel'),
			'parent_item_colon' => esc_html__('Parent Review Criterion:', 'iver-hotel'),
			'edit_item'         => esc_html__('Edit Review Criterion', 'iver-hotel'),
			'update_item'       => esc_html__('Update Review Criterion', 'iver-hotel'),
			'add_new_item'      => esc_html__('Add New Review Criterion', 'iver-hotel'),
			'new_item_name'     => esc_html__('New Review Criterion Name', 'iver-hotel'),
			'menu_name'         => esc_html__('Review Criteria', 'iver-hotel'),
		);

		register_taxonomy( 'extra-service-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels_extra_services,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'extra-service-tag' )
		) );

		register_taxonomy( 'amenity-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels_amenities,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'amenity-tag' )
		) );

		register_taxonomy( 'location-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels_locations,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'location-tag' )
		) );

		register_taxonomy('review-tag', array($this->base), array(
			'hierarchical'      => false,
			'labels'            => $labels_review,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => false,
			'rewrite'           => array( 'slug' => 'review-tag' )
		));
	}

	public function removeLocationTagMetaBox() {
		// remove location tags from side metaboxes
		remove_meta_box('tagsdiv-location-tag', $this->base, 'side');
	}

	public function removeExtraServicesTagMetaBox() {
		// remove extra services tags from side metaboxes
		remove_meta_box('tagsdiv-extra-service-tag', $this->base, 'side');
	}

	public function removeReviewTagMetaBox() {
		// remove extra services tags from side metaboxes
		remove_meta_box('review-tagdiv', $this->base, 'side');
	}





}