<?php

namespace IverHotel\CPT\HotelRoom\Lib;

/**
 * Class BookingHandler
 * @package IverHotel\CPT\HotelRoom\Lib
 */
class BookingHandler {
	/**
	 * @var private instance of current class
	 */
	private static $instance;

	/**
	 * @var
	 */
	private $labels;

	/**
	 * Private constuct because of Singletone
	 */
	private function __construct() {
	}

	/**
	 * Private sleep because of Singletone
	 */
	private function __wakeup() {
	}

	/**
	 * Private clone because of Singletone
	 */
	private function __clone() {
	}

	/**
	 * Returns current instance of class
	 * @return BookingHandler
	 */
	public static function getInstance() {
		if(self::$instance == null) {
			return new self;
		}

		return self::$instance;
	}

	/**
	 * Initializes all functionality of booking handling.
	 * Calls methods that enqueue necessary assets,
	 * initialize labels, hooks method to ajax call
	 */
	public function initialize() {
		$this->setLabels();

		add_action('wp_ajax_check_hotel_room_booking', array($this, 'handleBooking'));
		add_action('wp_ajax_nopriv_check_hotel_room_booking', array($this, 'handleBooking'));

		add_action('wp_ajax_check_hotel_room_session_update', array($this, 'updateBookingSession'));
		add_action('wp_ajax_nopriv_check_hotel_room_session_update', array($this, 'updateBookingSession'));

		add_action('after_setup_theme', array($this, 'startSession'));
	}

	/**
	 *
	 */
	public function startSession() {
		//session_start();
	}

	/**
	 * Hooks to ajax call, calls method that validate data and store new booking
	 * @return mixed
	 */
	public function handleBooking() {
		$returnObject = new \stdClass();

		// start
		parse_str($_POST['fields'], $params);

		// check validation
		$validation = $this->validate($params);

		if(!$validation->status) {
			$returnObject->status   = $validation->status;
			$returnObject->messages = $validation->messages;

			echo json_encode($returnObject);
			exit;
		}

		// check availability
		$can_be_booked = $this->checkAvailability($params);

		if(!$can_be_booked->status) {
			$returnObject->status     = $can_be_booked->status;
			$returnObject->messages = $can_be_booked->messages;
			$returnObject->relocation = $can_be_booked->relocation;

			echo json_encode($returnObject);
			exit;
		}

		// get new price
		$new_price_info = $this->getNewPrice($params);
		$new_price = $new_price_info['price'];
		$additional_info = $new_price_info['additional_info'];

		$returnObject->rooms       = $can_be_booked->rooms;
		$returnObject->status       = true;
		$returnObject->messages     = $can_be_booked->messages;
		$returnObject->newPrice     = $new_price;

		$params['free_rooms'] = $can_be_booked->rooms;
		$params['new_price'] = $new_price;
		$params['additional_info'] = $additional_info;

		// get new price
		$this->setRoomSection($params);

		echo json_encode($returnObject);
		exit;
	}

	/**
	 * Hooks to ajax call, calls method that update session
	 * @return mixed
	 */
	public function updateBookingSession() {
		$returnObject = new \stdClass();

		$ids = $this->getProductIds();

		// update session to be the same elements in cart
		$this->updateRoomSection($ids);

		echo json_encode($returnObject);
		exit;
	}

	/**
	 * @param $params
	 *
	 * @return bool|\stdClass
	 */
	private function checkAvailability($params) {

		$check_validation = new \stdClass();

		$check_validation->status   = false;
		$check_validation->messages = array();

		$availability = iver_hotel_room_check_availability(array(
			'page_id' => $params['room_id'],
			'room_min_date' => $params['room_min_date'],
			'room_max_date' => $params['room_max_date'],
			'room_number_of_rooms' => $params['room_number']));

		// this is just for check - it shouldn't be used if it is not hacked
		$room_max_adults = get_post_meta($params['room_id'], 'hotel_room_price', true);
		$room_max_children = get_post_meta($params['room_id'], 'hotel_room_price', true);

		$capacity_allowed = intval($params['room_adults']) <= intval($room_max_adults)
		                    && intval($params['room_children']) <= intval($room_max_children);

		if((!$availability['flag'])) {
			$check_validation->messages[] = $this->labels['room_booked'];
			$check_validation->status = false;
			$check_validation->relocation = 'hotel_search';
		}
		elseif(!$capacity_allowed)  {
			$check_validation->messages[] = $this->labels['capacity_error'];
			$check_validation->status = false;
			$check_validation->relocation = 'hotel_search';
		}
		else {
			$check_validation->rooms = $availability['rooms'];
			$check_validation->status = true;
			$check_validation->relocation = '';
		}

		return $check_validation;

	}

	/**
	 * Validates current request. Returns object that has status and messages hotel room
	 *
	 * @param $request
	 *
	 * @param $validateUserInfo
	 *
	 * @return \stdClass
	 */
	private function validate($request, $validateUserInfo = true) {

		$validation = new \stdClass();

		$validation->status   = false;
		$validation->messages = array();

		if(empty($request['iver_hotel_room_booking_form']) || !wp_verify_nonce($request['iver_hotel_room_booking_form'], 'iver_hotel_room_booking_form')) {
			$validation->messages[] = 'Don\'t try to hack me!';
			$validation->status     = false;

			return $validation;
		}

		if($validateUserInfo) {

			$email          = wp_get_current_user()->user_email;

			if(empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$validation->messages[] = $this->labels['email'];
			}
		}

		$dateInInt = strtotime($request['room_min_date']);
		$dateOutInt = strtotime($request['room_max_date']);

		if(empty($request['room_min_date']) || !(checkdate(date('m', $dateInInt), date('d', $dateInInt), date('Y', $dateInInt)))) {
			$validation->messages[] = $this->labels['room_min_date'];
		}

		if(empty($request['room_max_date']) || !(checkdate(date('m', $dateOutInt), date('d', $dateOutInt), date('Y', $dateOutInt)))) {
			$validation->messages[] = $this->labels['room_max_date'];
		}

		if(empty($request['room_number']) && !filter_var($request['room_number'], FILTER_VALIDATE_INT)) {
			$validation->messages[] = $this->labels['room_number'];
		}

		if(empty($request['room_adults']) && !filter_var($request['room_adults'], FILTER_VALIDATE_INT)) {
			$validation->messages[] = $this->labels['room_adults'];
		}

		if(empty($request['room_children']) && !filter_var($request['room_children'], FILTER_VALIDATE_INT) && $request['room_children'] != 0) {
			$validation->messages[] = $this->labels['room_children'];
		}

		$validation->status = count($validation->messages) === 0;

		return $validation;

	}

	/**
	 * This function returns new price based on new extra services, number of rooms and persons
	 *
	 * @param $params array form elements
	 *
	 * @return array of strings new price and all additional info
	 */
	private function getNewPrice( $params ) {

		$price_params_array = array(
			'page_id' => $params['room_id'],
			'room_min_date' => $params['room_min_date'],
			'room_max_date' => $params['room_max_date'],
			'room_adults' => $params['room_adults'],
			'room_children' => $params['room_children'],
			'room_number' => $params['room_number'],
			'checked_extra_services' => $params['checked_extra_services']

		);

		$all_extra_services = $this->getExtraServices($price_params_array);
		$price = iver_hotel_room_get_new_price($price_params_array);

		return array('price' => $price, 'additional_info' => $all_extra_services);

	}


	/**
	 * Sets validation labels
	 */
	private function setLabels() {

		$this->labels = array(
			'email'            => esc_html__('Please login with valid email', 'iver-hotel'),
			'room_min_date'             => esc_html__('Please choose date for Check In', 'iver-hotel'),
			'room_max_date'             => esc_html__('Please choose date for Check Out', 'iver-hotel'),
			'room_number'               => esc_html__('Please number of rooms time', 'iver-hotel'),
			'room_adults'  => esc_html__('Please choose number of adults', 'iver-hotel'),
			'room_children'  => esc_html__('Please choose number of children', 'iver-hotel'),
			'room_booked'  => esc_html__('Those Rooms are booked', 'iver-hotel'),
			'capacity_error'  => esc_html__('Not enough capacity', 'iver-hotel')

		);

	}

	/**
	 * Function that put rooms number into session
	 *
	 * @param $params
	 *
	 */
	private function setRoomSection( $params ) {

		// creating session
		if(!isset($_SESSION)) {
			session_start();
			$_SESSION['rooms'] = array();
		}
		else {
			if(!isset($_SESSION['rooms'])) {
				$_SESSION['rooms'] = array();
			}
		}

		// reset all rooms except the room that exists
		$new_rooms = array();
		foreach ($_SESSION['rooms'] as $room) {
			if($room['item_id'] != $params['room_id']) {
				$new_rooms[] = $room;
			}
		}
		$_SESSION['rooms'] = $new_rooms;

		// added new room
		$room_reservation = array(
			'item_id' => $params['room_id'],
			'room_price' => $params['new_price'],
			'room_min_date' => $params['room_min_date'],
			'room_max_date' => $params['room_max_date'],
			'free_rooms' => $params['free_rooms'],
			'room_adults' => $params['room_adults'],
			'room_children' => $params['room_children'],
			'additional_info' => $params['additional_info']
		);

		// overwrite previous section
		$_SESSION['rooms'][] = $room_reservation;
	}

	/**
	 * Function update session
	 * This function is called cuz user may deleted some product from cart
	 * Update is based on element in cart that will be send to checkout
	 *
	 * @param $ids
	 *
	 */
	private function updateRoomSection( $ids ) {

		if(isset($_SESSION) && isset($_SESSION['rooms'])) {

			// compare rooms in cart and in session and make it to be same
			$new_rooms = array();
			foreach ( $_SESSION['rooms'] as $room ) {
				if ( is_array($ids) && in_array(intval($room['item_id']), $ids)) {
					$new_rooms[] = $room;
				}
			}

			// overwrite previous section
			$_SESSION['rooms'] = $new_rooms;
		}

	}


	/**
	 * This function returns all ids of products which are in cart
	 *
	 * @return array
	 */
	private function getProductIds() {
		global $woocommerce;
		$items = $woocommerce->cart->get_cart();

		$ids = array();

		foreach($items as $item => $values) {
			$ids[] = $values['data']->get_id();
		}

		return $ids;

	}



	/**
	 * This function get all extra services which are used to create new price
	 *
	 * @param $params
	 *
	 * @return string
	 */
	private function getExtraServices($params) {

		// get all selected extra services - this does not include mandatory extra services
		$checked_extra_services     = array();
		$checked_extra_services_ids = $params['checked_extra_services'];
		$additional_info = ''; // this string is used to add into additional info after room is booked

		foreach ( $checked_extra_services_ids as $checked_extra_services_id ) {

			// get extra service parameters based on their id
			$public = strstr( $checked_extra_services_id, 'public' ) !== false;
			$tag_id = substr( strstr( $checked_extra_services_id, 'id-' ), 3 ); // clear 'id-'

			$checked_extra_services[] = iver_hotel_room_single_specific_extra_service( $public, $tag_id, $params['page_id'] );
		}

		// get all mandatory extra services cuz they are not in form
		$mandatory_extra_services = array();
		$single_extra_services    = iver_hotel_room_single_room_extra_services(array(), $params['page_id'] );

		foreach ( $single_extra_services['extra_services'] as $extra_service ) {
			if ( $extra_service['type'] == 'mandatory' ) {
				$mandatory_extra_services[] = $extra_service;
			}
		}

		// merging all extra services
		$all_extra_services = array_merge( $checked_extra_services, $mandatory_extra_services );
		foreach ( $all_extra_services as $all_extra_service ) {
			if($additional_info != '') {
				$additional_info .= ', ';
			}
			$additional_info .= $all_extra_service['name'];
		}

		return $additional_info;


	}
}