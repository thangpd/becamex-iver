<?php

use IverHotel\CPT\HotelRoom\Lib\HotelRoomSearch;

if(!function_exists('iver_hotel_room_search')) {
	/**
	 * @return HotelRoomSearch
	 */
	function iver_hotel_room_search() {
		return HotelRoomSearch::getInstance();
	}
}