<?php

/* Property Type Custom Fields */
if (!function_exists( 'iver_hotel_room_taxonomy_extra_services_fields' )) {
    function iver_hotel_room_taxonomy_extra_services_fields() {

	    /* get currency */
	    $currency = iver_hotel_room_get_currency();

        $extra_service_type_fields = iver_select_add_taxonomy_fields(
            array(
                'scope' => 'extra-service-tag',
                'name'  => 'extra_service_tag'
            )
        );

	    iver_select_add_taxonomy_field(
		    array(
			    'name'        => 'qodef_extra_service_pack',
			    'type'        => 'selectblank',
			    'label'       => esc_html__( 'Service Pack', 'iver-hotel' ),
			    'description' => esc_html__( 'Choose Service Pack from the list.', 'iver-hotel' ),
			    'parent'      => $extra_service_type_fields,
			    'options'     => iver_hotel_room_get_service_packs(),
			    'args'    => array(
				    'select2'  => true
			    )
		    )
	    );

	    iver_select_add_taxonomy_field(
            array(
                'name'        => 'qodef_extra_service_price',
                'type'        => 'text',
                'label'       => esc_html__( 'Price', 'iver-hotel' ).' ('.$currency.')',
                'description' => esc_html__( 'Enter price for extra service. To change currency, use Woocommerce Settings.', 'iver-hotel' ),
                'parent'      => $extra_service_type_fields,
				'dependency' => array(
					'hide' => array(
						'qodef_extra_service_pack'  => array(
							'',
							'increase_price_by_percent_amount',
							'decrease_price_by_percent_amount'
						)
					)
				)
            )
        );

	    iver_select_add_taxonomy_field(
		    array(
			    'name'        => 'qodef_extra_service_percent',
			    'type'        => 'text',
			    'label'       => esc_html__( 'Percent', 'iver-hotel' ),
			    'description' => esc_html__( 'Enter percent for extra service.', 'iver-hotel' ),
			    'parent'      => $extra_service_type_fields,
				'dependency' => array(
					'hide' => array(
						'qodef_extra_service_pack'  => array(
							'',
							'add_to_price',
							'add_to_price_per_night',
							'add_to_price_per_person',
							'add_to_price_per_person_per_night',
							'subtract_from_price',
							'subtract_from_price_per_night',
						)
					)
				)
		    )
	    );

	    iver_select_add_taxonomy_field(
		    array(
			    'name'        => 'qodef_extra_service_type',
			    'type'        => 'selectblank',
			    'label'       => esc_html__( 'Type', 'iver-hotel' ),
			    'description' => esc_html__( 'Choose type of Service Pack from the list.', 'iver-hotel' ),
			    'parent'      => $extra_service_type_fields,
			    'options'     => array(
				    'optional' => esc_html__( 'Optional', 'iver-hotel' ),
				    'mandatory' => esc_html__( 'Mandatory', 'iver-hotel' ),
			    ),
			    'args'    => array(
				    'select2'  => true
			    )
		    )
	    );
    }

    add_action('iver_select_custom_taxonomy_fields', 'iver_hotel_room_taxonomy_extra_services_fields');
}

/* Review tag custom fields */
if ( ! function_exists( 'iver_hotel_room_reviews_fields' ) ) {
    function iver_hotel_room_reviews_fields() {

        $hotel_room_fields = iver_select_add_taxonomy_fields( array(
            'scope' => 'review-tag',
            'name'  => 'review_tag'
        ) );

        iver_select_add_taxonomy_field( array(
            'name'        => 'review_tag_order',
            'type'        => 'text',
            'label'       => esc_html__( 'Order', 'iver-hotel' ),
            'description' => esc_html__( 'If there are multiple criteria, they will be displayed in an ascending order.', 'iver-hotel' ),
            'parent'      => $hotel_room_fields
        ) );

        iver_select_add_taxonomy_field( array(
            'name'        => 'review_tag_show',
            'type'        => 'selectblank',
            'label'       => esc_html__( 'Show in Reviews', 'iver-hotel' ),
            'description' => esc_html__( 'All the criteria can be rated when leaving a review, but only those marked to be shown will be displayed in the list of reviews.', 'iver-hotel' ),
            'options'     => array(
                'no'  => esc_html__( 'No', 'iver-hotel' ),
                'yes' => esc_html__( 'Yes', 'iver-hotel' ),
            ),
            'parent'      => $hotel_room_fields
        ) );
    }

    add_action( 'iver_select_custom_taxonomy_fields', 'iver_hotel_room_reviews_fields' );
}

if ( ! function_exists( 'iver_hotel_room_review_tag_columns' ) ) {
    function iver_hotel_room_review_tag_columns( $columns ) {
        $new_columns = array(
            'cb'                => '<input type="checkbox" />',
            'name'              => esc_html__( 'Name', 'iver-hotel' ),
            'slug'              => esc_html__( 'Slug', 'iver-hotel' ),
            'review_tag_order'  => esc_html__( 'Order', 'iver-hotel' ),
            'review_tag_show'   => esc_html__( 'Shown in Reviews', 'iver-hotel' ),
        );

        return $new_columns;
    }

    add_filter( "manage_edit-review-tag_columns", 'iver_hotel_room_review_tag_columns' );
}

if ( ! function_exists( 'iver_hotel_room_review_tag_column_values' ) ) {
    function iver_hotel_room_review_tag_column_values( $out, $column_name, $term_id ) {
        $term_meta = get_term_meta( $term_id );
        switch ( $column_name ) {
            case 'review_tag_order':
                $out .= isset( $term_meta['review_tag_order'][0] ) ? $term_meta['review_tag_order'][0] : '-';
                break;
            case 'review_tag_show':
                $out .= ( isset( $term_meta['review_tag_show'][0] ) && $term_meta['review_tag_show'][0] == 'yes' ) ? esc_html__( 'Yes', 'iver-hotel' ) : esc_html__( 'No', 'iver-hotel' );
                break;

            default:
                break;
        }

        return $out;
    }

    add_filter( "manage_review-tag_custom_column", 'iver_hotel_room_review_tag_column_values', 10, 3 );
}

if(!function_exists('iver_hotel_room_reviews_get_tag_criteria')) {
    function iver_hotel_room_reviews_get_tag_criteria($default_criteria) {
        $taxonomy_rating = array();
        if(iver_select_core_plugin_installed()) {
            $taxonomy_rating = iver_core_taxonomy_rating_array('review-tag');
        }

        return array_merge($default_criteria, $taxonomy_rating);
    }

    add_filter( 'iver_core_filter_rating_criteria', 'iver_hotel_room_reviews_get_tag_criteria' );
}