<div class="qodef-post-read-more-button">
	<?php
	if ( iver_select_core_plugin_installed() ) {
		echo iver_select_get_button_html(
			apply_filters(
				'iver_select_blog_template_read_more_button',
				array(
					'type'         => 'simple',
					'size'         => 'medium',
					'link'         => get_the_permalink(),
					'text'         => esc_html__( 'Book Now', 'iver-hotel' ),
					'custom_class' => ''
				)
			)
		);
	} else { ?>
		<a itemprop="url" class="qodef-btn qodef-btn-medium qodef-btn-simple" href="<?php echo esc_url( get_the_permalink() ); ?>">
			<span class="qodef-btn-text"><?php echo esc_html__( 'Book Now', 'iver-hotel' ); ?></span>
		</a>
	<?php } ?>
</div>
