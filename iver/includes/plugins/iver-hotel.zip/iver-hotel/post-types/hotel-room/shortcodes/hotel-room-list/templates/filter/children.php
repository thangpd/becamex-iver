<?php
$max_children = iver_hotel_get_hotel_room_max_children();
?>
<?php if ( $max_children != '' ) { ?>
    <div class="qodef-filter-section qodef-filter-section-12 qodef-section-children">
        <div class="qodef-filter-children-count-holder" data-children="<?php echo esc_attr($params['room_children']) ?>">
            <label for="qodef-filter-children"><?php esc_html_e( 'Children', 'iver-hotel' ) ?></label>
            <select id="qodef-filter-children" name="qodef-filter-children" class="qodef-filter-children">
                <option value="0">0</option>
	            <?php for ( $i = 1; $i <= $max_children; $i ++ ) { ?>
                    <option <?php echo (esc_attr($params['room_children']) == $i) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	            <?php } ?>
            </select>
        </div>
    </div>
<?php } ?>