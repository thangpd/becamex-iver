<?php
if ( iver_select_core_plugin_installed() ) {
	echo iver_select_get_button_html( array(
			'custom_class' => 'qodef-hr-filter-button',
			'html_type'    => 'button',
			'size'         => 'medium',
			'type'         => 'solid',
			'text'         => esc_html__( 'Filter Results', 'iver-hotel' )
		) );
}
