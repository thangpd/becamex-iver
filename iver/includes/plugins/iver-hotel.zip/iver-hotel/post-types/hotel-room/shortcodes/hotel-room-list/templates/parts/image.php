<?php
$thumb_size = $this_object->getImageSize($params);
?>
<div class="qodef-hrl-item-image">
	<?php if ( has_post_thumbnail() ) {
    $image_src = get_the_post_thumbnail_url( get_the_ID() );

    if ( strpos( $image_src, '.gif' ) !== false ) {
        echo get_the_post_thumbnail( get_the_ID(), 'full' );
    } else {
        echo get_the_post_thumbnail( get_the_ID(), $thumb_size );
    }
} else { ?>
    <img itemprop="image" class="qodef-hrl-original-image" width="800" height="600" src="<?php echo IVER_HOTEL_CPT_URL_PATH.'/hotel-room/assets/img/hotel_room_featured_image.jpg'; ?>" alt="<?php esc_attr_e('Hotel Room Featured Image', 'iver-hotel'); ?>" />
<?php } ?>
    <a itemprop="url" class="qodef-hrl-link qodef-block-drag-link" href="<?php echo get_permalink(); ?>"></a>
	<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/featured', '', $params ); ?>
</div>