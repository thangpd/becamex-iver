<?php

namespace IverHotel\CPT\Shortcodes\HotelRoomList;

use IverHotel\Lib;

class HotelRoomList implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'iver_hotel_room_list';

        add_action('vc_before_init', array($this, 'vcMap'));

        //Room List Location filter
        add_filter('vc_autocomplete_iver_hotel_room_list_room_location_callback', array(&$this, 'roomLocationAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Location render
        add_filter('vc_autocomplete_iver_hotel_room_list_room_location_render', array(&$this, 'roomLocationAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)

        //Room List Extra Services filter
        add_filter('vc_autocomplete_iver_hotel_room_list_room_extra_services_callback', array(&$this, 'roomExtraServicesAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Extra Services render
        add_filter('vc_autocomplete_iver_hotel_room_list_room_extra_services_render', array(&$this, 'roomExtraServicesAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)

        //Room List Amenities filter
        add_filter('vc_autocomplete_iver_hotel_room_list_room_amenities_callback', array(&$this, 'roomAmenitiesAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Amenities render
        add_filter('vc_autocomplete_iver_hotel_room_list_room_amenities_render', array(&$this, 'roomAmenitiesAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)


    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(array(
                    'name'                      => esc_html__('Iver Hotel Room List', 'iver-hotel'),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__('by IVER HOTEL', 'iver-hotel'),
                    'icon'                      => 'icon-wpb-hotel-room-list extended-custom-hotel-room-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'type',
                            'heading'     => esc_html__('Type', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Standard', 'iver-hotel') => 'standard',
                                esc_html__('Gallery', 'iver-hotel')  => 'gallery',
                                esc_html__('Divided', 'iver-hotel')  => 'divided',
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'gallery_hover',
                            'heading'     => esc_html__('Hover', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Default', 'iver-hotel')            => 'standard',
                                esc_html__('Slide from bottom ', 'iver-hotel') => 'slide_from_bottom'
                            ),
                            'save_always' => true,
                            'dependency'  => array('element' => 'type', 'value' => array('gallery')),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'boxed_layout',
                            'heading'     => esc_html__('Boxed Layout', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_yes_no_select_array()),
                            'save_always' => true,
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'number_of_columns',
                            'heading'     => esc_html__('Number of Columns', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Default', 'iver-hotel') => '',
                                esc_html__('One', 'iver-hotel')     => '1',
                                esc_html__('Two', 'iver-hotel')     => '2',
                                esc_html__('Three', 'iver-hotel')   => '3',
                                esc_html__('Four', 'iver-hotel')    => '4',
                                esc_html__('Five', 'iver-hotel')    => '5'
                            ),
                            'description' => esc_html__('Default value is Three', 'iver-hotel'),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'space_between_items',
                            'heading'     => esc_html__('Space Between Room', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_space_between_items_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'number_of_items',
                            'heading'     => esc_html__('Number of Rooms Per Page', 'iver-hotel'),
                            'description' => esc_html__('Set number of rooms for your hotel room list. Enter -1 to show all.', 'iver-hotel'),
                            'value'       => '-1'
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'image_proportions',
                            'heading'     => esc_html__('Image Proportions', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Original', 'iver-hotel')  => 'full',
                                esc_html__('Square', 'iver-hotel')    => 'square',
                                esc_html__('Landscape', 'iver-hotel') => 'landscape',
                                esc_html__('Portrait', 'iver-hotel')  => 'portrait',
                                esc_html__('Thumbnail', 'iver-hotel') => 'thumbnail',
                                esc_html__('Medium', 'iver-hotel')    => 'medium',
                                esc_html__('Large', 'iver-hotel')     => 'large'
                            ),
                            'description' => esc_html__('Set image proportions for your hotel room list.', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'autocomplete',
                            'param_name' => 'room_location',
                            'heading'    => esc_html__('Location', 'iver-hotel'),
                            'value'      => array_flip(iver_hotel_get_taxonomy_list('location-tag', true)),
                            'settings'   => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'       => 'autocomplete',
                            'param_name' => 'room_amenities',
                            'heading'    => esc_html__('Amenities', 'iver-hotel'),
                            'value'      => array_flip(iver_hotel_get_taxonomy_list('amenity-tag', true)),
                            'settings'   => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'room_extra_services',
                            'heading'     => esc_html__('Extra Services', 'iver-hotel'),
                            'value'       => array_flip(iver_hotel_get_taxonomy_list('extra-service-tag', true)),
                            'save_always' => true,
                            'settings'    => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'sort_option',
                            'heading'     => esc_html__('Sorting Option', 'iver-hotel'),
                            'value'       => array_flip(iver_hotel_room_get_room_sorting_options()),
                            'description' => esc_html__('Set Sorting Option. This option will overwrite Order By and Order', 'iver-hotel'),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order_by',
                            'heading'     => esc_html__('Order By', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_query_order_by_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order',
                            'heading'     => esc_html__('Order', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_query_order_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading'    => esc_html__('Title Tag', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_title_tag(true)),
                            'group'      => esc_html__('Content Layout', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'title_width',
                            'heading'    => esc_html__('Title Width', 'iver-hotel'),
                            'group'      => esc_html__('Content Layout', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_filter',
                            'heading'    => esc_html__('Enable Filter', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array()),
                            'group'      => esc_html__('Additional Features', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_sort',
                            'heading'    => esc_html__('Enable Sort', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array()),
                            'group'      => esc_html__('Additional Features', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'sort_skin',
                            'heading'    => esc_html__('Sort Skin', 'iver-hotel'),
                            'value'      => array(
                                esc_html__('Default', 'iver-hotel') => '',
                                esc_html__('Light', 'iver-hotel')   => 'light',
                            ),
                            'group'      => esc_html__('Additional Features', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_excerpt',
                            'heading'    => esc_html__('Enable Excerpt', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array(false)),
                            'group'      => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'excerpt_length',
                            'heading'     => esc_html__('Excerpt Length', 'iver-hotel'),
                            'description' => esc_html__('Number of characters', 'iver-hotel'),
                            'dependency'  => array('element' => 'enable_excerpt', 'value' => array('yes')),
                            'group'       => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_price_period',
                            'heading'    => esc_html__('Enable Price Period', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array(false)),
                            'dependency' => array('element' => 'type', 'value' => array('gallery','divided')),
                            'group'      => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'price_period_text',
                            'heading'     => esc_html__('Price Period Text', 'iver-hotel'),
                            'description' => esc_html__('Default: \'Night\'', 'iver-hotel'),
                            'dependency'  => array('element' => 'enable_price_period', 'value' => array('yes')),
                            'group'       => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'pagination_type',
                            'heading'    => esc_html__('Pagination Type', 'iver-hotel'),
                            'value'      => array(
                                esc_html__('None', 'iver-hotel')            => '',
                                esc_html__('Standard', 'iver-hotel')        => 'standard',
                                esc_html__('Load More', 'iver-hotel')       => 'load-more',
                                esc_html__('Infinite Scroll', 'iver-hotel') => 'infinite-scroll'
                            ),
                            'group'      => esc_html__('Additional Features', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'load_more_top_margin',
                            'heading'    => esc_html__('Load More Top Margin (px or %)', 'iver-hotel'),
                            'dependency' => array('element' => 'pagination_type', 'value' => array('load-more')),
                            'group'      => esc_html__('Additional Features', 'iver-hotel')
                        )
                    )
                )
            );
        }
    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     *
     * @return string
     */
    public function render($atts, $content = null) {
        $args = array(
            'type'                   => 'standard',
            'gallery_hover'          => '',
            'boxed_layout'           => 'yes',
            'number_of_columns'      => '3',
            'space_between_items'    => 'tiny',
            'number_of_items'        => '-1',
            'image_proportions'      => 'full',
            'room_location'          => '',
            'room_amenities'         => '',
            'room_extra_services'    => '',
            'room_min_date'          => '',
            'room_max_date'          => '',
            'room_min_price'         => '',
            'room_max_price'         => '',
            'room_adults'            => '',
            'room_children'          => '',
            'room_number_of_rooms'   => '',
            'sort_option'            => '',
            'order_by'               => 'date',
            'order'                  => 'DESC',
            'title_tag'              => 'h5',
            'title_width'            => '',
            'enable_excerpt'         => 'no',
            'excerpt_length'         => '150',
            'enable_price_period'    => 'no',
            'price_period_text'      => 'Night',
            'pagination_type'        => 'no-pagination',
            'load_more_top_margin'   => '',
            'enable_filter'          => 'no',
            'enable_sort'            => 'no',
            'sort_skin'              => '',
            'hotel_room_slider_on'   => 'no',
            'enable_loop'            => 'no',
            'enable_autoplay'        => 'yes',
            'slider_speed'           => '5000',
            'slider_speed_animation' => '600',
            'enable_navigation'      => 'yes',
            'navigation_skin'        => '',
            'enable_pagination'      => 'yes',
            'pagination_skin'        => '',
        );
        $params = shortcode_atts($args, $atts);

        /***
         * @params query_results
         * @params holder_data
         * @params holder_classes
         * @params holder_inner_classes
         */
        $additional_params = array();

        $query_array = $this->getQueryArray($params);
        $query_results = new \WP_Query($query_array);
        $additional_params['query_results'] = $query_results;

        $additional_params['holder_data'] = iver_select_get_holder_data_for_cpt($params, $additional_params);
        $additional_params['holder_classes'] = $this->getHolderClasses($params);
        $additional_params['holder_inner_classes'] = $this->getHolderInnerClasses($params);
        $additional_params['holder_list_classes'] = $this->getListClasses($params);
        $additional_params['holder_sidebar_classes'] = $this->getListSidebar($params);

        $params['this_object'] = $this;

        $html = iver_hotel_get_shortcode_module_template_part('hotel-room', 'hotel-room-list', 'holder', '', $params, $additional_params);

        return $html;
    }

    /**
     * Generates hotel room list query attribute array
     *
     * @param $params
     *
     * @return array
     */

    public function getQueryArray($params) {
        $query_array = array(
            'post_status'    => 'publish',
            'post_type'      => 'hotel-room',
            'posts_per_page' => $params['number_of_items']
        );

        switch ($params['sort_option']) {
            case 'price-low' : {
                $query_array['meta_key'] = 'hotel_room_price';
                $query_array['orderby'] = 'meta_value_num';
                $query_array['order'] = 'ASC';
            }
                break;
            case 'price-high' : {
                $query_array['meta_key'] = 'hotel_room_price';
                $query_array['orderby'] = 'meta_value_num';
                $query_array['order'] = 'DESC';
            }
                break;
            case 'date' : {
                $query_array['orderby'] = 'date';
                $query_array['order'] = 'ASC';
            }
                break;
            case 'name' : {
                $query_array['orderby'] = 'name';
                $query_array['order'] = 'ASC';
            }
                break;
            case 'name-x' : {
                $query_array['orderby'] = 'DESC';
                $query_array['order'] = 'name';
            }
                break;
            default : {
                $query_array['orderby'] = $params['order_by'];
                $query_array['order'] = $params['order'];
            }
                break;
        }

        // TAXONOMY QUERY VALUES
        if (!empty($params['room_location']) || !empty($params['room_amenities']) || !empty($params['room_extra_services'])) {
            $tax_query = array();

            if (!empty($params['room_location'])) {
                $tax_query[] = array(
                    'taxonomy' => 'location-tag',
                    'terms'    => $params['room_location'],
                    'operator' => 'AND',
                );
            }

            if (!empty($params['room_amenities'])) {
                $tax_query[] = array(
                    'taxonomy' => 'amenity-tag',
                    'terms'    => $params['room_amenities'],
                    'operator' => 'AND',
                );
            }

            if (!empty($params['room_extra_services'])) {
                $tax_query[] = array(
                    'taxonomy' => 'extra-service-tag',
                    'terms'    => $params['room_extra_services'],
                    'operator' => 'AND'
                );
            }

            $query_array['tax_query'] = $tax_query;
        }

        // META QUERY VALUES
        if (!empty($params['room_min_price']) || !empty($params['room_max_price']) || !empty($params['room_number_of_rooms'])) {
            $meta_query = array();

            if (!empty($params['room_min_price']) || !empty($params['room_max_price'])) {
                $min_price = 0;
                $max_price = iver_hotel_get_hotel_room_max_price_value();
                if (!empty($params['room_min_price'])) {
                    $min_price = $params['room_min_price'];

                }
                if (!empty($params['room_max_price'])) {
                    $max_price = $params['room_max_price'];
                }
                $meta_query[] = array(
                    'key'     => 'hotel_room_price',
                    'value'   => array($min_price, $max_price),
                    'type'    => 'numeric',
                    'compare' => 'BETWEEN'
                );
            }

            if (!empty($params['room_number_of_rooms'])) {

                $room_number_of_rooms = $params['room_number_of_rooms'];

                $meta_query[] = array(
                    'key'     => 'hotel_room_number',
                    'value'   => $room_number_of_rooms,
                    'type'    => 'numeric',
                    'compare' => '>='
                );
            }

            if (!empty($params['room_adults'])) {

                $room_adults = $params['room_adults'];

                $meta_query[] = array(
                    'key'     => 'hotel_room_capacity_adults',
                    'value'   => $room_adults,
                    'type'    => 'numeric',
                    'compare' => '>='
                );
            }

            if (!empty($params['room_children'])) {

                $room_children = $params['room_children'];

                $meta_query[] = array(
                    'key'     => 'hotel_room_capacity_children',
                    'value'   => $room_children,
                    'type'    => 'numeric',
                    'compare' => '>='
                );
            }

            $query_array['meta_query'] = $meta_query;
        }

        if (!empty($params['next_page'])) {
            $query_array['paged'] = $params['next_page'];
        } else {
            $query_array['paged'] = 1;
        }

        return $query_array;
    }

    /**
     * Generates hotel room holder classes
     *
     * @param $params
     *
     * @return string
     */

    public function getHolderClasses($params) {
        $classes = array();

        $classes[] = !empty($params['type']) ? 'qodef-hrl-' . $params['type'] : 'qodef-hrl-standard';
        $classes[] = $params['sort_skin'] == 'light' ? 'qodef-hrl-sort-light' : '';
        $classes[] = $params['boxed_layout'] == 'yes' ? 'qodef-hrl-boxed-layout' : '';
        $classes[] = !empty($params['navigation_skin']) ? 'qodef-nav-' . $params['navigation_skin'] . '-skin' : '';
        $classes[] = !empty($params['pagination_skin']) ? 'qodef-pag-' . $params['pagination_skin'] . '-skin' : '';

        if ($params['type'] == 'gallery') {
            switch ($params['gallery_hover']) {
                case 'slide_from_bottom' : {
                    $classes[] = 'qodef-hrl-gallery-hover-sfb';
                }
                    break;
                case 'standard' : {
                    $classes[] = 'qodef-hrl-gallery-hover-st';
                }
                    break;
                default : {
                    $classes[] = 'qodef-hrl-gallery-hover-st';
                }
            }

        }
        $classes[] = !empty($params['space_between_items']) ? 'qodef-' . $params['space_between_items'] . '-space' : 'qodef-normal-space';
        $classes[] = !empty($params['enable_filter']) && $params['enable_filter'] == 'yes' ? 'qodef-hrl-with-filter' : '';
        $classes[] = !empty($params['room_location']) ? 'qodef-hrl-location-set' : '';
        $classes[] = !empty($params['room_amenity']) ? 'qodef-hrl-amenity-set' : '';

        $number_of_columns = $params['number_of_columns'];
        switch ($number_of_columns):
            case '1':
                $classes[] = 'qodef-hrl-one-column';
                break;
            case '2':
                $classes[] = 'qodef-hrl-two-columns';
                break;
            case '3':
                $classes[] = 'qodef-hrl-three-columns';
                break;
            case '4':
                $classes[] = 'qodef-hrl-four-columns';
                break;
            case '5':
                $classes[] = 'qodef-hrl-five-columns';
                break;
            default:
                $classes[] = 'qodef-hrl-three-columns';
                break;
        endswitch;

        $classes[] = !empty($params['pagination_type']) ? 'qodef-hrl-pag-' . $params['pagination_type'] : '';

        return implode(' ', $classes);
    }


    /**
     * Return classes for content holder when sidebar is active
     *
     * @param $params
     *
     * @return string
     */
    public function getListClasses($params) {

        $content_class = array();

        if ($params['enable_filter'] == 'yes') {
            $content_class[] = 'qodef-grid-col-9';
        } else {
            $content_class[] = 'qodef-grid-col-12';
        }

        return implode(' ', $content_class);
    }

    /**
     * Return classes for sidebar holder when sidebar is active
     *
     * @param $params
     *
     * @return string
     */
    public function getListSidebar($params) {

        $sidebar_class = array();

        if ($params['enable_filter'] == 'yes') {
            $sidebar_class[] = 'qodef-grid-col-3';
        }

        return implode(' ', $sidebar_class);
    }


    /**
     * Generates hotel room holder inner classes
     *
     * @param $params
     *
     * @return string
     */

    public function getHolderInnerClasses($params) {
        $classes = array();

        $classes[] = 'qodef-outer-space';

        $classes[] = $params['hotel_room_slider_on'] === 'yes' ? 'qodef-owl-slider qodef-hrl-is-slider' : '';

        return implode(' ', $classes);
    }


    /**
     * Generates hotel room article classes
     *
     *
     * @return string
     */

    public function getArticleClasses($params) {
        $classes = array();

        $classes[] = 'qodef-item-space';

        $item_featured = get_post_meta(get_the_ID(), 'iver_hotel_room_is_featured_meta', true);
        $classes[] = !empty($item_featured) && $item_featured === 'yes' ? 'qodef-item-featured' : '';

        $article_classes = get_post_class($classes);

        return implode(' ', $article_classes);
    }


    /**
     * Generates hotel room image size
     *
     * @param $params
     *
     * @return string
     */

    public function getImageSize($params) {
        $thumb_size = 'full';

        if (!empty($params['image_proportions'])) {
            $image_size = $params['image_proportions'];

            switch ($image_size) {
                case 'landscape':
                    $thumb_size = 'iver_select_landscape';
                    break;
                case 'portrait':
                    $thumb_size = 'iver_select_portrait';
                    break;
                case 'square':
                    $thumb_size = 'iver_select_square';
                    break;
                case 'thumbnail':
                    $thumb_size = 'thumbnail';
                    break;
                case 'medium':
                    $thumb_size = 'medium';
                    break;
                case 'large':
                    $thumb_size = 'large';
                    break;
                case 'full':
                    $thumb_size = 'full';
                    break;
            }
        }

        return $thumb_size;
    }

    /**
     * Returns array of load more element styles
     *
     * @param $params
     *
     * @return array
     */

    public function getLoadMoreStyles($params) {
        $styles = array();

        if (!empty($params['load_more_top_margin'])) {
            $margin = $params['load_more_top_margin'];

            if (iver_select_string_ends_with($margin, '%') || iver_select_string_ends_with($margin, 'px')) {
                $styles[] = 'margin-top: ' . $margin;
            } else {
                $styles[] = 'margin-top: ' . iver_select_filter_px($margin) . 'px';
            }
        }

        return implode(';', $styles);
    }

    /**
     * Returns array of title element styles
     *
     * @param $params
     *
     * @return array
     */

    public function getTitleStyles($params) {
        $styles = array();

        if (!empty($params['title_width'])) {
            $width = $params['title_width'];

            if (iver_select_string_ends_with($width, '%') || iver_select_string_ends_with($width, 'px')) {
                $styles[] = 'max-width: ' . $width;
            } else {
                $styles[] = 'max-width: ' . iver_select_filter_px($width) . 'px';
            }
        }

        return implode(';', $styles);
    }


    /**
     * Filter room list location
     *
     * @param $query
     *
     * @return array
     */
    public function roomLocationAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_location_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'location-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_location_title']) > 0) ? esc_html__('Location', 'iver-hotel') . ': ' . $value['room_location_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list location by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomLocationAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room location
            $room_location = get_term_by('slug', $query, 'location-tag');
            if (is_object($room_location)) {

                $room_location_slug = $room_location->slug;
                $room_location_title = $room_location->name;

                $room_location_title_display = '';
                if (!empty($room_location_title)) {
                    $room_location_title_display = esc_html__('Location', 'iver-hotel') . ': ' . $room_location_title;
                }

                $data = array();
                $data['value'] = $room_location_slug;
                $data['label'] = $room_location_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

    /**
     * Filter room list extra service
     *
     * @param $query
     *
     * @return array
     */
    public function roomExtraServicesAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_extra_service_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'extra-service-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_extra_service_title']) > 0) ? esc_html__('Extra Service', 'iver-hotel') . ': ' . $value['room_extra_service_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list extra service by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomExtraServicesAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room extra service
            $room_extra_service = get_term_by('slug', $query, 'extra-service-tag');
            if (is_object($room_extra_service)) {

                $room_extra_service_slug = $room_extra_service->slug;
                $room_extra_service_title = $room_extra_service->name;

                $room_extra_service_title_display = '';
                if (!empty($room_extra_service_title)) {
                    $room_extra_service_title_display = esc_html__('Extra Service', 'iver-hotel') . ': ' . $room_extra_service_title;
                }

                $data = array();
                $data['value'] = $room_extra_service_slug;
                $data['label'] = $room_extra_service_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

    /**
     * Filter room list amenity
     *
     * @param $query
     *
     * @return array
     */
    public function roomAmenitiesAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_amenity_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'amenity-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_amenity_title']) > 0) ? esc_html__('Amenity', 'iver-hotel') . ': ' . $value['room_amenity_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list amenity by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomAmenitiesAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room amenity
            $room_amenity = get_term_by('slug', $query, 'amenity-tag');
            if (is_object($room_amenity)) {

                $room_amenity_slug = $room_amenity->slug;
                $room_amenity_title = $room_amenity->name;

                $room_amenity_title_display = '';
                if (!empty($room_amenity_title)) {
                    $room_amenity_title_display = esc_html__('Amenity', 'iver-hotel') . ': ' . $room_amenity_title;
                }

                $data = array();
                $data['value'] = $room_amenity_slug;
                $data['label'] = $room_amenity_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

}