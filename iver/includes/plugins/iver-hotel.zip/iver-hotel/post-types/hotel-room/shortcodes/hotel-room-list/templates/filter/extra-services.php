<?php
$extra_service_set   = isset( $params['amenity-tag'] ) && $params['amenity-tag'] !== '';
$extra_services      = iver_hotel_get_taxonomy_list( 'extra-service-tag' );
$room_extra_services = explode( ',', $room_extra_services );
?>
<div class="qodef-filter-section qodef-section-extra-services">
    <div class="qodef-filter-extra-services-holder">
        <div class="qodef-filter-extra-services-wrapper clearfix">
			<?php foreach ( $extra_services as $key => $extra_service ) { ?>
                <div class="qodef-extra-service-item">
                    <input type="checkbox" <?php echo ! empty( $room_extra_services ) && in_array( $key, $room_extra_services ) ? 'checked' : ''; ?>
                           data-id="<?php echo esc_attr( $key ); ?>"
                           id="qodef-extra-service-<?php echo esc_attr( $key ); ?>" name="qodef-extra-services[]" value=""/>
                    <label class="qodef-checkbox-label" for="qodef-extra-service-<?php echo esc_attr( $key ); ?>">
                        <span class="qodef-label-view"></span>
                        <span class="qodef-label-text">
                            <?php echo esc_html( $extra_service ); ?>
                        </span>
                    </label>
                </div>
			<?php } ?>
        </div>
    </div>
</div>