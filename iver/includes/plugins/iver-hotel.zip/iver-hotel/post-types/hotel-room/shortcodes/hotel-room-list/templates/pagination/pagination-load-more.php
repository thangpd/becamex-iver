<?php
if ( $query_results->max_num_pages > 1 ) {
	$holder_styles = $this_object->getLoadMoreStyles( $params );
	?>
    <div class="qodef-hrl-pagination-holder">
        <div class="qodef-hrl-load-more-holder">
            <div class="qodef-hrl-load-more" <?php iver_select_inline_style( $holder_styles ); ?>>
				<?php
				if ( iver_select_core_plugin_installed() ) {
					echo iver_select_get_button_html( array(
						'link' => 'javascript: void(0)',
						'size' => 'large',
						'text' => esc_html__( 'Load more', 'iver-hotel' )
					) );
				} else { ?>
                    <a itemprop="url" class="qodef-btn qodef-btn-medium qodef-btn-solid" href="<?php echo esc_url( get_the_permalink() ); ?>">
                        <span class="qodef-btn-text"><?php echo esc_html__( 'Load more', 'iver-hotel' ); ?></span>
                    </a>
				<?php } ?>
            </div>
        </div>
    </div>
<?php }