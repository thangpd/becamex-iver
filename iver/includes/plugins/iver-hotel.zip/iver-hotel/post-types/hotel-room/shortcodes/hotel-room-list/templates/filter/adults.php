<?php
$max_adults = iver_hotel_get_hotel_room_adults();
?>
<?php if ( $max_adults != '' ) { ?>
    <div class="qodef-filter-section qodef-filter-section-12 qodef-section-adults">
        <div class="qodef-filter-adults-count-holder" data-adults="<?php echo esc_attr($params['room_adults']) ?>">
            <label for="qodef-filter-adults"><?php esc_html_e( 'adults', 'iver-hotel' ) ?></label>
            <select id="qodef-filter-adults" name="qodef-filter-adults" class="qodef-filter-adults">
                <option value="0">0</option>
	            <?php for ( $i = 1; $i <= $max_adults; $i ++ ) { ?>
                    <option <?php echo (esc_attr($params['room_adults']) == $i) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	            <?php } ?>
            </select>
        </div>
    </div>
<?php } ?>