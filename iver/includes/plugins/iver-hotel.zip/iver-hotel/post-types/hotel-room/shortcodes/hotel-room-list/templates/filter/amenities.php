<?php
$amenities      = iver_hotel_get_taxonomy_list( 'amenity-tag' );
$room_amenities = explode( ',', $room_amenities );
?>
<div class="qodef-filter-section qodef-section-amenities">
    <div class="qodef-filter-amenities-holder">
        <div class="qodef-filter-amenities-wrapper clearfix">
			<?php foreach ( $amenities as $key => $amenity ) { ?>
                <div class="qodef-amenity-item">
                    <input type="checkbox" <?php echo ! empty( $room_amenities ) && in_array( $key, $room_amenities ) ? 'checked' : ''; ?>
                           data-id="<?php echo esc_attr( $key ); ?>" id="qodef-amenity-<?php echo esc_attr( $key ); ?>"
                           name="qodef-amenities[]" value=""/>
                    <label class="qodef-checkbox-label" for="qodef-amenity-<?php echo esc_attr( $key ); ?>">
                        <span class="qodef-label-view"></span>
                        <span class="qodef-label-text">
                            <?php echo esc_html( $amenity ); ?>
                        </span>
                    </label>
                </div>
			<?php } ?>
        </div>
    </div>
</div>