<?php extract( apply_filters( 'iver_select_hotel_single_location_params', array() ) ); ?>
<div class="qodef-hrl-address">
    <span class="qodef-hrl-city">
	    <?php if ( $location != '' ) { ?>
            <a href="<?php echo get_term_link( $location->term_id ); ?>">
				<?php echo esc_html( $location->name ); ?>
			</a>
	    <?php } ?>
    </span>
    <span class="qodef-hrl-dash">&ndash;</span>
	<?php if ( isset( $location ) && ( $location != '' ) ) { ?>
        <span class="qodef-hrl-city"><?php echo esc_html( $full_address ); ?></span>
	<?php }
	if ( isset( $simple_address ) && ( $simple_address != '' ) ) { ?>
        <span class="qodef-hrl-city"><?php echo esc_html( $simple_address ); ?></span>
	<?php }
	if ( isset( $country ) && ( $country != '' ) ) { ?>
        <span class="qodef-hrl-city"><?php echo esc_html( $country ); ?></span>
	<?php }
	if ( isset( $zip_code ) && ( $zip_code != '' ) ) { ?>
        <span class="qodef-hrl-city"><?php echo esc_html( $zip_code ); ?></span>
	<?php } ?>
</div>