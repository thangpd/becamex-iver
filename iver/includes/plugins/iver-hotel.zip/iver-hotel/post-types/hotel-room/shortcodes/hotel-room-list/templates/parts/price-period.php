<?php if ( $price_period_text != '' ) { ?>
    <span class="qodef-hrl-price-period"><?php echo esc_html($price_period_text) ?></span>
<?php }
