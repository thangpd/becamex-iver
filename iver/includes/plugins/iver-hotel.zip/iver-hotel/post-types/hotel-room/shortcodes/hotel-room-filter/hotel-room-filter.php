<?php

namespace IverHotel\CPT\Shortcodes\HotelRoomFilter;

use IverHotel\Lib;

class HotelRoomFilter implements Lib\ShortcodeInterface {
	private $base;

	public function __construct() {
		$this->base = 'iver_hotel_room_filter';

		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map( array(
				'name'                      => esc_html__( 'Iver Hotel Filter', 'iver-hotel' ),
				'base'                      => $this->base,
				'category'                  => esc_html__( 'by IVER HOTEL', 'iver-hotel' ),
				'icon'                      => 'icon-wpb-hotel-room-filters extended-custom-hotel-room-icon',
				'allowed_container_element' => 'vc_row',
				'params'                    => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Skin', 'iver-hotel' ),
						'param_name' => 'type',
						'value'      => array(
							esc_html__( 'Stripe', 'iver-hotel' ) => 'stripe',
							esc_html__( 'Box', 'iver-hotel' )   => 'box'
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Skin', 'iver-hotel' ),
						'param_name' => 'filter_skin',
						'value'      => array(
							esc_html__( 'Default', 'iver-hotel' ) => '',
							esc_html__( 'Light', 'iver-hotel' )   => 'light'
						),
					),
					array(
						'type'       => 'colorpicker',
						'param_name' => 'filter_background_color',
						'heading'    => esc_html__( 'Background Color', 'iver-hotel' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Filter Width', 'iver-hotel' ),
						'param_name' => 'filter_grid',
						'value'      => array(
							esc_html__( 'Full Width', 'iver-hotel' ) => 'full-width',
							esc_html__( 'Full Width Only Background', 'iver-hotel' )  => 'full-width-bckg',
							esc_html__( 'In Grid', 'iver-hotel' )  => 'grid'
						),
						'dependency' => array( 'element' => 'type', 'value' => array('stripe') )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Bottom Border', 'iver-hotel' ),
						'param_name' => 'filter_border',
						'value'      => array(
							esc_html__( 'No', 'iver-hotel' ) => '',
							esc_html__( 'Solid', 'iver-hotel' )   => 'border',
							esc_html__( 'Shadow', 'iver-hotel' )  => 'shadow',
						)
					),
					array(
						'type'       => 'colorpicker',
						'param_name' => 'filter_border_color',
						'heading'    => esc_html__( 'Border Color', 'iver-hotel' ),
						'dependency' => array( 'element' => 'filter_border', 'value' => array('border') )
					),
				)
			) );
		}
	}

	public function render( $atts, $content = null ) {
		$args = array(
			'type'                      => 'stripe',
			'filter_skin'               => '',
			'filter_background_color'   => '',
			'filter_grid'               => 'full-width',
			'filter_border'             => '',
			'filter_border_color'       => '',
		);

		$params = shortcode_atts( $args, $atts );

		$params['holder_classes'] = $this->getHolderClasses( $params );
		$params['holder_style'] = $this->getHolderStyles( $params );
		$params['inner_style'] = $this->getInnerStyles( $params );

		$params = $this->getParams($params);

		$html = iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-filter', 'hotel-filters', $params['type'], $params);
		return $html;
	}

	/**
	 * Generates hotel room holder classes
	 *
	 * @param $params
	 *
	 * @return string
	 */

	public function getHolderClasses( $params ) {
		$classes = array();

		$classes[] = 'qodef-hotel-filter-holder';

		$classes[] = $params['type'] != '' ? 'qodef-hrf-type-' . $params['type'] : 'qodef-hrf-type-stripe';

		if ( $params['filter_skin'] !== '' ) {
			$classes[] = 'qodef-hotel-filter-skin-' . $params['filter_skin'];
		}

		if ( $params['filter_grid'] != '' ) {
			$classes[] = 'qodef-hotel-' . $params['filter_grid'] . '-filter';
		}

		if ( $params['filter_border'] !== '' ) {
			$classes[] = 'qodef-hotel-filter-' . $params['filter_border'];
		}

        if ( ! empty( $params['filter_background_color'] ) ) {
            $classes[] = 'qodef-hotel-filter-background';
        }

		return implode( ' ', $classes );
	}

	private function getHolderStyles( $params ) {
		$itemStyle = array();

		if ( $params['filter_grid'] === 'full-width-bckg' || $params['filter_grid'] === 'full-width' || $params['type'] === 'box') {

			if ( ! empty( $params['filter_background_color'] ) ) {
				$itemStyle[] = 'background-color: ' . $params['filter_background_color'];
			}

			if ( ! empty( $params['filter_border_color'] ) ) {
				$itemStyle[] = 'border-color: ' . $params['filter_border_color'];
			}
		}

		return implode( ';', $itemStyle );
	}

	private function getInnerStyles( $params ) {
		$itemStyle = array();

		if ( $params['filter_grid'] === 'grid') {

			if ( ! empty( $params['filter_background_color'] ) ) {
				$itemStyle[] = 'background-color: ' . $params['filter_background_color'];
			}

			if ( ! empty( $params['filter_border_color'] ) ) {
				$itemStyle[] = 'border-bottom-color: ' . $params['filter_border_color'];
			}
		}

		return implode( ';', $itemStyle );
	}


	private function getParams( $params ) {

		$params['today'] = date('Y-m-d');
		$params['tomorrow'] = date('Y-m-d', mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));

		$params['number_of_rooms'] = iver_hotel_get_hotel_room_max_rooms();
		$params['locations'] = iver_hotel_room_get_locations();
		$params['adults'] = iver_hotel_get_hotel_room_adults();
		$params['children'] = iver_hotel_get_hotel_room_max_children();

		return $params;
	}
}