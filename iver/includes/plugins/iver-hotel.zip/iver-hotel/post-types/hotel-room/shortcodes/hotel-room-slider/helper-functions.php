<?php

if ( ! function_exists( 'iver_hotel_room_hotel_room_slider_shortcode_helper' ) ) {
	function iver_hotel_room_hotel_room_slider_shortcode_helper( $shortcodes_class_name ) {
		$shortcodes = array(
			'IverHotel\CPT\Shortcodes\HotelRoomSlider\HotelRoomSlider'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'iver_hotel_add_vc_shortcode', 'iver_hotel_room_hotel_room_slider_shortcode_helper' );
}

if ( ! function_exists( 'iver_hotel_room_set_hotel_room_slider_icon_class_name_for_vc_shortcodes' ) ) {
	/**
	 * Function that set custom icon class name for hotel room slider shortcode to set our icon for Visual Composer shortcodes panel
	 */
	function iver_hotel_room_set_hotel_room_slider_icon_class_name_for_vc_shortcodes( $shortcodes_icon_class_array ) {
		$shortcodes_icon_class_array[] = '.icon-wpb-hotel-room-slider';
		
		return $shortcodes_icon_class_array;
	}
	
	add_filter( 'iver_hotel_filter_add_vc_shortcodes_custom_icon_class', 'iver_hotel_room_set_hotel_room_slider_icon_class_name_for_vc_shortcodes' );
}