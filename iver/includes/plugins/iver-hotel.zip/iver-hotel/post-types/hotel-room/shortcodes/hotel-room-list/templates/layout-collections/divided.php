<div class="qodef-item-holder">
    <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/image', '', $params ); ?>
    <div class="qodef-hrl-item-content">
        <div class="qodef-hrl-item-content-holder">
            <div class="qodef-hrl-item-content-inner">
                <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/price' ); ?>
                <?php if($enable_price_period == 'yes') : ?>
                    <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/price-period', '', $params); ?>
                <?php endif; ?>
                <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/title', '', $params ); ?>
				<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/excerpt', '', $params ); ?>
				<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/read-more' ); ?>
            </div>
        </div>
    </div>
</div>
