<div class="<?php echo esc_attr( $holder_classes ) ?>" <?php echo iver_select_get_inline_style( $holder_style ) ?>>
    <?php if ($filter_grid == 'grid' || $filter_grid == 'full-width-bckg') { ?>
    <div class="qodef-grid">
    <?php } ?>
        <div class="qodef-hotel-filters" <?php echo iver_select_get_inline_style( $inner_style ) ?>>
            <form action="<?php echo esc_url( iver_hotel_room_get_search_page_url() ); ?>" method="GET">
                <div class="qodef-hotel-filters-inner clearfix">
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-min-date">
                            <label><?php esc_html_e('Check-in', 'iver-hotel' ); ?></label>
                            <input type="text" class="qodef-filter-min-date" name="min_date" placeholder="<?php esc_attr_e( 'Select', 'iver-hotel' ) ?>" value=""/>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-max-date">
                            <label><?php esc_html_e('Check-out', 'iver-hotel' ); ?></label>
                            <input type="text" class="qodef-filter-max-date" name="max_date" placeholder="<?php esc_attr_e( 'Select', 'iver-hotel' ) ?>" value=""/>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-rooms-number">
                            <label><?php esc_html_e('Rooms', 'iver-hotel' ); ?></label>
                            <select name="rooms_number" class="qodef-filter-rooms-number">
                            <?php for ( $i = 1; $i <= $number_of_rooms; $i ++ ) { ?>
                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                            <?php } ?>
                            </select>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-location">
                            <label><?php esc_html_e('Location', 'iver-hotel' ); ?></label>
                            <select name="location" class="qodef-filter-location">
	                            <?php foreach ( $locations as $key => $location ) { ?>
                                    <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $location ); ?></option>
	                            <?php } ?>
                            </select>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-adults">
                            <label><?php esc_html_e('Adults', 'iver-hotel' ); ?></label>
                            <select name="adults" class="qodef-filter-adults">
                                <option selected value="0">0</option>
	                            <?php for ( $i = 1; $i <= $adults; $i ++ ) { ?>
	                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	                            <?php } ?>
                            </select>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell">
                        <span class="qodef-input-children">
                            <label><?php esc_html_e('Children', 'iver-hotel' ); ?></label>
                            <select name="children" class="qodef-filter-children">
                                <option selected value="0">0</option>
	                            <?php for ( $i = 1; $i <= $children; $i ++ ) { ?>
	                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	                            <?php } ?>
                            </select>
                        </span>
                    </div>
                    <div class="qodef-hotel-filters-cell qodef-hotel-room-filter-button-holder">
                        <?php
                        echo iver_select_get_button_html( array(
                            'custom_class' => 'qodef-hotel-room-filter-button',
                            'html_type'    => 'button',
                            'size'         => 'medium',
                            'type'         => 'solid',
                            'text'         => esc_html__( 'Book Now', 'iver-hotel' )
                        ) );
                        ?>
                    </div>
	                <?php if ( iver_hotel_is_wpml_installed() ) { ?>
		                <?php
		                $lang = ICL_LANGUAGE_CODE;
		                ?>
                        <input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>">
	                <?php } ?>
                </div>
            </form>
        </div>
    <?php if ($filter_grid == 'grid' || $filter_grid == 'full-width-bckg') { ?>
    </div>
    <?php } ?>
</div>