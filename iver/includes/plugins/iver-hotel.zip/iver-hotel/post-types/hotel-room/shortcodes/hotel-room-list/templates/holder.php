<div class="qodef-hrl-holder <?php echo esc_attr( $holder_classes ); ?>" <?php echo wp_kses( $holder_data, array( 'data' ) ); ?>>
	<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'sort/sort', '', $params, $additional_params ); ?>

    <?php if($hotel_room_slider_on == 'no') : ?>
        <div class="qodef-hrl-items-part-holder">
            <div class="qodef-grid-row qodef-grid-small-gutter">
                <div class="qodef-hrl-items-part <?php echo esc_attr( $holder_list_classes ) ?>">
    <?php endif; ?>
                    <div class="qodef-hrl-inner <?php echo esc_attr( $holder_inner_classes ); ?> clearfix">
                        <?php
                        if ( $query_results->have_posts() ):
                            while ( $query_results->have_posts() ) : $query_results->the_post();
                                echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'item', '', $params, $additional_params );
                            endwhile;
                        else:
                            echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/posts-not-found' );
                        endif;

                        wp_reset_postdata();
                        ?>
                    </div>
    <?php if($hotel_room_slider_on == 'no') : ?>

                <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/loader', '', $params, $additional_params ); ?>
                <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'pagination/pagination', $pagination_type, $params, $additional_params ); ?>
                </div>
                <?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/holder', '', $params, $additional_params ); ?>
            </div>
        </div>
    <?php endif; ?>
</div>