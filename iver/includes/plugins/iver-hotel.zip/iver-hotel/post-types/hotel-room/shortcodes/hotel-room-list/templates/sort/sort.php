<?php  if(isset($params['enable_sort']) && $params['enable_sort'] === 'yes') { ?>
	<div class="qodef-hrl-sort-part">
        <div class="qodef-hrl-sort-part-inner">
            <?php
            foreach (iver_hotel_room_get_room_sorting_options() as $key => $value) { ?>
                <div class="qodef-hrl-sort-item <?php if($sort_option == $key) echo 'qodef-hrl-sort-active' ?>" data-sort="<?php echo esc_attr($key) ?>">
                    <span><?php echo esc_html($value) ?></span>
                </div>
            <?php }

            ?>
        </div>
	</div>
<?php } ?>