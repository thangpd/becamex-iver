<?php
if ( $query_results->max_num_pages > 1 ) { ?>
    <div class="qodef-hrl-pagination-holder">
		<?php
		$pages = $query_results->max_num_pages;
		$paged = $query_results->query['paged'];

		if ( $pages > 1 ) { ?>
            <div class="qodef-hrl-standard-pagination">
                <ul>
                    <li class="qodef-hrl-pag-prev">
                        <a href="#" data-paged="1"><span class="ion-chevron-left"></span></a>
                    </li>
					<?php for ( $i = 1; $i <= $pages; $i ++ ) { ?>
						<?php
						$active_class = '';
						if ( $paged == $i ) {
							$active_class = 'qodef-hrl-pag-active';
						}
						?>
                        <li class="qodef-hrl-pag-number <?php echo esc_attr( $active_class ); ?>">
                            <a href="#" data-paged="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?></a>
                        </li>
					<?php } ?>
                    <li class="qodef-hrl-pag-next">
                        <a href="#" data-paged="2"><span class="ion-chevron-right"></span></a>
                    </li>
                </ul>
            </div>
		<?php }
		?>
    </div>
<?php }