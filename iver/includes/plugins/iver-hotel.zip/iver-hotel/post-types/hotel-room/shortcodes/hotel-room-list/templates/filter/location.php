<?php
$locations = iver_hotel_get_taxonomy_list( 'location-tag' );
?>

<div class="qodef-filter-section qodef-section-location">
    <div class="qodef-filter-location-holder" data-location="<?php echo esc_attr( $params['room_location'] ) ?>">
        <label for="qodef-filter-location"><?php esc_html_e( 'Choose a location', 'iver-hotel' ) ?></label>
        <select id="qodef-filter-location" name="qodef-filter-location" class="qodef-filter-location">
            <option value=""><?php esc_html_e( 'All', 'iver-hotel' ) ?></option>
			<?php foreach ( $locations as $key => $location ) { ?>
                <option <?php echo ( $params['room_location'] == $key ) ? 'selected' : ''; ?>
                        value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $location ); ?></option>
			<?php } ?>
        </select>
    </div>
</div>
