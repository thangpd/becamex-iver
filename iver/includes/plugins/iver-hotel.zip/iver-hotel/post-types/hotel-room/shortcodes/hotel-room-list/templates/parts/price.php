<?php extract( apply_filters( 'iver_select_hotel_single_price_params', array() ) ); ?>
<?php if ( $price ) { ?>
    <span class="qodef-hrl-price">
    <span class="qodef-hrl-price-currency"><?php echo esc_attr( $currency ) ?></span><span><?php echo esc_attr( $price ) ?></span>
    </span>
<?php }
