<?php if ( isset( $params['enable_filter'] ) && $params['enable_filter'] === 'yes' ) { ?>
    <div class="qodef-hrl-filter-part <?php echo esc_attr( $holder_sidebar_classes ) ?>">

        <div class="qodef-filter-row">
            <h3>
                <?php esc_html_e( 'Your Reservation', 'iver-hotel' ); ?>
            </h3>

			<?php
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/date', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/location', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/room-count', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/adults', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/children', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/price-range', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/amenities', '', $params );
			echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/button', '', $params );
			?>
        </div>
    </div>
<?php } ?>