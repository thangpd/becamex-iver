<?php
$min_price = isset($room_min_price) && !empty($room_min_price) ? $room_min_price : 0;
$max_price = isset($room_max_price) && !empty($room_max_price) ? $room_max_price : iver_hotel_get_hotel_room_max_price_value();
$currency = iver_hotel_room_get_currency();
?>
<div class="qodef-filter-section qodef-section-price">
    <div class="qodef-filter-price-holder" data-currency="<?php echo esc_attr($currency) ?>" data-max-price-setting="<?php echo esc_attr(iver_hotel_get_hotel_room_max_price_value()); ?>">
        <div class="qodef-range-slider-response-holder">
            <label><?php esc_html_e('Price filter', 'iver-hotel'); ?></label>
        </div>
        <div class="qodef-range-slider-wrapper">
            <div class="qodef-range-slider"></div>
        </div>
        <div class="qodef-range-slider-price-holder">
            <span id="qodef-min-price-value" data-min-price="<?php echo esc_attr($min_price); ?>"><?php echo esc_attr($currency) . esc_html($min_price); ?></span>
            <span id="qodef-max-price-mark"> - </span>
            <span id="qodef-max-price-value" data-max-price="<?php echo esc_attr($max_price); ?>"><?php echo esc_attr($currency) . esc_html($max_price); ?></span>
        </div>
    </div>
</div>