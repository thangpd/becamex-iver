<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/image', '', $params ); ?>
<div class="qodef-hrl-item-content">
	<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/title', '', $params ); ?>
	<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/price'); ?>
	<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/excerpt', '', $params ); ?>
</div>