<div class="qodef-filter-section qodef-section-date">
    <div class="qodef-filter-date-holder" data-date-min="<?php echo esc_attr($room_min_date); ?>" data-date-max="<?php echo esc_attr($room_max_date); ?>">
        <div class="qodef-inputs-holder clearfix">
            <span class="qodef-input-min-size">
                <label><?php esc_html_e('Check In', 'iver-hotel') ?></label>
                <input type="text" class="qodef-min-date" name="qodef-min-date" placeholder="<?php esc_attr_e('Select', 'iver-hotel') ?>" value="<?php echo esc_attr($room_min_date); ?>" data-min-date="" />
            </span>
            <span class="qodef-input-max-size">
                <label><?php esc_html_e('Check Out', 'iver-hotel') ?></label>
                <input type="text" class="qodef-max-date" name="qodef-max-date" placeholder="<?php esc_attr_e('Select', 'iver-hotel') ?>" value="<?php echo esc_attr($room_max_date); ?>" data-max-date="" />
            </span>
        </div>
    </div>
</div>