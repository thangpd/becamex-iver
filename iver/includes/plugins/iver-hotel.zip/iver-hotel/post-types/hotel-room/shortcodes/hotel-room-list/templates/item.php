<?php
if ( ( iver_hotel_room_check_availability( $params )['flag'] )) { ?>
    <article class="qodef-hrl-item <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>">
        <div class="qodef-hrl-item-inner">
			<?php echo iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'layout-collections/' . $type, '', $params ); ?>
        </div>
    </article>
<?php } ?>