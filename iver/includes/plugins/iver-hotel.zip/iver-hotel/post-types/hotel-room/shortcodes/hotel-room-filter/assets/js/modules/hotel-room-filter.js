(function($) {
    'use strict';

    var hotelRoomFilter = {};
    qodef.modules.hotelRoomFilter = hotelRoomFilter;

    hotelRoomFilter.qodefOnDocumentReady = qodefOnDocumentReady;

    $(document).ready(qodefOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
        qodefInitHotelRoomFilter();
    }

    function qodefInitHotelRoomFilter() {
        var filters = $('.qodef-hotel-filters');
        
        if (filters.length) {
            filters.each(function () {
                var filter = $(this),
                    roomNumber = filter.find('.qodef-filter-rooms-number'),
                    location = filter.find('.qodef-filter-location'),
                    adults = filter.find('.qodef-filter-adults'),
                    children = filter.find('.qodef-filter-children'),
                    minDate = filter.find('.qodef-filter-min-date'),
                    maxDate = filter.find('.qodef-filter-max-date');

                //INIT ROOMS FIELD

                var selectRoomNumber = roomNumber;
                if (selectRoomNumber.length) {
                    selectRoomNumber.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT LOCATION FIELD

                var selectLocation = location;
                if (selectLocation.length) {
                    selectLocation.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectAdults = adults;
                if (selectAdults.length) {
                    selectAdults.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectChildren = children;
                if (selectChildren.length) {
                    selectChildren.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT DATE CHECK-IN FIELD
                if (minDate.length) {
                    minDate.datepicker({
                        minDate: '0',
                        dateFormat: 'yy-mm-dd'
                    });
                }

                //INIT DATE CHECK-OUT FIELD
                if (maxDate.length) {
                    maxDate.datepicker({
                        minDate: '+1d',
                        dateFormat: 'yy-mm-dd'
                    });
                }
            });
        }
    }

})(jQuery);