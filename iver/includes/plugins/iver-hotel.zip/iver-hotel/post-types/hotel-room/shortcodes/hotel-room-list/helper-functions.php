<?php
if(!function_exists('iver_hotel_room_hotel_room_list_shortcode_helper')) {
    function iver_hotel_room_hotel_room_list_shortcode_helper($shortcodes_class_name) {
        $shortcodes = array(
            'IverHotel\CPT\Shortcodes\HotelRoomList\HotelRoomList'
        );

        $shortcodes_class_name = array_merge($shortcodes_class_name, $shortcodes);

        return $shortcodes_class_name;
    }

    add_filter('iver_hotel_add_vc_shortcode', 'iver_hotel_room_hotel_room_list_shortcode_helper');
}

if( !function_exists('iver_hotel_room_set_hotel_room_list_icon_class_name_for_vc_shortcodes') ) {
    /**
     * Function that set custom icon class name for hotel room list shortcode to set our icon for Visual Composer shortcodes panel
     */
    function iver_hotel_room_set_hotel_room_list_icon_class_name_for_vc_shortcodes($shortcodes_icon_class_array) {
        $shortcodes_icon_class_array[] = '.icon-wpb-hotel-room-list';

        return $shortcodes_icon_class_array;
    }

    add_filter('iver_hotel_filter_add_vc_shortcodes_custom_icon_class', 'iver_hotel_room_set_hotel_room_list_icon_class_name_for_vc_shortcodes');
}

if( !function_exists('iver_hotel_room_hrl_ajax_load_more') ) {
	/**
	 * Function that is called after via filter or pagination
	 */
	function iver_hotel_room_hrl_ajax_load_more() {


        $shortcode_params = array();
        $additional_params = array();

        if ( ! empty( $_POST ) ) {
            foreach ( $_POST as $key => $value ) {
                if ( $key !== '' ) {
                    $addUnderscoreBeforeCapitalLetter = preg_replace( '/([A-Z])/', '_$1', $key );
                    $setAllLettersToLowercase         = strtolower( $addUnderscoreBeforeCapitalLetter );

                    $shortcode_params[ $setAllLettersToLowercase ] = $value;
                }
            }
        }


        $hotel_room_list = new \IverHotel\CPT\Shortcodes\HotelRoomList\HotelRoomList();

        $query_array                        = $hotel_room_list->getQueryArray( $shortcode_params );
        $query_results                      = new \WP_Query( $query_array );
        $additional_params['query_results'] = $query_results;
        $shortcode_params['this_object']    = $hotel_room_list;



        $html = '';


        if ( $query_results->have_posts() ):
            while ( $query_results->have_posts() ) : $query_results->the_post();
                $html .= iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'item', '', $shortcode_params, $additional_params );
            endwhile;
        else:
            $html .= iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/posts-not-found', '', $shortcode_params, $additional_params );
        endif;

        wp_reset_postdata();

		$pagination_array = array();


		if (isset($shortcode_params['new_pagination'])) {
			$max_num_pages = $query_results->max_num_pages;

			$pagination_html = iver_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list','pagination/' . $shortcode_params['pagination_type'], '', $shortcode_params, $additional_params );

			$pagination_array = array(
				'paginationHtml'    => $pagination_html,
				'maxNumPages'       => $max_num_pages
			);
		}


        $return_obj = array(
            'html' => $html,
            'pagination' => $pagination_array
        );

        echo json_encode( $return_obj );
        exit;
    }

    add_action( 'wp_ajax_nopriv_iver_hotel_room_hrl_ajax_load_more', 'iver_hotel_room_hrl_ajax_load_more' );
    add_action( 'wp_ajax_iver_hotel_room_hrl_ajax_load_more', 'iver_hotel_room_hrl_ajax_load_more' );
}