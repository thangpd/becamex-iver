<?php if($pagination_type != '' || $params['enable_sort'] === 'yes') { ?>
<div class="qodef-hrl-loading">
	<div class="qodef-hrl-loading-bounce1"></div>
	<div class="qodef-hrl-loading-bounce2"></div>
	<div class="qodef-hrl-loading-bounce3"></div>
</div>
<?php } ?>