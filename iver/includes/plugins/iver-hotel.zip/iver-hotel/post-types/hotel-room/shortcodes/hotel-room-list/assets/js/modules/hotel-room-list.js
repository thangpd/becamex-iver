(function($) {
    'use strict';

    var hotelRoomList = {};
    qodef.modules.hotelRoomList = hotelRoomList;

    hotelRoomList.qodefOnDocumentReady = qodefOnDocumentReady;
    hotelRoomList.qodefOnWindowLoad = qodefOnWindowLoad;
    hotelRoomList.qodefOnWindowResize = qodefOnWindowResize;
    hotelRoomList.qodefOnWindowScroll = qodefOnWindowScroll;

    $(document).ready(qodefOnDocumentReady);
    $(window).load(qodefOnWindowLoad);
    $(window).resize(qodefOnWindowResize);
    $(window).scroll(qodefOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
        qodefInitRangeSlider();

    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function qodefOnWindowLoad() {
        qodefInitHotelRoomListLoad();
        qodefInitHotelRoomListFilter();
        qodefInitHotelRoomListPagination().init();
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function qodefOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function qodefOnWindowScroll() {
        qodefInitHotelRoomListPagination().scroll();
    }

    /*
     * This function is called to opacity to 1 for all articles after pagination or on load
     */
    function qodefInitHotelRoomListAnimation(thisHotelRoomListInner) {
        setTimeout(function () {
            thisHotelRoomListInner.find('article').addClass('qodef-hrl-item-showed');
        }, 100); // fake animation

    }
    /*
     * This function is triggered on load to set opacity to 1 for all articles
     */
    function qodefInitHotelRoomListLoad() {
        var hotelRoomList = $('.qodef-hrl-holder');
        qodefInitHotelRoomListAnimation( hotelRoomList.find('.qodef-hrl-inner'));
    }

    /*
     * This function load range slider on hotel room list filter
     */
    function qodefInitRangeSlider(){

        var selectorHolder =  $('.qodef-hrl-filter-part .qodef-filter-price-holder');
        var slider = selectorHolder.find('.qodef-range-slider');
        var outputMin = selectorHolder.find('#qodef-min-price-value');
        var valueMin = outputMin.data('min-price');
        var outputMax = selectorHolder.find('#qodef-max-price-value');
        var valueMax = outputMax.data('max-price');
        var currency = selectorHolder.data('currency');

        var maxPriceSetting = selectorHolder.data('max-price-setting');

        // Basic rangeslider initialization

        slider.slider({
            range: true,
            animate: true,
            min: 0,
            max: maxPriceSetting,
            step: 25,
            values: [ valueMin, valueMax],
            create: function() {

            },
            slide: function( event, ui ) {
                outputMin.html(currency + "" + ui.values[0] );
                outputMax.html(currency + "" + ui.values[1] );
            },
            change: function( event, ui ) {
                outputMin.data('min-price', ui.values[0] );
                outputMax.data('max-price', ui.values[1] );
            }
        });
    }

    /*
     * This function load all parts on hotel room list filter
     */
    function qodefInitHotelRoomListFilter() {
        var hotelRoomListHolder = $('.qodef-hrl-holder');
        if (hotelRoomListHolder.length) {
            hotelRoomListHolder.each(function () {
                var thisHotelRoomList = $(this),
                    thisFilter = $(this).find('.qodef-hrl-filter-part'),
                    thisSorter = $(this).find('.qodef-hrl-sort-part'),
                    button = '', // this will be used for filter
                    sortItems = ''; // this will be used for sorting

                if (thisFilter.length) {

                    var location = thisFilter.find('.qodef-filter-location-holder'),
                        numberOfRooms = thisFilter.find('.qodef-filter-room-count-holder'),
                        minPrice = thisFilter.find('#qodef-min-price-value'),
                        maxPrice = thisFilter.find('#qodef-max-price-value'),
                        minDate = thisFilter.find('.qodef-min-date'),
                        maxDate = thisFilter.find('.qodef-max-date'),
                        adults = thisFilter.find('.qodef-filter-adults-count-holder'),
                        children = thisFilter.find('.qodef-filter-children-count-holder');

                    button = thisFilter.find('.qodef-hr-filter-button');

                    //INIT LOCATION FIELD
                    var selectLocation = location.find('select');
                    if (selectLocation.length) {
                        selectLocation.select2({
                            minimumResultsForSearch: -1
                        }).on('select2:select', function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            location.data('location', selectVal);
                        });
                    }

                    //INIT NUMBER OF ROOMS FIELD
                    var selectNumberOfRooms = numberOfRooms.find('select');
                    if (selectNumberOfRooms.length) {
                        selectNumberOfRooms.select2({
                            minimumResultsForSearch: -1
                        }).on('select2:select', function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            numberOfRooms.data('room-count', selectVal);
                        });
                    }

                    //INIT ADULTS FIELD
                    var selectAdults = adults.find('select');
                    if (selectAdults.length) {
                        selectAdults.select2({
                            minimumResultsForSearch: -1
                        }).on('select2:select', function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            adults.data('adults', selectVal);
                        });
                    }

                    //INIT ADULTS FIELD
                    var selectChildren = children.find('select');
                    if (selectChildren.length) {
                        selectChildren.select2({
                            minimumResultsForSearch: -1
                        }).on('select2:select', function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            children.data('children', selectVal);
                        });
                    }

                    //INIT DATE CHECK-IN FIELD
                    if (minDate.length) {
                        minDate.datepicker({
                            minDate: '0',
                            dateFormat: 'yy-mm-dd'
                        }).change(function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            minDate.data('min-date', selectVal);
                        })
                    }

                    //INIT DATE CHECK-OUT FIELD
                    if (maxDate.length) {
                        maxDate.datepicker({
                            minDate: '+1d',
                            dateFormat: 'yy-mm-dd'
                        }).change(function (e) {
                            var selectedElement = $(e.currentTarget);
                            var selectVal = selectedElement.val();
                            maxDate.data('max-date', selectVal);
                        })
                    }

                    // call ajax in case if filter button is clicked
                    button.on('click',function () {

                        sortItems = thisHotelRoomList.find('.qodef-hrl-sort-item');
                        sortItems.removeClass('qodef-hrl-sort-active');
                        thisHotelRoomList.find('.qodef-hrl-sort-item:first-child').addClass('qodef-hrl-sort-active');
                        thisHotelRoomList.find('article').removeClass('qodef-hrl-item-showed');

                        var locationValue = location.data('location'),
                            numberOfRoomsValue = numberOfRooms.data('room-count'),
                            minPriceValue = minPrice.data('min-price'),
                            maxPriceValue = maxPrice.data('max-price'),
                            minDateValue = minDate.val(),
                            maxDateValue = maxDate.val(),
                            adultsValue = adults.data('adults'),
                            childrenValue = children.data('children'),
                            amenities = [],
                            extraServices = [],
                            order = '',
                            orderBy = '';

                        // check all amenities
                        $("input[name='qodef-amenities[]']:checked").each(function () {
                            amenities.push(parseInt($(this).data('id')));
                        });
                        amenities = amenities.join(',');

                        // check all extra services
                        $("input[name='qodef-extra-services[]']:checked").each(function () {
                            extraServices.push(parseInt($(this).data('id')));
                        });
                        extraServices = extraServices.join(',');

                        // set data for pagination
	                    thisHotelRoomList.data('room-location', locationValue !== 'undefined' && locationValue !== false && locationValue !== '' ? locationValue : '');
                        thisHotelRoomList.data('room-number-of-rooms', numberOfRoomsValue);
                        thisHotelRoomList.data('room-min-price', minPriceValue);
                        thisHotelRoomList.data('room-max-price', maxPriceValue);
                        thisHotelRoomList.data('room-min-date', minDateValue);
                        thisHotelRoomList.data('room-max-date', maxDateValue);
                        thisHotelRoomList.data('room-adults', adultsValue);
                        thisHotelRoomList.data('room-children', childrenValue);
                        thisHotelRoomList.data('room-amenities', amenities);
                        thisHotelRoomList.data('room-extra-services', extraServices);
                        thisHotelRoomList.data('order', order);
                        thisHotelRoomList.data('order-by', orderBy);

                        // call reset pagination - true
                        qodefInitHotelRoomListPagination().getMainPagFunction(thisHotelRoomList, 1, true);

                    });
                }

                if (thisSorter.length) {

                    sortItems = thisHotelRoomList.find('.qodef-hrl-sort-item');

                    var sortOption;

                    // call ajax in case if sort items is change
                    sortItems.on('click',function () {

                        thisHotelRoomList.find('article').removeClass('qodef-hrl-item-showed');

                        sortItems.removeClass('qodef-hrl-sort-active');
                        $(this).addClass('qodef-hrl-sort-active');

                        sortOption = $(this).data('sort');

                        thisHotelRoomList.data('sort-option', sortOption);

                        qodefInitHotelRoomListPagination().getMainPagFunction(thisHotelRoomList, 1);

                    });
                }
            });

        }
    }


    /**
     * Initializes hotel room list pagination functions
     */
    function qodefInitHotelRoomListPagination(){
        var hotelRoomList = $('.qodef-hrl-holder');

        var initStandardPagination = function(thisHotelRoomList) {
            var standardLink = thisHotelRoomList.find('.qodef-hrl-standard-pagination li');

            if(standardLink.length) {
                standardLink.each(function(){
                    var thisLink = $(this).children('a'),
                        pagedLink = 1;

                    thisLink.on('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();

                        if (typeof thisLink.data('paged') !== 'undefined' && thisLink.data('paged') !== false) {
                            pagedLink = thisLink.data('paged');
                        }

                        initMainPagFunctionality(thisHotelRoomList, pagedLink);
                    });
                });
            }
        };

        var initLoadMorePagination = function(thisHotelRoomList) {
            var loadMoreButton = thisHotelRoomList.find('.qodef-hrl-load-more a');

            loadMoreButton.on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();

                initMainPagFunctionality(thisHotelRoomList);
            });
        };

        var initInifiteScrollPagination = function(thisHotelRoomList) {

            var hotelRoomListHeight = thisHotelRoomList.outerHeight(),
                hotelRoomListTopOffest = thisHotelRoomList.offset().top,
                hotelRoomListPosition = hotelRoomListHeight + hotelRoomListTopOffest - qodefGlobalVars.vars.qodefAddForAdminBar,
                hotelRoomListInfinityError = 200;

            if(!thisHotelRoomList.hasClass('qodef-hrl-infinite-scroll-started') && qodef.scroll + qodef.windowHeight > (hotelRoomListPosition - hotelRoomListInfinityError)) {
                initMainPagFunctionality(thisHotelRoomList);
            }
        };

        var initMainPagFunctionality = function(thisHotelRoomList, pagedLink, newPagination) {


            var thisHotelRoomListInner = thisHotelRoomList.find('.qodef-hrl-inner'),
                nextPage,
                maxNumPages,
                thisHotelRoomPagination = thisHotelRoomList.find('.qodef-hrl-pagination-holder');
            if (typeof thisHotelRoomList.data('max-num-pages') !== 'undefined' && thisHotelRoomList.data('max-num-pages') !== false) {
                maxNumPages = thisHotelRoomList.data('max-num-pages');
            }

            if(thisHotelRoomList.hasClass('qodef-hrl-pag-standard')) {
                thisHotelRoomList.data('next-page', pagedLink);
            }

            if(thisHotelRoomList.hasClass('qodef-hrl-pag-infinite-scroll')) {
                thisHotelRoomList.addClass('qodef-hrl-infinite-scroll-started');
            }

            if(pagedLink == 1) {
                thisHotelRoomList.data('next-page', pagedLink);
            }

            var loadMoreDatta = qodef.modules.common.getLoadMoreData(thisHotelRoomList),
                loadingItem = thisHotelRoomList.find('.qodef-hrl-loading');

            nextPage = loadMoreDatta.nextPage;

            if(nextPage <= maxNumPages || maxNumPages == 0){
                if(thisHotelRoomList.hasClass('qodef-hrl-pag-standard')) {
                    loadingItem.addClass('qodef-showing qodef-standard-pag-trigger');
                    thisHotelRoomList.addClass('qodef-hrl-pag-standard-animate');
                } else {
                    loadingItem.addClass('qodef-showing');
                }

                var ajaxData = qodef.modules.common.setLoadMoreAjaxData(loadMoreDatta, 'iver_hotel_room_hrl_ajax_load_more');

                if(newPagination === true) {
                    ajaxData['newPagination'] = 'yes';
                }

                $.ajax({
                    type: 'POST',
                    data: ajaxData,
                    url: qodefGlobalVars.vars.qodefAjaxUrl,
                    success: function (data) {
                        if(!thisHotelRoomList.hasClass('qodef-hrl-pag-standard')) {
                            nextPage++;
                        }

                        thisHotelRoomList.data('next-page', nextPage);

                        var response = $.parseJSON(data),
                            responseHtml =  response.html;

                        if(thisHotelRoomList.hasClass('qodef-hrl-pag-standard') || pagedLink == 1) {
                            qodefInitStandardPaginationLinkChanges(thisHotelRoomList, maxNumPages, nextPage);

                            thisHotelRoomList.waitForImages(function(){
                                qodefInitHtmlGalleryNewContent(thisHotelRoomList, thisHotelRoomListInner, loadingItem, responseHtml);

                            });
                        } else {
                            thisHotelRoomList.waitForImages(function(){
                                qodefInitAppendGalleryNewContent(thisHotelRoomList, thisHotelRoomListInner, loadingItem, responseHtml);
                            });
                        }


                        if(newPagination === true) {
                            if(thisHotelRoomPagination.length) {
                                qodefInitAppendPaginationContent(thisHotelRoomList, thisHotelRoomPagination, response.pagination);
                            }
                        }

                        if(thisHotelRoomList.hasClass('qodef-hrl-infinite-scroll-started')) {
                            thisHotelRoomList.removeClass('qodef-hrl-infinite-scroll-started');
                        }
                    }
                });
            }

            if(pagedLink == 1) {
                thisHotelRoomList.find('.qodef-hrl-load-more-holder').show();
            }

            if(nextPage === maxNumPages){
                thisHotelRoomList.find('.qodef-hrl-load-more-holder').hide();
            }
        };

        var qodefInitStandardPaginationLinkChanges = function(thisHotelRoomList, maxNumPages, nextPage) {
            var standardPagHolder = thisHotelRoomList.find('.qodef-hrl-standard-pagination'),
                standardPagNumericItem = standardPagHolder.find('li.qodef-hrl-pag-number'),
                standardPagPrevItem = standardPagHolder.find('li.qodef-hrl-pag-prev a'),
                standardPagNextItem = standardPagHolder.find('li.qodef-hrl-pag-next a');

            standardPagNumericItem.removeClass('qodef-hrl-pag-active');
            standardPagNumericItem.eq(nextPage-1).addClass('qodef-hrl-pag-active');

            standardPagPrevItem.data('paged', nextPage-1);
            standardPagNextItem.data('paged', nextPage+1);

            if(nextPage > 1) {
                standardPagPrevItem.css({'opacity': '1'});
            } else {
                standardPagPrevItem.css({'opacity': '0'});
            }

            if(nextPage === maxNumPages) {
                standardPagNextItem.css({'opacity': '0'});
            } else {
                standardPagNextItem.css({'opacity': '1'});
            }
        };

        var qodefInitHtmlGalleryNewContent = function(thisHotelRoomList, thisHotelRoomListInner, loadingItem, responseHtml) {
            loadingItem.removeClass('qodef-showing qodef-standard-pag-trigger');
            thisHotelRoomList.removeClass('qodef-hrl-pag-standard-animate');
            thisHotelRoomListInner.html(responseHtml);

            qodefInitHotelRoomListAnimation(thisHotelRoomListInner);
            qodef.modules.common.qodefInitParallax();
        };

        var qodefInitAppendGalleryNewContent = function(thisHotelRoomList, thisHotelRoomListInner, loadingItem, responseHtml) {
            loadingItem.removeClass('qodef-showing');
            thisHotelRoomListInner.append(responseHtml);

            qodefInitHotelRoomListAnimation(thisHotelRoomListInner);
            qodef.modules.common.qodefInitParallax();
        };

        var qodefInitAppendPaginationContent = function(thisHotelRoomList, thisHotelRoomPagination, pagination) {
            thisHotelRoomPagination.html(pagination.paginationHtml);
            thisHotelRoomList.data('max-num-pages', pagination.maxNumPages)

            qodefInitHotelRoomListPagination().init();
        };

        return {
            init: function() {
                if(hotelRoomList.length) {
                    hotelRoomList.each(function() {
                        var thisHotelRoomList = $(this);

                        if(thisHotelRoomList.hasClass('qodef-hrl-pag-standard')) {
                            initStandardPagination(thisHotelRoomList);
                        }

                        if(thisHotelRoomList.hasClass('qodef-hrl-pag-load-more')) {
                            initLoadMorePagination(thisHotelRoomList);
                        }

                        if(thisHotelRoomList.hasClass('qodef-hrl-pag-infinite-scroll')) {
                            initInifiteScrollPagination(thisHotelRoomList);
                        }
                    });
                }
            },
            scroll: function() {

                if(hotelRoomList.length) {
                    hotelRoomList.each(function() {
                        var thisHotelRoomList = $(this);

                        if(thisHotelRoomList.hasClass('qodef-hrl-pag-infinite-scroll')) {
                            initInifiteScrollPagination(thisHotelRoomList);
                        }
                    });
                }
            },
            getMainPagFunction: function(thisHotelRoomList, paged, newPagination) {
                initMainPagFunctionality(thisHotelRoomList, paged, newPagination);
            }
        };

    }


})(jQuery);