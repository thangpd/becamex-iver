<?php

namespace IverHotel\CPT\Shortcodes\HotelRoomSlider;

use IverHotel\Lib;

class HotelRoomSlider implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'iver_hotel_room_slider';

        add_action('vc_before_init', array($this, 'vcMap'));

        //Room List Location filter
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_location_callback', array(&$this, 'roomLocationAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Location render
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_location_render', array(&$this, 'roomLocationAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)

        //Room List Extra Services filter
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_extra_services_callback', array(&$this, 'roomExtraServicesAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Extra Services render
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_extra_services_render', array(&$this, 'roomExtraServicesAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)

        //Room List Amenities filter
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_amenities_callback', array(&$this, 'roomAmenitiesAutocompleteSuggester',), 10, 1); // Get suggestion(find). Must return an array

        //Room List Amenities render
        add_filter('vc_autocomplete_iver_hotel_room_slider_room_amenities_render', array(&$this, 'roomAmenitiesAutocompleteRender',), 10, 1); // Render exact room. Must return an array (label,value)
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                      => esc_html__('Iver Hotel Room Slider', 'iver-hotel'),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__('by IVER HOTEL', 'iver-hotel'),
                    'icon'                      => 'icon-wpb-hotel-room-slider extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'number_of_columns',
                            'heading'     => esc_html__('Number of Columns', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Default', 'iver-hotel') => '',
                                esc_html__('One', 'iver-hotel')     => '1',
                                esc_html__('Two', 'iver-hotel')     => '2',
                                esc_html__('Three', 'iver-hotel')   => '3',
                                esc_html__('Four', 'iver-hotel')    => '4',
                                esc_html__('Five', 'iver-hotel')    => '5'
                            ),
                            'description' => esc_html__('Default value is Three', 'iver-hotel'),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'space_between_items',
                            'heading'     => esc_html__('Space Between Room', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_space_between_items_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'number_of_items',
                            'heading'     => esc_html__('Number of Rooms Per Page', 'iver-hotel'),
                            'description' => esc_html__('Set number of rooms for your hotel room list. Enter -1 to show all.', 'iver-hotel'),
                            'value'       => '-1'
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'image_proportions',
                            'heading'     => esc_html__('Image Proportions', 'iver-hotel'),
                            'value'       => array(
                                esc_html__('Original', 'iver-hotel')  => 'full',
                                esc_html__('Square', 'iver-hotel')    => 'square',
                                esc_html__('Landscape', 'iver-hotel') => 'landscape',
                                esc_html__('Portrait', 'iver-hotel')  => 'portrait',
                                esc_html__('Thumbnail', 'iver-hotel') => 'thumbnail',
                                esc_html__('Medium', 'iver-hotel')    => 'medium',
                                esc_html__('Large', 'iver-hotel')     => 'large'
                            ),
                            'description' => esc_html__('Set image proportions for your hotel room list.', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'autocomplete',
                            'param_name' => 'room_location',
                            'heading'    => esc_html__('Location', 'iver-hotel'),
                            'value'      => array_flip(iver_hotel_get_taxonomy_list('location-tag', true)),
                            'settings'   => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'       => 'autocomplete',
                            'param_name' => 'room_amenities',
                            'heading'    => esc_html__('Amenities', 'iver-hotel'),
                            'value'      => array_flip(iver_hotel_get_taxonomy_list('amenity-tag', true)),
                            'settings'   => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'room_extra_services',
                            'heading'     => esc_html__('Extra Services', 'iver-hotel'),
                            'value'       => array_flip(iver_hotel_get_taxonomy_list('extra-service-tag', true)),
                            'save_always' => true,
                            'settings'    => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order_by',
                            'heading'     => esc_html__('Order By', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_query_order_by_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order',
                            'heading'     => esc_html__('Order', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_query_order_array()),
                            'save_always' => true
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading'    => esc_html__('Title Tag', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_title_tag(true)),
                            'group'      => esc_html__('Content Layout', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'title_width',
                            'heading'    => esc_html__('Title Width', 'iver-hotel'),
                            'group'      => esc_html__('Content Layout', 'iver-hotel'),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_excerpt',
                            'heading'    => esc_html__('Enable Excerpt', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array(false)),
                            'group'      => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'excerpt_length',
                            'heading'     => esc_html__('Excerpt Length', 'iver-hotel'),
                            'description' => esc_html__('Number of characters', 'iver-hotel'),
                            'dependency'  => array('element' => 'enable_excerpt', 'value' => array('yes')),
                            'group'       => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_price_period',
                            'heading'    => esc_html__('Enable Price Period', 'iver-hotel'),
                            'value'      => array_flip(iver_select_get_yes_no_select_array(false)),
                            'dependency'  => array('element' => 'type', 'value' => array('divided')),
                            'group'      => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'price_period_text',
                            'heading'     => esc_html__('Price Period Text', 'iver-hotel'),
                            'description' => esc_html__('Default: \'Night\'', 'iver-hotel'),
                            'dependency'  => array('element' => 'enable_price_period', 'value' => array('yes')),
                            'group'       => esc_html__('Content Layout', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_loop',
                            'heading'     => esc_html__('Enable Slider Loop', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_yes_no_select_array(false, false)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'iver-hotel'),
                            'dependency'  => array('element' => 'item_type', 'value' => array(''))
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_autoplay',
                            'heading'     => esc_html__('Enable Slider Autoplay', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_yes_no_select_array(false, true)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed',
                            'heading'     => esc_html__('Slide Duration', 'iver-hotel'),
                            'description' => esc_html__('Default value is 5000 (ms)', 'iver-hotel'),
                            'group'       => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed_animation',
                            'heading'     => esc_html__('Slide Animation Duration', 'iver-hotel'),
                            'description' => esc_html__('Speed of slide animation in milliseconds. Default value is 600.', 'iver-hotel'),
                            'group'       => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_navigation',
                            'heading'     => esc_html__('Enable Slider Navigation Arrows', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_yes_no_select_array(false, true)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_pagination',
                            'heading'     => esc_html__('Enable Slider Pagination', 'iver-hotel'),
                            'value'       => array_flip(iver_select_get_yes_no_select_array(false, true)),
                            'save_always' => true,
                            'group'       => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'pagination_skin',
                            'heading'    => esc_html__('Pagination Skin', 'iver-hotel'),
                            'value'      => array(
                                esc_html__('Default', 'iver-hotel') => '',
                                esc_html__('Light', 'iver-hotel')   => 'light',
                                esc_html__('Dark', 'iver-hotel')    => 'dark'
                            ),
                            'dependency' => array('element' => 'enable_pagination', 'value' => array('yes')),
                            'group'      => esc_html__('Slider Settings', 'iver-hotel')
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'boxed_layout'         => 'no',
            'number_of_columns'    => '3',
            'space_between_items'  => 'tiny',
            'number_of_items'      => '-1',
            'image_proportions'    => 'full',
            'room_location'        => '',
            'room_amenities'       => '',
            'room_extra_services'  => '',
            'room_min_date'        => '',
            'room_max_date'        => '',
            'room_min_price'       => '',
            'room_max_price'       => '',
            'room_adults'          => '',
            'room_children'        => '',
            'room_number_of_rooms' => '',
            'order_by'             => 'date',
            'order'                => 'DESC',
            'title_tag'            => 'h5',
            'title_width'          => '',
            'enable_excerpt'       => 'no',
            'excerpt_length'       => '150',
            'enable_price_period'  => 'no',
            'price_period_text'    => 'Night',
            'enable_loop'            => 'no',
            'enable_autoplay'        => 'yes',
            'slider_speed'           => '5000',
            'slider_speed_animation' => '600',
            'enable_navigation'      => 'yes',
            'navigation_skin'        => '',
            'enable_pagination'      => 'yes',
            'pagination_skin'        => '',
        );
        $params = shortcode_atts($args, $atts);

        $params['type'] = 'gallery';
        $params['gallery_hover'] = 'standard';
        $params['hotel_room_slider_on'] = 'yes';

        $html = '<div class="qodef-hrs-holder">';
        $html .= iver_select_execute_shortcode('iver_hotel_room_list', $params);
        $html .= '</div>';

        return $html;
    }

    /**
     * Filter room list location
     *
     * @param $query
     *
     * @return array
     */
    public function roomLocationAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_location_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'location-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_location_title']) > 0) ? esc_html__('Location', 'iver-hotel') . ': ' . $value['room_location_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list location by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomLocationAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room location
            $room_location = get_term_by('slug', $query, 'location-tag');
            if (is_object($room_location)) {

                $room_location_slug = $room_location->slug;
                $room_location_title = $room_location->name;

                $room_location_title_display = '';
                if (!empty($room_location_title)) {
                    $room_location_title_display = esc_html__('Location', 'iver-hotel') . ': ' . $room_location_title;
                }

                $data = array();
                $data['value'] = $room_location_slug;
                $data['label'] = $room_location_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

    /**
     * Filter room list extra service
     *
     * @param $query
     *
     * @return array
     */
    public function roomExtraServicesAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_extra_service_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'extra-service-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_extra_service_title']) > 0) ? esc_html__('Extra Service', 'iver-hotel') . ': ' . $value['room_extra_service_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list extra service by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomExtraServicesAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room extra service
            $room_extra_service = get_term_by('slug', $query, 'extra-service-tag');
            if (is_object($room_extra_service)) {

                $room_extra_service_slug = $room_extra_service->slug;
                $room_extra_service_title = $room_extra_service->name;

                $room_extra_service_title_display = '';
                if (!empty($room_extra_service_title)) {
                    $room_extra_service_title_display = esc_html__('Extra Service', 'iver-hotel') . ': ' . $room_extra_service_title;
                }

                $data = array();
                $data['value'] = $room_extra_service_slug;
                $data['label'] = $room_extra_service_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }

    /**
     * Filter room list amenity
     *
     * @param $query
     *
     * @return array
     */
    public function roomAmenitiesAutocompleteSuggester($query) {
        global $wpdb;
        $post_meta_infos = $wpdb->get_results($wpdb->prepare("SELECT a.slug AS slug, a.name AS room_amenity_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'amenity-tag' AND a.name LIKE '%%%s%%'", stripslashes($query)), ARRAY_A);

        $results = array();
        if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
            foreach ($post_meta_infos as $value) {
                $data = array();
                $data['value'] = $value['termid'];
                $data['label'] = ((strlen($value['room_amenity_title']) > 0) ? esc_html__('Amenity', 'iver-hotel') . ': ' . $value['room_amenity_title'] : '');
                $results[] = $data;
            }
        }

        return $results;
    }

    /**
     * Find room list amenity by slug
     * @since 4.4
     *
     * @param $query
     *
     * @return bool|array
     */
    public function roomAmenitiesAutocompleteRender($query) {
        $query = trim($query['value']); // get value from requested
        if (!empty($query)) {
            // get room amenity
            $room_amenity = get_term_by('slug', $query, 'amenity-tag');
            if (is_object($room_amenity)) {

                $room_amenity_slug = $room_amenity->slug;
                $room_amenity_title = $room_amenity->name;

                $room_amenity_title_display = '';
                if (!empty($room_amenity_title)) {
                    $room_amenity_title_display = esc_html__('Amenity', 'iver-hotel') . ': ' . $room_amenity_title;
                }

                $data = array();
                $data['value'] = $room_amenity_slug;
                $data['label'] = $room_amenity_title_display;

                return !empty($data) ? $data : false;
            }

            return false;
        }

        return false;
    }
}