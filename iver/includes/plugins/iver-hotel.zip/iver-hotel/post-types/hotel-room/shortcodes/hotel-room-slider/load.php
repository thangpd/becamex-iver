<?php

require_once 'hotel-room-slider.php';
require_once 'helper-functions.php';