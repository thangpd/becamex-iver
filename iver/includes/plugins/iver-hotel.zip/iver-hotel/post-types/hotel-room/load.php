<?php

include_once IVER_HOTEL_CPT_PATH.'/hotel-room/hotel-room-register.php';
include_once IVER_HOTEL_CPT_PATH.'/hotel-room/helper-functions.php';
include_once IVER_HOTEL_CPT_PATH.'/hotel-room/tax-custom-fields.php';
if(iver_hotel_iver_membership_installed()) {
	include_once IVER_HOTEL_CPT_PATH . '/hotel-room/profile/profile-functions.php';
}
include_once IVER_HOTEL_CPT_PATH.'/hotel-room/shop/load.php';

//load admin
if(!function_exists('iver_hotel_room_load_admin')) {
	function iver_hotel_room_load_admin() {
		include_once IVER_HOTEL_CPT_PATH.'/hotel-room/admin/options/map.php';
	}
	add_action('iver_select_before_options_map', 'iver_hotel_room_load_admin');
}
