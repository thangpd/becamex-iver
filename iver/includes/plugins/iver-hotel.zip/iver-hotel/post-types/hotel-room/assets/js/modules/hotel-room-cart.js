(function($) {
    'use strict';

    var hotelRoomCart = {};
    qodef.modules.hotelRoomCart = hotelRoomCart;

    hotelRoomCart.qodefOnDocumentReady = qodefOnDocumentReady;
    hotelRoomCart.qodefOnWindowLoad = qodefOnWindowLoad;
    hotelRoomCart.qodefOnWindowResize = qodefOnWindowResize;
    hotelRoomCart.qodefOnWindowScroll = qodefOnWindowScroll;

    hotelRoomCart.qodefInitHotelRoomCartUpdateSession = qodefInitHotelRoomCartUpdateSession ;

    $(document).ready(qodefOnDocumentReady);
    $(window).load(qodefOnWindowLoad);
    $(window).resize(qodefOnWindowResize);
    $(window).scroll(qodefOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
        qodefInitHotelRoomCartUpdateSession();


    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function qodefOnWindowLoad() {
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function qodefOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function qodefOnWindowScroll() {

    }

    function qodefInitHotelRoomCartUpdateSession(){
        var wooCommerceCheckout = $('.woocommerce-checkout');

        function updateSessionTrigger() {


            var ajaxData = {
                action: 'check_hotel_room_session_update',
            };

            $.ajax({
                type: 'POST',
                data: ajaxData,
                url: qodefGlobalVars.vars.qodefAjaxUrl,

                success: function (data) {
                    return true;
                }
            });
        }

        if(wooCommerceCheckout.length) {
            updateSessionTrigger();
        }
      
    }

    

})(jQuery);