(function($) {
    'use strict';

    var hotelRoomSingle = {};
    qodef.modules.hotelRoomSingle = hotelRoomSingle;

    hotelRoomSingle.qodefOnDocumentReady = qodefOnDocumentReady;
    hotelRoomSingle.qodefOnWindowLoad = qodefOnWindowLoad;

    hotelRoomSingle.qodefInitHotelRoomSingleTabs = qodefInitHotelRoomSingleTabs;
    hotelRoomSingle.qodefHotelRoomTabsMapTrigger = qodefHotelRoomTabsMapTrigger;

    $(document).ready(qodefOnDocumentReady);
    $(window).load(qodefOnWindowLoad);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
        if(typeof qodef === 'undefined' || typeof qodef === '' ){
            //if theme is not installed, generate single items manualy
            qodefInitHotelRoomSingleTabs();
        }

        if(typeof qodef !== 'undefined' ){
            //if theme is installed, trigger google map loading on location tab on single pages
            qodefHotelRoomTabsMapTrigger();
        }
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function qodefOnWindowLoad() {
        qodefInitHotelRoomSingleReservation();
    }

    function qodefInitHotelRoomSingleTabs(){
        var holder = $('.qodef-hotel-room-single-outer');
        var roomNavItems = holder.find('.qodef-hr-item-wrapper ul li a');
        var roomSectionsItems  = holder.find('.qodef-hr-item-section');
        roomNavItems.first().addClass('qodef-active-item');

        roomNavItems.on('click', function(e){
            e.preventDefault();

            roomNavItems.removeClass('qodef-active-item');

            var thisNavItem  = $(this);

            var thisNavItemId = thisNavItem.attr('href');
            thisNavItem.addClass('qodef-active-item');

            if( roomSectionsItems.length ){
                roomSectionsItems.each(function(){
                    var thisSectionItem = $(this);

                    if('#'+thisSectionItem.attr('id') === thisNavItemId){
                        thisSectionItem.show();
                        if(thisNavItemId === '#iver_hotel_room_tab_id_location'){
                            qodefHotelRoomReInitGoogleMap();
                        }
                    }else{
                        thisSectionItem.hide();
                    }
                });
            }
        });
    }

    function qodefHotelRoomTabsMapTrigger(){
        var holder = $('.qodef-hotel-room-single-outer');
        var hotelRoomNavItems = holder.find('.qodef-hr-item-wrapper ul li a');
        
        hotelRoomNavItems.on('click', function(e){
            e.preventDefault();

            var thisNavItem  = $(this);
            var thisNavItemId = thisNavItem.attr('href');

            if(thisNavItemId === '#iver_hotel_room_tab_id_location'){
                qodefHotelRoomReInitGoogleMap();
            }
        });
    }

    function qodefHotelRoomReInitGoogleMap(){
        if(typeof qodef !== 'undefined'){
            qodef.modules.googleMap.qodefShowGoogleMap();
        }
    }

    function qodefInitHotelRoomSingleReservation() {
        var reservation = $('.qodef-hotel-room-reservation');
        if (reservation.length) {

            reservation.each(function() {
                var thisReservation = $(this),
                    allInputs               = thisReservation.find('input, select'),
                    thisReservationHolder   = thisReservation.parents('.qodef-hotel-room-reservation-holder'),
                    finishForm              = thisReservation.find('.qodef-buy-item-form .qodef-hotel-room-single-res-button'), // form that is enabled after validation
                    relocationButton        = thisReservation.find('.qodef-hotel-room-reservation-similar'), // button for relocation
                    form                    = thisReservation.find('#qodef-hotel-room-form'), // initial form
                    checkButton             = form.find('.qodef-hotel-room-single-res-check'), // check button
                    checkButtonChecking     = form.find('.qodef-hotel-room-single-res-checking'), // check button
                    initialPrice            = thisReservation.find('.qodef-res-initial-price .qodef-res-price-number'), // initial price
                    endPrice                = thisReservation.find('.qodef-res-end-price .qodef-res-price-number'), // end price after activated extra services
                    roomNumber              = thisReservation.find('.qodef-res-rooms-number'),
                    adults                  = thisReservation.find('.qodef-res-adults'),
                    children                = thisReservation.find('.qodef-res-children'),
                    minDate                 = thisReservation.find('.qodef-res-min-date'),
                    maxDate                 = thisReservation.find('.qodef-res-max-date'),
                    formValidation          = thisReservation.find('#reservation-validation-messages-holder');

                //INIT ROOMS FIELD

                var selectRoomNumber = roomNumber;
                if(selectRoomNumber.length) {
                    selectRoomNumber.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectAdults = adults;
                if(selectAdults.length) {
                    selectAdults.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectChildren = children;
                if(selectChildren.length) {
                    selectChildren.select2({
                        minimumResultsForSearch: -1
                    });
                }
                
                //INIT DATE CHECK-IN FIELD
                if(minDate.length) {
                    minDate.datepicker({
                        minDate : '0',
                        dateFormat: 'yy-mm-dd'
                    });
                }

                //INIT DATE CHECK-OUT FIELD
                if(maxDate.length) {
                    maxDate.datepicker({
                        minDate : '+1d',
                        dateFormat: 'yy-mm-dd'
                    });
                }

                allInputs.change(function() {
                    // reset buttons on reservation form when something is changed
                    finishForm.addClass('qodef-disable-hotel-room-single-btn');
                    relocationButton.addClass('qodef-disable-hotel-room-single-btn');
                });

                form.on('submit', function(e) {
                    var thisForm = $(this);

                    // remove check -> checking
                    checkButton.addClass('qodef-disable-hotel-room-single-btn');
                    checkButtonChecking.removeClass('qodef-disable-hotel-room-single-btn');

                    e.preventDefault();
                    e.stopPropagation();

                    var ajaxData = {
                        action: 'check_hotel_room_booking'
                    };

                    // get all inputs
                    ajaxData.fields = thisForm.serialize();

                    $.ajax({
                        type: 'POST',
                        data: ajaxData,
                        url: qodefGlobalVars.vars.qodefAjaxUrl,
                        success: function (data) {
                            var response = $.parseJSON(data);

                            if(!response.status) {
                                updateValidationTemplate(formValidation, response.messages);

                                finishForm.addClass('qodef-disable-hotel-room-single-btn');

                                if(response.relocation === 'hotel_search') {
                                    // enable relocation
                                    relocationButton.removeClass('qodef-disable-hotel-room-single-btn');
                                } else {
                                    // leave only check reservation
                                    relocationButton.addClass('qodef-disable-hotel-room-single-btn');
                                }

                            } else {

                                // reset all messages
                                updateValidationTemplate(formValidation, []);

                                // enable add to cart
                                relocationButton.addClass('qodef-disable-hotel-room-single-btn');

                                finishForm.removeClass('qodef-disable-hotel-room-single-btn');

                                if(response.newPrice !== '') {
                                    // set new price
                                    endPrice.html(response.newPrice);
                                }
                            }

                            // added to reservation holder data
                            setDataForBooking(thisReservationHolder, thisForm);

                            // remove checking -> check
                            checkButtonChecking.addClass('qodef-disable-hotel-room-single-btn');
                            checkButton.removeClass('qodef-disable-hotel-room-single-btn');
                        }
                    });
                });

                relocationButton.on('click',function (e) {
                    e.preventDefault();
                    e.stopPropagation();

                    var thisButton = $(this);
                    var data = thisReservationHolder.data();

                    var searchLink = thisButton.attr('href');

                    var i = 0;
                    // creating link and 'get' data
                    $.each(data, function(index, value) {
                        if(i++ === 0) {
                            searchLink+= '?';
                        } else {
                            searchLink+= '&';
                        }
                        searchLink += index + '=' + value;
                    });

                    // redirect to search page
                    window.location = searchLink;
                });
            });
        }
        
        var updateValidationTemplate = function (formValidation, messages) {
            var html = '';

            for(var i = 0; i < messages.length; i++) {
                html += '<div class="qodef-reservation-messages">' + messages[i] + '</div>';
            }
            
            formValidation.html(html);
        };

        var setDataForBooking = function (holder, form) {
            holder.data('min_date', form.find('input[name="room_min_date"]').val());
            holder.data('max_date', form.find('input[name="room_max_date"]').val());
            holder.data('rooms_number', form.find('select[name="room_number"]').val());
            holder.data('adults', form.find('select[name="room_adults"]').val());
            holder.data('children', form.find('select[name="room_children"]').val());
        }
    }

})(jQuery);