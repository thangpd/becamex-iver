<?php
if(iver_hotel_theme_installed()) {
	if ( ! function_exists( 'iver_hotel_room_gallery_meta_box_map' ) ) {

		function iver_hotel_room_gallery_meta_box_map() {

			$hotel_room_gallery_section_meta_box = iver_select_create_meta_box( array(
				'scope' => array( 'hotel-room' ),
				'title' => esc_html__( 'Gallery Section', 'iver-hotel' ),
				'name'  => 'hotel_gallery_section_meta'
			) );

			iver_select_add_multiple_images_field( array(
				'parent'      => $hotel_room_gallery_section_meta_box,
				'name'        => 'hotel_room_gallery_images',
				'label'       => esc_html__( 'Gallery Images', 'iver-hotel' ),
				'description' => esc_html__( 'Choose your gallery images', 'iver-hotel' )
			) );
		}

		add_action( 'iver_select_meta_boxes_map', 'iver_hotel_room_gallery_meta_box_map' );
	}
}
