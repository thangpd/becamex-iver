<?php

if(!function_exists('iver_hotel_room_options_map')) {

	function iver_hotel_room_options_map() {

		$search_pages =  iver_hotel_room_get_search_pages(true);

		$search_panel = iver_select_add_admin_panel(array(
			'title' => esc_html__('Search Page', 'iver-hotel'),
			'name'  => 'panel_hotel_room_search',
			'page'  => '_hotel'
		));

		iver_select_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_main_page',
			'default_value' => '',
			'label'         => esc_html__('Main Search Page', 'iver-hotel'),
			'description'   => esc_html__('Choose main search page. Defaults to hotel rooms archive page', 'iver-hotel'),
			'options'       => $search_pages,
			'args'          => array(
				'col_width' => 3
			)
		));

		iver_select_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'text',
			'name'          => 'hotel_room_per_page',
			'default_value' => 12,
			'label'         => esc_html__('Items per Page', 'iver-hotel'),
			'description'   => esc_html__('Choose number of hotel rooms per page', 'iver-hotel'),
			'args'          => array(
				'col_width' => 3
			)
		));

		iver_select_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_default_view_type',
			'default_value' => 'gallery',
			'label'         => esc_html__('Default Hotel Room View Type', 'iver-hotel'),
			'description'   => esc_html__('Choose default Hotel room view type', 'iver-hotel'),
			'options'       => array(
				'gallery'     => esc_html__('Gallery', 'iver-hotel'),
				'standard' => esc_html__('Standard', 'iver-hotel'),
				'divided'  => esc_html__('Divided', 'iver-hotel')
			),
			'args'          => array(
				'col_width' => 3
			)
		));

		iver_select_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_columns',
			'default_value' => 'gallery',
			'label'         => esc_html__('Number of Columns', 'iver-hotel'),
			'description'   => esc_html__('Choose number of columns on search page', 'iver-hotel'),
			'options'       => array(
				''     => esc_html__('Default', 'iver-hotel'),
				'1' => esc_html__('One', 'iver-hotel'),
				'2'  => esc_html__('Two', 'iver-hotel'),
				'3'  => esc_html__('Three', 'iver-hotel'),
				'4'  => esc_html__('Four', 'iver-hotel'),
				'5'  => esc_html__('Five', 'iver-hotel'),
				'6'  => esc_html__('Six', 'iver-hotel'),
			),
			'args'          => array(
				'col_width' => 3
			)
		));

		iver_select_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_default_ordering',
			'default_value' => 'date',
			'label'         => esc_html__('Default Hotel Room Ordering', 'iver-hotel'),
			'description'   => esc_html__('Choose default hotel room ordering', 'iver-hotel'),
			'options'       => iver_hotel_room_get_room_sorting_options(),
			'args'          => array(
				'col_width' => 3
			)
		));

		$panel_hotel_room_single = iver_select_add_admin_panel(array(
			'title' => esc_html__('Hotel Room Single', 'iver-hotel'),
			'name'  => 'panel_hotel_room_single',
			'page'  => '_hotel'
		));

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_featured_item',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__('Choose element on the top', 'iver-hotel'),
				'description'   => esc_html__('This option will set first element on single item ', 'iver-hotel'),
				'options'     => array(
					''  => esc_html__( 'Default', 'iver-hotel' ),
					'featured_image' => esc_html__( 'Featured Image', 'iver-hotel' ),
					'slider' => esc_html__( 'Slider (from gallery)', 'iver-hotel' ),
				),
				'parent'        => $panel_hotel_room_single,
			)
		);

        iver_select_add_admin_field(
            array(
                'name'          => 'hotel_room_boxed_single_item',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Boxed Single Item', 'iver-hotel'),
                'options'     => array(
                    ''  => esc_html__( 'Default', 'iver-hotel' ),
                    'yes' => esc_html__( 'Yes', 'iver-hotel' ),
                    'no' => esc_html__( 'No', 'iver-hotel' ),
                ),
                'parent'        => $panel_hotel_room_single,
            )
        );

		iver_select_add_admin_section_title( array(
			'title'       => esc_html__( 'Tabs', 'iver-hotel' ),
			'description' => esc_html__( 'Enable items for single room', 'iver-hotel' ),
			'name'        => 'hotel_room_single_tab_title',
			'parent'      => $panel_hotel_room_single
		) );

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_amenities',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Amenities', 'iver-hotel'),
				'description'   => esc_html__('This option will enable/disable Amenities ', 'iver-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_gallery',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Gallery', 'iver-hotel'),
				'description'   => esc_html__('This option will enable/disable Gallery ', 'iver-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_extra_services',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Extra Services', 'iver-hotel'),
				'description'   => esc_html__('This option will enable/disable Extra Services ', 'iver-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_location',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Location', 'iver-hotel'),
				'description'   => esc_html__('This option will enable/disable Location ', 'iver-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_reviews',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Reviews', 'iver-hotel'),
				'description'   => esc_html__('This option will enable/disable Reviews ', 'iver-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		iver_select_add_admin_field(
			array(
				'name'          => 'hotel_room_google_code_map',
				'type'          => 'textarea',
				'label'         => esc_html__('Insert Google Snazzy Map', 'iver-hotel'),
				'description'   => esc_html__( 'Fill code from snazzy map site https://snazzymaps.com to add predefined style for your google map', 'iver-hotel' ),
				'parent'        => $panel_hotel_room_single,
			)
		);
	}

	add_action('iver_hotel_room_action_single_fields', 'iver_hotel_room_options_map');
}