<?php
if(!function_exists( 'iver_hotel_room_map_date_meta' )) {
    function iver_hotel_room_map_date_meta($meta_box) {

	    $hotel_room_date_container = iver_select_add_admin_container(array(
            'type'            => 'container',
            'name'            => 'hotel_date_container',
            'parent'          => $meta_box
        ));

        iver_select_add_admin_section_title(array(
            'title'           => esc_html__('Reserved Dates', 'iver-hotel'),
            'description' => esc_html__('Insert reserved date for hotel room', 'iver-hotel'),
            'name'            => 'hotel_date_container_title',
            'parent'          => $hotel_room_date_container
        ));

	    iver_select_add_repeater_field(
            array(
                'name'        => 'hotel_room_date',
                'parent'      => $hotel_room_date_container,
                'button_text' => '',
                'fields'      => array_merge(
	                array(
		                array(
			                'type'        => 'date',
			                'name'        => 'date_begin',
			                'label'       => esc_html__( 'Date (Begin)', 'iver-hotel' ),
			                'col_width'   => '3',
			                'args'        => array(
				                'col_width' => 12,
			                ),
		                ),
		                array(
			                'type'        => 'date',
			                'name'        => 'date_end',
			                'label'       => esc_html__( 'Date (End)', 'iver-hotel' ),
			                'col_width'   => '3',
			                'args'        => array(
				                'col_width' => 12,
			                ),
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'number_of_room',
			                'label'       => esc_html__( 'Number', 'iver-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'adults',
			                'label'       => esc_html__( 'Adults', 'iver-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'children',
			                'label'       => esc_html__( 'Children', 'iver-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'order_id',
			                'label'       => esc_html__( 'Order ID', 'iver-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'textarea',
			                'name'        => 'additional_info',
			                'label'       => esc_html__( 'Additional Info', 'iver-hotel' ),
			                'col_width'   => '12'
		                ),
	                )
                )
            )
        );

    }

    add_action('iver_hotel_room_action_meta_fields', 'iver_hotel_room_map_date_meta', 20, 1);
}