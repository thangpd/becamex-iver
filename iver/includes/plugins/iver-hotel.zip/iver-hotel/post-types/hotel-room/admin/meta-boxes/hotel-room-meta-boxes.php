<?php
if(iver_hotel_theme_installed()) {
	if(!function_exists( 'iver_hotel_room_meta_box_map' )) {
		function iver_hotel_room_meta_box_map()
		{

			/* get currency */
			$currency = iver_hotel_room_get_currency();

			$hotel_room_meta_box = iver_select_create_meta_box(
				array(
					'scope' => array('hotel-room'),
					'title' => esc_html__('Hotel Room Meta Box', 'iver-hotel'),
					'name' => 'hotel_room_item_meta'
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_featured_item_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Choose element on the top', 'iver-hotel'),
					'description'   => esc_html__('This option will set first element on single item ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'featured_image' => esc_html__( 'Featured Image', 'iver-hotel' ),
						'slider' => esc_html__( 'Slider (from gallery)', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

            iver_select_create_meta_box_field(
                array(
                    'name'          => 'qodef_hotel_room_boxed_single_item_meta',
                    'type'          => 'select',
                    'default_value' => '',
                    'label'         => esc_html__('Boxed Single Item', 'iver-hotel'),
                    'options'     => array(
                        ''  => esc_html__( 'Default', 'iver-hotel' ),
                        'yes' => esc_html__( 'Yes', 'iver-hotel' ),
                        'no' => esc_html__( 'No', 'iver-hotel' ),
                    ),
                    'parent'        => $hotel_room_meta_box,
                )
            );

			iver_select_add_admin_section_title( array(
				'title'       => esc_html__( 'Tabs', 'iver-hotel' ),
				'description' => esc_html__( 'Enable items for single room', 'iver-hotel' ),
				'name'        => 'qodef_hotel_room_single_tab_title_meta',
				'parent'      => $hotel_room_meta_box
			) );


			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_enable_amenities_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Amenities', 'iver-hotel'),
					'description'   => esc_html__('This option will enable/disable Amenities ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'yes' => esc_html__( 'Yes', 'iver-hotel' ),
						'no' => esc_html__( 'No', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_enable_gallery_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Gallery', 'iver-hotel'),
					'description'   => esc_html__('This option will enable/disable Gallery ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'yes' => esc_html__( 'Yes', 'iver-hotel' ),
						'no' => esc_html__( 'No', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_enable_extra_services_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Extra Services', 'iver-hotel'),
					'description'   => esc_html__('This option will enable/disable Extra Services ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'yes' => esc_html__( 'Yes', 'iver-hotel' ),
						'no' => esc_html__( 'No', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_enable_location_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Location', 'iver-hotel'),
					'description'   => esc_html__('This option will enable/disable Location ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'yes' => esc_html__( 'Yes', 'iver-hotel' ),
						'no' => esc_html__( 'No', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'          => 'qodef_hotel_room_enable_reviews_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Reviews', 'iver-hotel'),
					'description'   => esc_html__('This option will enable/disable Reviews ', 'iver-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'iver-hotel' ),
						'yes' => esc_html__( 'Yes', 'iver-hotel' ),
						'no' => esc_html__( 'No', 'iver-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'        => 'hotel_room_number',
					'type'        => 'text',
					'label'       => esc_html__( 'Room Number', 'iver-hotel' ),
					'description' => esc_html__( 'Enter number of hotel rooms', 'iver-hotel' ),
					'args'        => array(
						'col_width' => 2,
					),
					'parent'      => $hotel_room_meta_box
				)
			);

			iver_select_create_meta_box_field(
				array(
					'name'        => 'hotel_room_price',
					'type'        => 'text',
					'label'       => esc_html__( 'Price per night', 'iver-hotel' ),
					'description' => esc_html__( 'Enter hotel room price per night', 'iver-hotel' ),
					'args'        => array(
						'col_width' => 2,
						'suffix'    => $currency
					),
					'parent'      => $hotel_room_meta_box
				)
			);

			$iver_capacity_group = iver_select_add_admin_group(
				array(
					'name'        => 'capacity_group',
					'title'       => esc_html__( 'Capacity', 'iver-hotel' ),
					'description' => esc_html__( 'Enter capacity for hotel room', 'iver-hotel' ),
					'parent'      => $hotel_room_meta_box
				)
			);

					$iver_capacity_row = iver_select_add_admin_row(
						array(
							'name'   => 'hotel_room_capacity_row',
							'next'   => true,
							'parent' => $iver_capacity_group
						)
					);

							iver_select_create_meta_box_field(
								array(
									'name'   => 'hotel_room_capacity_adults',
									'type'   => 'textsimple',
									'label'  => esc_html__( 'Adults (Number)', 'iver-hotel' ),
									'parent' => $iver_capacity_row,
								)
							);

							iver_select_create_meta_box_field(
								array(
									'name'   => 'hotel_room_capacity_children',
									'type'   => 'textsimple',
									'label'  => esc_html__( 'Children (Number)', 'iver-hotel' ),
									'parent' => $iver_capacity_row,
								)
							);

			do_action('iver_hotel_room_action_meta_fields', $hotel_room_meta_box);

		}
		add_action('iver_select_meta_boxes_map', 'iver_hotel_room_meta_box_map');
	}
}