<?php
if(iver_hotel_theme_installed()) {
	if ( ! function_exists( 'iver_hotel_room_map_room_extra_service_meta' ) ) {
		function iver_hotel_room_map_room_extra_service_meta( $hotel_room_extra_services_meta_box ) {

			/* get all extra services */
			$hotel_extra_services = iver_hotel_room_get_extra_services();

			/* get currency */
			$currency = iver_hotel_room_get_currency();

			/* printing meta boxes */

			$hotel_room_extra_services_meta_box = iver_select_create_meta_box( array(
					'scope' => array( 'hotel-room' ),
					'title' => esc_html__( 'Hotel Room Extra Services', 'iver-hotel' ),
					'name'  => 'hotel_room_extra_services_item_meta'
				) );

			if ( is_array( $hotel_extra_services ) && count( $hotel_extra_services ) ) {

				iver_select_create_meta_box_field( array(
					'name'          => 'hotel_room_extra_service',
					'type'          => 'checkboxgroup',
					'default_value' => '',
					'label'         => esc_html__( 'Extra Services', 'iver-hotel' ),
					'description'   => esc_html__( 'Define room extra services', 'iver-hotel' ),
					'parent'        => $hotel_room_extra_services_meta_box,
					'options'       => $hotel_extra_services
				) );
			}

			$hotel_room_extra_service_container = iver_select_add_admin_container( array(
				'type'   => 'container',
				'name'   => 'hotel_room_extra_service_container',
				'parent' => $hotel_room_extra_services_meta_box
			) );

			iver_select_add_admin_section_title( array(
				'title'       => esc_html__( 'Additional Extra Service', 'iver-hotel' ),
				'description' => esc_html__( 'Add extra service only for this Single Room', 'iver-hotel' ),
				'name'        => 'hotel_room_extra_service_container_title',
				'parent'      => $hotel_room_extra_service_container
			) );

			iver_select_add_repeater_field( array(
					'name'        => 'hotel_room_additional_extra_service',
					'parent'      => $hotel_room_extra_service_container,
					'button_text' => '',
					'fields'      => array_merge( array(
							array(
								'type'        => 'text',
								'name'        => 'name',
								'label'       => esc_html__( 'Name', 'iver-hotel' ),
								'col_width'   => '6'
							),
							array(
								'type'        => 'textarea',
								'name'        => 'description',
								'label'       => esc_html__( 'Description', 'iver-hotel' ),
								'col_width'   => '12'
							),
							array(
								'type'        => 'select',
								'name'        => 'type',
								'label'       => esc_html__( 'Type', 'iver-hotel' ),
								'options'     => array(
									'optional'  => esc_html__( 'Optional', 'iver-hotel' ),
									'mandatory' => esc_html__( 'Mandatory', 'iver-hotel' ),
								),
								'col_width'   => '6',
								'args'        => array(
									'col_width' => 12,
									'select2'  => true
								),
							),
							array(
								'type'        => 'select',
								'name'        => 'service_pack',
								'label'       => esc_html__( 'Service Pack', 'iver-hotel' ),
								'options'     => iver_hotel_room_get_service_packs(),
								'col_width'   => '6',
								'args'        => array(
									'col_width' => 12,
									'select2'  => true
								),
							),
							array(
								'type'        => 'text',
								'name'        => 'price',
								'label'       => esc_html__( 'Price', 'iver-hotel' ),
								'col_width'   => '6',
								'args'        => array(
									'suffix' => $currency,

								),
							),
							array(
								'type'        => 'text',
								'name'        => 'percent',
								'label'       => esc_html__( 'Percent', 'iver-hotel' ),
								'col_width'   => '6',
								'args'        => array(
									'suffix' => '%',

								),
							),

						) )
				) );
		}

		add_action( 'iver_select_meta_boxes_map', 'iver_hotel_room_map_room_extra_service_meta');
	}
}