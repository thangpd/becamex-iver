<?php
if(!function_exists('iver_hotel_map_hotel_room_address_meta')) {
    function iver_hotel_map_hotel_room_address_meta($meta_box) {

	    /* get all location */
	    $hotel_locations = iver_hotel_room_get_locations();

	    $default_value = '';
	    if(isset($hotel_locations[0])){
		    $default_value = $hotel_locations[0];
	    }

        $hotel_room_address_container = iver_select_add_admin_container(array(
            'type'            => 'container',
            'name'            => 'hotel_room_address_container',
            'parent'          => $meta_box
        ));

        iver_select_add_admin_section_title(array(
            'title'           => esc_html__('Address', 'iver-hotel'),
            'name'            => 'hotel_room_address_container_title',
            'parent'          => $hotel_room_address_container
        ));

	    iver_select_create_meta_box_field(array(
		    'name'        => 'iver_hotel_room_location_meta',
		    'type'        => 'select',
		    'label'       => esc_html__('Location', 'iver-hotel'),
		    'description' => esc_html__('Choose location for Single Room', 'iver-hotel'),
		    'default_value' => $default_value,
		    'parent'      => $hotel_room_address_container,
		    'options'     => $hotel_locations,
		    'args'        => array(
			    'select2' => true,
		    ),
	    ));

	    iver_select_create_meta_box_field(array(
		    'name'        => 'iver_hotel_room_address_country_meta',
		    'type'        => 'text',
		    'label'       => esc_html__('Country', 'iver-hotel'),
		    'parent'      => $hotel_room_address_container,
	    ));

        iver_select_create_meta_box_field(array(
            'name'        => 'iver_hotel_room_full_address_meta',
            'type'        => 'address',
            'label'       => esc_html__('Full Address', 'iver-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'latitude_field' => 'iver_hotel_room_full_address_latitude',
                'longitude_field' => 'iver_hotel_room_full_address_longitude'
            )
        ));

        iver_select_create_meta_box_field(array(
            'name'        => 'iver_hotel_room_full_address_latitude',
            'type'        => 'text',
            'label'       => esc_html__('Latitude', 'iver-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3,
                'custom_class' => 'qodef-address-elements',
                'input-data' => array(
                    'data-geo' => 'lat'
                )
            )
        ));

        iver_select_create_meta_box_field(array(
            'name'        => 'iver_hotel_room_full_address_longitude',
            'type'        => 'text',
            'label'       => esc_html__('Longitude', 'iver-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3,
                'custom_class' => 'qodef-address-elements',
                'input-data' => array(
                    'data-geo' => 'lng'
                )
            )
        ));

        iver_select_create_meta_box_field(array(
            'name'        => 'iver_hotel_room_simple_address_meta',
            'type'        => 'text',
            'label'       => esc_html__('Simple Address', 'iver-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3
            )
        ));

	    iver_select_create_meta_box_field(array(
		    'name'        => 'iver_hotel_room_email_meta',
		    'type'        => 'text',
		    'label'       => esc_html__('Email', 'iver-hotel'),
		    'parent'      => $hotel_room_address_container,
		    'args'        => array(
			    'col_width' => 3
		    )
	    ));

	    iver_select_create_meta_box_field(array(
		    'name'        => 'iver_hotel_room_phone_meta',
		    'type'        => 'text',
		    'label'       => esc_html__('Phone', 'iver-hotel'),
		    'parent'      => $hotel_room_address_container,
		    'args'        => array(
			    'col_width' => 3
		    )
	    ));
    }

    add_action('iver_hotel_room_action_meta_fields', 'iver_hotel_map_hotel_room_address_meta', 30, 1);
}