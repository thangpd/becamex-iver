<?php $amenities = iver_hotel_room_get_hotel_room_taxonomy( 'amenity-tag' );
if ( isset( $amenities ) && count( $amenities ) > 0 ) { ?>
    <div class="qodef-hotel-room-amenity qodef-hotel-part-holder">
        <h3 class="qodef-hotel-room-title">
            <?php esc_html_e( 'Amenities', 'iver-hotel' ); ?>
        </h3>
        <div class="qodef-hotel-room-items-style qodef-grid-row clearfix">
			<?php foreach ( $amenities as $amenity ) { ?>
                <div class="qodef-tag-item qodef-grid-col-4">
                    <p class="qodef-hr-amenity-title">
						<?php echo esc_html( $amenity->name ); ?>
                    </p>
                    <?php if($amenity->description != '') { ?>
                        <p>
                            <?php echo esc_html( $amenity->description ); ?>
                        </p>
                    <?php } ?>
                </div>
			<?php } ?>
        </div>
    </div>
<?php }