<div class="qodef-full-width">
    <div class="qodef-full-width-inner clearfix">
        <div class="qodef-hotel-room-search-holder">
            <div class="qodef-container">
                <div class="qodef-container-inner">
                    <div class="qodef-grid-row <?php echo esc_attr($holder_classes); ?>">
                        <div <?php echo iver_select_get_content_sidebar_class(); ?>>
                            <?php
                            iver_hotel_get_cpt_single_module_template_part( 'templates/search/parts/search-hotel', 'hotel-room', '', array( 'params' => $params ) );
                            ?>
                        </div>
                        <?php if($sidebar_layout !== 'no-sidebar') { ?>
                            <div <?php echo iver_select_get_sidebar_holder_class(); ?>>
                                <?php get_sidebar(); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>