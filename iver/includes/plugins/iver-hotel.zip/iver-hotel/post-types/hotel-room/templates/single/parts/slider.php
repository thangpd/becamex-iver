<?php extract( apply_filters( 'iver_select_hotel_single_slider_params', array() ) );

if($slider_images !== '') :

    $slider_images_array = explode( ',', $slider_images );
    if ( isset( $slider_images_array ) && count( $slider_images_array ) ) : ?>

	<div class="qodef-owl-slider" data-enable-thumbnail='yes'>
        <?php
        for ( $i = 0; $i < count( $slider_images_array ); $i ++ ) : ?>
            <?php if ( isset( $slider_images_array[ $i ] ) ) : ?>
                <div class="qodef-hotel-room-slider-item">
                    <a href="<?php echo wp_get_attachment_url( $slider_images_array[ $i ] ) ?>"
                       data-rel="prettyPhoto[gallery_excerpt_pretty_photo]">
                        <?php echo wp_get_attachment_image( $slider_images_array[ $i ], 'full' ); ?>
                    </a>
                </div>
            <?php endif; ?>
        <?php endfor; ?>
    </div>

    <ul class="qodef-slider-thumbnail" data-thumbnail-count="<?php echo count( $slider_images_array )?>">
        <?php
        for ( $i = 0; $i < count( $slider_images_array ); $i ++ ) : ?>
            <?php if ( isset( $slider_images_array[ $i ] ) ) : ?>
                <li class="qodef-slider-thumbnail-item">
                    <?php echo wp_get_attachment_image( $slider_images_array[ $i ], 'full' ); ?>
                </li>
            <?php endif; ?>
        <?php endfor; ?>
    </ul>

    <?php endif; ?>




<?php endif; ?>