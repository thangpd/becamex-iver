<h2 class="qodef-hotel-room-single-title">
	<?php the_title(); ?>
</h2>