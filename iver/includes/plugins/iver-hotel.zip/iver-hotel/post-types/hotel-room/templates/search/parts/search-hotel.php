<?php

$params['boxed_layout'] = 'no';

?>

<?php echo iver_select_execute_shortcode('iver_hotel_room_list', $params); ?>