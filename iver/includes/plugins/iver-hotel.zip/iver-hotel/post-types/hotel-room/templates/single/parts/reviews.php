<div class="qodef-hotel-room-reviews-list-top">
	<?php
        if(iver_select_core_plugin_installed()) {
            echo iver_core_list_review_details('per-criteria');
        }
    ?>
</div>
<?php
comments_template('', true);