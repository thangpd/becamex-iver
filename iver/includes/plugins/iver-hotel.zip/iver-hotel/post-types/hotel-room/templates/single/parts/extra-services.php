<?php extract( apply_filters( 'iver_select_hotel_single_extra_services_params', array() ) );
if ( ( isset( $extra_services ) && count( $extra_services ) > 0 )) {
	?>
    <div class="qodef-hotel-room-extra-service qodef-hotel-part-holder">
        <h3 class="qodef-hotel-room-title">
				<?php esc_html_e( 'Extra Services', 'iver-hotel' ); ?>
        </h3>
        <div class="qodef-hotel-room-items-style qodef-grid-row clearfix">
            <?php foreach ( $extra_services as $extra_service ) { ?>
                <div class="qodef-grid-col-12">
                    <div class="qodef-tag-item qodef-label-items-item">
                        <p class="qodef-label-items-label qodef-tag-item-name">
                            <?php echo esc_attr( $extra_service['name'] ); ?>
                        </p>
                        <div class="qodef-dot-item"></div>
                        <span class="qodef-label-items-value qodef-tag-item-service">
                            <?php echo iver_hotel_room_get_extra_service_string( $extra_service );
                                if ( iver_hotel_room_get_extra_service_type( $extra_service ) ) {
                                    esc_html_e( ' (*Mandatory)', 'iver-hotel' );
                                }
                        ?>
                        </span>
                    </div>
                    <?php echo esc_attr( $extra_service['description']); ?>
                </div>
            <?php } ?>
        </div>
    </div>
<?php }