<?php extract( apply_filters( 'iver_select_hotel_single_active_tabs_params', array() ) );
?>
<div class="qodef-container">
    <div class="qodef-container-inner clearfix">
        <div class="qodef-hotel-room-single-content-holder">
            <div class="qodef-grid-row qodef-grid-small-gutter">
                <div class="qodef-grid-col-9">
                    <div class="qodef-hotel-room-single-outer">

                        <?php

                        if ( $featured_item == 'slider' ) {
                            echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/slider', 'hotel-room', '', $params );
                        } else {
                            echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/featured-image', 'hotel-room', '', $params );
                        }

                        ?>

                        <div class="qodef-hr-item-wrapper qodef-tabs qodef-horizontal qodef-tab-text">

                            <ul class="qodef-tabs-nav clearfix">
                                <?php foreach ( $hotel_tabs as $hotel_tab ) { ?>

                                    <li class="qodef-hotel-room-nav-item">

                                        <a href="<?php echo esc_attr( $hotel_tab['id'] ) ?>">

                                            <span class="qodef-hotel-room-nav-section-title">
                                                <?php echo esc_html( $hotel_tab['title'] ) ?>
                                            </span>

                                        </a>
                                    </li>
                                <?php }; ?>
                            </ul>

                            <div class="qodef-hr-item-section qodef-tab-container"
                                 id="<?php echo esc_attr( $hotel_tabs['description']['id'] ) ?>">
                                <?php

                                echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/description', 'hotel-room', '', $params );

                                if ( $hotel_info['amenities'] == 'yes' ) {

                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/amenities', 'hotel-room', '', $params );
                                }

                                if ( $hotel_info['extra_services'] == 'yes' ) {

                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/extra-services', 'hotel-room', '', $params );
                                }


                                ?>
                            </div>

                            <?php if ( $hotel_info['gallery'] == 'yes' ) { ?>
                                <div class="qodef-hr-item-section qodef-tab-container"
                                     id="<?php echo esc_attr( $hotel_tabs['gallery']['id'] ) ?>">
                                    <?php

                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/gallery', 'hotel-room', '', $params );

                                    ?>
                                </div>

                            <?php } ?>

                            <?php if ( $hotel_info['location'] == 'yes' ) { ?>
                                <div class="qodef-hr-item-section qodef-tab-container"
                                     id="<?php echo esc_attr( $hotel_tabs['location']['id'] ) ?>">
                                    <?php

                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/google-map', 'hotel-room', '', $params );
                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/location', 'hotel-room', '', $params );

                                    ?>
                                </div>

                            <?php } ?>

                            <?php if ( $hotel_info['reviews'] == 'yes' ) { ?>
                                <div class="qodef-hr-item-section qodef-tab-container"
                                     id="<?php echo esc_attr( $hotel_tabs['reviews']['id'] ) ?>">
                                    <?php

                                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/reviews', 'hotel-room', '', $params );

                                    ?>
                                </div>

                            <?php } ?>

                        </div>
                    </div>
                </div>
                <div class="qodef-grid-col-3">
                    <?php
                    echo iver_hotel_get_cpt_single_module_template_part( 'templates/single/parts/reservation', 'hotel-room', '', $params );
                    dynamic_sidebar( 'hotel-room-single-sidebar' ); ?>
                </div>
            </div>
        </div>
    </div>
</div>