<div class="qodef-container">
    <div class="qodef-container-inner clearfix">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="qodef-hotel-room-single-holder">
				<?php if ( post_password_required() ) {
					echo get_the_password_form();
				} else { ?>
					<?php

					do_action( 'iver_select_hotel_room_page_before_content' );

					iver_hotel_get_cpt_single_module_template_part( 'templates/single/layout-collections/default', 'hotel-room', '', $params );

					do_action( 'iver_select_hotel_room_page_after_content' );

					?>
				<?php } ?>
			</div>
		<?php endwhile; endif; ?>
	</div>
</div>