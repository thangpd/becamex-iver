<?php
extract( apply_filters( 'iver_select_hotel_single_reservation_params', array() ) );
$input_array = apply_filters( 'iver_select_extra_services', array() );
$today  = date('Y-m-d');
$tomorrow  = date('Y-m-d', mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));
?>

<div class="qodef-hotel-room-reservation-holder">
    <h3>
		<?php esc_html_e( 'Your Reservation', 'iver-hotel' ); ?>
    </h3>
    <div class="qodef-hotel-room-reservation" data-room-id="<?php echo get_the_ID(); ?>">
        <form id="qodef-hotel-room-form" method="POST">
	        <?php wp_nonce_field('iver_hotel_room_booking_form', 'iver_hotel_room_booking_form'); ?>
            <div class="qodef-grid-row">
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-email">
                        <label><?php esc_html_e( 'Email:', 'iver-hotel' ); ?></label>
                        <input type="text" class="qodef-res-email" name="user_email"
                               placeholder="<?php esc_attr_e( 'Need to be logged in', 'iver-hotel' ) ?>" disabled value="<?php echo esc_attr($email) ?>" />
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-min-date">
                        <label><?php esc_html_e( 'Check in:', 'iver-hotel' ); ?></label>
                        <input type="text" class="qodef-res-min-date" name="room_min_date" placeholder="<?php esc_attr_e( 'Select', 'iver-hotel' ) ?>" value=""/>
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-max-date">
                        <label><?php esc_html_e( 'Check out:', 'iver-hotel' ); ?></label>
                        <input type="text" class="qodef-res-max-date" name="room_max_date" placeholder="<?php esc_attr_e( 'Select', 'iver-hotel' ) ?>" value=""/>
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-rooms-number">
                        <label><?php esc_html_e( 'Rooms:', 'iver-hotel' ); ?></label>
                        <select name="room_number" class="qodef-res-rooms-number">
                            <?php for ( $i = 1; $i <= $number_of_rooms; $i ++ ) { ?>
                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-adults">
                        <label><?php esc_html_e( 'Adults:', 'iver-hotel' ); ?></label>
                        <select name="room_adults" class="qodef-res-adults">
                            <option value="0">0</option>
                            <?php for ( $i = 1; $i <= $adults; $i ++ ) { ?>
                                <option <?php echo (esc_attr($adults) == $i) ? 'selected="selected"' : ''; ?> value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <span class="qodef-input-children">
                        <label><?php esc_html_e( 'Children:', 'iver-hotel' ); ?></label>
                        <select name="room_children" class="qodef-res-children">
                            <option value="0">0</option>
	                        <?php for ( $i = 1; $i <= $children; $i ++ ) { ?>
	                            <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	                        <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="qodef-grid-col-12">
                    <div class="qodef-input-extra-services-on-res">
                        <label><?php esc_html_e( 'Extra Services:', 'iver-hotel' ); ?></label>
                        <div class="qodef-res-extra-services-holder">
                            <?php foreach ( $input_array as $service_pack => $value ) { ?>
	                            <div class="qodef-res-extra-service-item" <?php echo iver_select_get_inline_attrs($value['data']) ?>>
                                    <input type="checkbox" <?php  echo ! empty( $value['type'] ) && $value['type'] == 'mandatory' ? 'checked disabled' : ''; ?>
                                           class="qodef-res-extra-service-checkbox" id="<?php echo esc_attr( $value['exs_id'] ); ?>"
                                           name="checked_extra_services[]" value="<?php echo esc_attr( $value['exs_id'] ); ?>"/>
                                    <label class="qodef-checkbox-label" for="<?php echo esc_attr( $value['exs_id'] ); ?>">
                                        <span class="qodef-label-view"></span>
                                        <span class="qodef-label-text">
                                            <?php echo esc_attr($value['name']); ?>
                                        </span>
                                    </label>
	                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="qodef-grid-col-12">
                    <div class="qodef-input-initial-price-on-res">
                        <label><?php esc_html_e( 'Initial Price', 'iver-hotel' ); ?></label>
                        <span class="qodef-res-initial-price">
                            <span class="qodef-res-price-currency"><?php echo esc_attr( $currency ) ?></span><span class="qodef-res-price-number"><?php echo esc_attr( intval( $initial_price ) ) ?></span>
                        </span>
                    </div>
                </div>
                <div class="qodef-grid-col-12">
                    <div class="qodef-input-end-price-on-res">
                        <label><?php esc_html_e( 'Your Price', 'iver-hotel' ); ?></label>
                        <span class="qodef-res-end-price">
                            <span class="qodef-res-price-currency"><?php echo esc_attr( $currency ) ?></span><span class="qodef-res-price-number"><?php echo esc_attr( intval( $initial_price ) ) ?></span>
                        </span>
                    </div>
                </div>
                <div class="qodef-grid-col-12">
	                <?php if ( ! $in_cart ) {
		                echo iver_select_get_button_html( array(
			                'html_type'    => 'button',
			                'input_name'   => 'submit',
			                'custom_class' => 'qodef-hotel-room-single-res-button qodef-hotel-room-single-res-check',
			                'size'         => 'medium',
			                'type'         => 'solid',
			                'text'         => esc_html__( 'Check', 'iver-hotel' )
		                ) );
		                echo iver_select_get_button_html( array(
			                'html_type'    => 'button',
			                'custom_class' => 'qodef-hotel-room-single-res-checking qodef-disable-hotel-room-single-btn qodef-hotel-room-single-res-button',
			                'size'         => 'medium',
			                'type'         => 'solid',
			                'text'         => esc_html__( 'Checking', 'iver-hotel' )
		                ) );
	                } ?>
                    <input type="hidden" name="room_id" value="<?php echo esc_attr(get_the_ID()); ?>">
                </div>
            </div>
            <div id="reservation-validation-messages-holder"></div>
        </form>
	    <?php if ( ! $in_cart ) {
		    echo iver_select_get_button_html( array(
			    'custom_class' => 'qodef-hotel-room-reservation-similar qodef-disable-hotel-room-single-btn',
			    'size'         => 'medium',
			    'link'         => iver_hotel_room_get_search_page_url(),
			    'type'         => 'solid',
			    'text'         => esc_html__( 'Check Similar', 'iver-hotel' )
		    ) );
		
		    echo iver_hotel_room_get_buy_form();
	    } else {
		    echo iver_select_get_button_html( array(
			    'custom_class' => 'qodef-hotel-room-reservation-cart',
			    'size'         => 'medium',
			    'link'         => esc_url( wc_get_cart_url() ),
			    'type'         => 'solid',
			    'text'         => esc_html__( 'View Cart', 'iver-hotel' )
		    ) );
	    }
	    ?>
    </div>
</div>