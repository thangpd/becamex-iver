<?php

$html = '';

switch ( $service_pack ) {
	case 'add_to_price' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price','iver-hotel');
		break;
	}
	case 'add_to_price_per_night' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price (per night)','iver-hotel');
		break;
	}
	case 'add_to_price_per_person' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price per person','iver-hotel');
		break;
	}
	case 'add_to_price_per_person_per_night' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price per person per night','iver-hotel');
		break;
	}
	case 'subtract_from_price' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '- ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('from price','iver-hotel');
		break;
	}
	case 'subtract_from_price_per_night' : {
		$html .= '<span class="qodef-extra-services-value-marked">' . '- ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('from price per night','iver-hotel');
		break;
	}
	case 'increase_price_by_percent_amount' : {
		$html .='<span class="qodef-extra-services-value-marked">'. '+ ' . esc_attr( $percent ). ' ' .'</span>';
		$html .= esc_html__('to price','iver-hotel');
		break;
	}
	case 'decrease_price_by_percent_amount' : {
		$html .= '<span class="qodef-extra-services-value-marked">'. '- ' . esc_attr( $percent ). ' ' . '</span>';
		$html .= esc_html__('from price','iver-hotel');
		break;
	}
	default : {

	}
		break;
}

print iver_select_get_module_part( $html );
