<?php extract( apply_filters( 'iver_select_hotel_single_location_params', array() ) ); ?>
<div class="qodef-hotel-room-location qodef-hotel-part-holder">
    <h3 class="qodef-hotel-room-title">
		<?php esc_html_e( 'Address', 'iver-hotel' ); ?>
    </h3>
    <div class="qodef-hotel-room-items-style qodef-grid-row clearfix">

		<?php if ( isset( $location ) && ( $location != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label><?php esc_html_e( 'City:', 'iver-hotel' ); ?></label>
                <span class="qodef-label-items-value">
                    <a href="<?php echo get_term_link( $location->term_id ); ?>">
                        <?php echo esc_html( $location->name ); ?>
                    </a>
                </span>
            </div>
		<?php }
		if ( isset( $full_address ) && ( $full_address != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label>
					<?php esc_html_e( 'Full Address:', 'iver-hotel' ); ?>
                </label>
                <span class="qodef-label-items-value">
                    <?php echo esc_html( $full_address ); ?>
                </span>
            </div>
		<?php }
		if ( isset( $simple_address ) && ( $simple_address != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label>
					<?php esc_html_e( 'Simple Address:', 'iver-hotel' ); ?>
                </label>
                <span class="qodef-label-items-value">
                    <?php echo esc_html( $simple_address ); ?>
                </span>
            </div>
		<?php }
		if ( isset( $email ) && ( $email != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label>
					<?php esc_html_e( 'Email:', 'iver-hotel' ); ?>
                </label>
                <span class="qodef-label-items-value">
                    <?php echo esc_html( $email ); ?>
                </span>
            </div>
		<?php }
		if ( isset( $country ) && ( $country != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label>
					<?php esc_html_e( 'Country:', 'iver-hotel' ); ?>
                </label>
                <span class="qodef-label-items-value">
                    <?php echo esc_html( $country ); ?>
                </span>
            </div>
		<?php }
        if ( isset( $phone ) && ( $phone != '' ) ) { ?>
            <div class="qodef-grid-col-6">
                <label>
                    <?php esc_html_e( 'Phone:', 'iver-hotel' ); ?>
                </label>
                <span class="qodef-label-items-value">
                    <?php echo esc_html( $phone ); ?>
                </span>
            </div>
        <?php } ?>

    </div>
</div>