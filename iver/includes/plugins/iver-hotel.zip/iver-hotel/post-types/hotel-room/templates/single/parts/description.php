<div class="qodef-hotel-room-description qodef-hotel-part-holder">
    <h3 class="qodef-hotel-room-title">
        <?php esc_html_e('Room Details', 'iver-hotel'); ?>
    </h3>
	<div class="qodef-hotel-room-items-style clearfix">
		<?php the_content(); ?>
	</div>
</div>