<?php extract( apply_filters( 'iver_select_hotel_single_google_map_params', array() ) ); ?>
<div class="qodef-hotel-room-map qodef-hotel-part-holder">
    <h3 class="qodef-hotel-room-title">
			<?php esc_html_e( 'Location', 'iver-hotel' ); ?>
    </h3>
    <div class="qodef-hotel-room-map-object">
        <?php echo iver_select_execute_shortcode('qodef_google_map', $google_map_params); ?>
    </div>
</div>