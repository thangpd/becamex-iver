<?php
$image_gallery_val = get_post_meta(get_the_ID(), 'hotel_room_gallery_images', true);

if($image_gallery_val !== '') : ?>

	<div class="qodef-hotel-room-gallery-item-holder">

		<h3 class="qodef-hotel-room-gallery-title">
			<?php esc_html_e('From our gallery', 'iver-hotel'); ?>
		</h3>

		<div class="qodef-hotel-room-gallery clearfix">
			<?php
			$image_gallery_array = explode(',', $image_gallery_val);
			if(isset($image_gallery_array) && count($image_gallery_array)) : ?>

				<?php for($i = 0; $i < count($image_gallery_array); $i++) : ?>
					<?php if(isset($image_gallery_array[$i])) : ?>
						<div class="qodef-hotel-room-gallery-item">
							<a href="<?php echo wp_get_attachment_url($image_gallery_array[$i]) ?>" data-rel="prettyPhoto[gallery_excerpt_pretty_photo]">
								<?php echo wp_get_attachment_image($image_gallery_array[$i], 'iver_select_square'); ?>
							</a>
						</div>
					<?php endif; ?>
				<?php endfor; ?>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>