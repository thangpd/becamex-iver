<?php

if(!function_exists('iver_hotel_add_profile_navigation_item')) {

	function iver_hotel_add_profile_navigation_item($navigation, $dashboard_url) {

        $navigation['hotel-reservations'] = array(
            'url'  => esc_url(add_query_arg( array( 'user-action' => 'hotel-reservations' ), $dashboard_url)),
            'text' => esc_html__( 'Reserved rooms', 'iver-hotel'),
            'user_action' => 'hotel-reservations',
            'icon' => '<i class="fa fa-bed" aria-hidden="true"></i>'
        );

        $navigation['hotel-favorites'] = array(
            'url'         => esc_url( add_query_arg( array( 'user-action' => 'hotel-favorites' ), $dashboard_url ) ),
            'text'        => esc_html__( 'Favorite Rooms', 'iver-hotel' ),
            'user_action' => 'hotel-favorites',
            'icon'        => '<i class="fa fa-heart" aria-hidden="true"></i>'
        );

		return $navigation;
	}

	//add_filter('iver_membership_dashboard_navigation_pages', 'iver_hotel_add_profile_navigation_item', 10, 2);
}

if(!function_exists('iver_hotel_add_profile_navigation_pages')) {

	function iver_hotel_add_profile_navigation_pages($page, $action) {

        if( $action == 'hotel-reservations' ) {
            $reservation_params = array();
            $customer_orders = iver_hotel_get_user_profile_reservation_items();
            $reservation_params['customer_orders'] = $customer_orders;
            $page = iver_hotel_return_cpt_single_module_template_part('profile/templates/reservations-list', 'hotel-room', '', $reservation_params);
        }
        else if( $action == 'hotel-favorites' ) {
            $favorites_params = array();
            $user_favorites = iver_membership_get_user_favorites(get_current_user_id(), array('hotel-room'));
            $favorites_params['user_favorites'] = $user_favorites;
            $page = iver_hotel_return_cpt_single_module_template_part('profile/templates/favorites-list', 'hotel-room', '', $favorites_params);
        }

		return $page;
	}

	add_filter('iver_membership_dashboard_pages', 'iver_hotel_add_profile_navigation_pages', 10, 2);
}

if(!function_exists('iver_hotel_get_user_profile_reservation_items')) {
    function iver_hotel_get_user_profile_reservation_items() {
        $formatted_orders = iver_checkout_get_user_order_items('WC_Order_Item_Hotel_Room');

        return $formatted_orders;
    }
}