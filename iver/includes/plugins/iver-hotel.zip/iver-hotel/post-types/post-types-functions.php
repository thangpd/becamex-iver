<?php

if(!function_exists('iver_hotel_include_custom_post_types_files')) {
	/**
	 * Loads all custom post types by going through all folders that are placed directly in post types folder
	 */
	function iver_hotel_include_custom_post_types_files() {
		if(iver_hotel_theme_installed()) {
			foreach (glob(IVER_HOTEL_CPT_PATH . '/*/load.php') as $cpt_load) {
				include_once $cpt_load;
			}
		}
	}
	
	add_action('after_setup_theme', 'iver_hotel_include_custom_post_types_files', 1);
}

if(!function_exists('iver_hotel_include_custom_post_types_meta_boxes')) {
	/**
	 * Loads all meta boxes functions for custom post types by going through all folders that are placed directly in post types folder
	 */
	function iver_hotel_include_custom_post_types_meta_boxes() {
		if(iver_hotel_theme_installed()) {
			foreach(glob(IVER_HOTEL_CPT_PATH . '/*/admin/meta-boxes/*.php') as $meta_boxes_map) {
				include_once $meta_boxes_map;
			}
		}
	}

	add_action('iver_select_before_meta_boxes_map', 'iver_hotel_include_custom_post_types_meta_boxes');
}