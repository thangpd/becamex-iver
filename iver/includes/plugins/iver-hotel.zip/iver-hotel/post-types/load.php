<?php

//require_once 'hotel-room/lib/hotel-room-query.php';
require_once 'hotel-room/lib/hotel-room-search.php';
//require_once 'hotel-room/lib/hotel-room-pagination.php';
require_once 'hotel-room/lib/booking-handler.php';
//require_once 'hotel-room/lib/hotel-room-price-helper.php';
require_once 'hotel-room/lib/helpers.php';
//require_once 'hotel-room/lib/template-helpers.php';
require_once 'hotel-room/lib/page-templater.php';