<?php
/*
Plugin Name: Iver Hotel
Description: Plugin that adds post types for Hotel extension
Author: Select Themes
Version: 1.0.3
*/

include_once 'load.php';

define( 'IVER_HOTEL_MAIN_FILE_PATH', __FILE__ );

use IverHotel\DatabaseSetup\TablesSetup;
use IverHotel\CPT\HotelRoom\Lib\PageTemplater;
use IverHotel\CPT\HotelRoom\Lib\BookingHandler;

add_action( 'after_setup_theme', array( IverHotel\CPT\PostTypesRegister::getInstance(), 'register' ) );

PageTemplater::getInstance()->initialize();
BookingHandler::getInstance()->initialize();

if ( ! function_exists( 'iver_hotel_load_assets' ) ) {
	function iver_hotel_load_assets() {
		$array_deps_css            = array();
		$array_deps_css_responsive = array();
		$array_deps_js             = array();
		
		if ( iver_hotel_theme_installed() ) {
			$array_deps_css[]            = 'select-iver-modules';
			$array_deps_css_responsive[] = 'select-iver-modules-responsive';
			$array_deps_js[]             = 'select-iver-modules';
			$array_deps_js[]             = 'select2';
			$array_deps_js[]             = 'rangeslider';
		}
		
		wp_enqueue_style( 'iver-hotel-style', plugins_url( '/assets/css/hotel.css', __FILE__ ), $array_deps_css );
		if ( function_exists( 'iver_select_is_responsive_on' ) && iver_select_is_responsive_on() ) {
			wp_enqueue_style( 'iver-hotel-responsive-style', plugins_url( '/assets/css/hotel-responsive.css', __FILE__ ), $array_deps_css_responsive );
		}
		
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'rangeslider', IVER_HOTEL_URL_PATH . 'assets/js/plugins/rangeslider.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'select2', IVER_HOTEL_URL_PATH . 'assets/js/plugins/select2.min.js', array( 'jquery' ), false, true );
		
		wp_enqueue_script( 'jquery-ui-slider' );
		if ( wp_is_mobile() ) {
			wp_enqueue_script( 'jquery-touch-punch' );
		}
		
		wp_enqueue_script( 'qodef-hotel-script', plugins_url( '/assets/js/hotel.min.js', __FILE__ ), $array_deps_js, false, true );
	}
	
	add_action( 'wp_enqueue_scripts', 'iver_hotel_load_assets' );
}

if ( ! function_exists( 'iver_hotel_load_admin_assets' ) ) {
	function iver_hotel_load_admin_assets() {
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_style( 'qodef-jquery-ui', get_template_directory_uri() . '/framework/admin/assets/css/jquery-ui/jquery-ui.css' );
	}
	
	add_action( 'admin_enqueue_scripts', 'iver_hotel_load_admin_assets' );
}

if ( ! function_exists( 'iver_hotel_style_dynamics_deps' ) ) {
	function iver_hotel_style_dynamics_deps( $deps ) {
		$style_dynamic_deps_array   = array();
		$style_dynamic_deps_array[] = 'iver-hotel-style';
		
		if ( function_exists( 'iver_select_is_responsive_on' ) && iver_select_is_responsive_on() ) {
			$style_dynamic_deps_array[] = 'iver-hotel-responsive-style';
		}
		
		return array_merge( $deps, $style_dynamic_deps_array );
	}
	
	add_filter( 'iver_select_style_dynamic_deps', 'iver_hotel_style_dynamics_deps' );
}

if ( ! function_exists( 'iver_hotel_add_maps_extensions' ) ) {
	function iver_hotel_add_maps_extensions( $extensions ) {
		$items      = array(
			'geometry',
			'places'
		);
		$extensions = array_unique( array_merge( $extensions, $items ) );
		
		return $extensions;
	}
	
	add_filter( 'iver_select_google_maps_extensions_array', 'iver_hotel_add_maps_extensions', 10, 1 );
}

if ( ! function_exists( 'iver_hotel_enable_maps_in_admin' ) ) {

	function iver_hotel_enable_maps_in_admin() {
		return true;
	}
	
	add_action( 'iver_select_google_maps_in_backend', 'iver_hotel_enable_maps_in_admin' );
}