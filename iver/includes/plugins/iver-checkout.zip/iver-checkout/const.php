<?php

define('IVER_CHECKOUT_INTEGRATION', '1.0.1');
define('IVER_CHECKOUT_INTEGRATION_PATH', dirname(__FILE__));
define('IVER_CHECKOUT_INTEGRATION_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('IVER_CHECKOUT_INTEGRATION_URL_PATH', plugin_dir_url( __FILE__ ));