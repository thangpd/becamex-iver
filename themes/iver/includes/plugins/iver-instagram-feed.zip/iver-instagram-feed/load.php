<?php

include_once 'lib/iver-instagram-api.php';

if(defined('SELECT_ROOT')){
	include_once 'widgets/load.php';
}
