<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Video
 */
class WPBakeryShortCode_Vc_Video extends WPBakeryShortCode {
}
