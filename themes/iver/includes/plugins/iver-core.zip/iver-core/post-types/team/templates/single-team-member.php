<?php

get_header();

iver_select_get_title();

do_action('iver_select_before_main_content');

iver_core_get_single_team();

get_footer();