<div class="qodef-team-single-info-holder">
	<div class="qodef-grid-row">
		<div class="qodef-ts-image-holder qodef-grid-col-6">
			<?php the_post_thumbnail(); ?>
		</div>
		<div class="qodef-ts-details-holder qodef-grid-col-6">
			<h3 itemprop="name" class="qodef-name entry-title"><?php the_title(); ?></h3>
			<p class="qodef-position"><?php echo esc_html($position); ?>
				<?php foreach ($social_icons as $social_icon) {
					echo wp_kses_post($social_icon);
				} ?>
			</p>
			<div class="qodef-ts-bio-holder">
				<?php if(!empty($birth_date)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_calendar qodef-ts-bio-icon"></span>
						<span class="qodef-ts-bio-info"><?php echo esc_html__('born on: ', 'iver-core').esc_html($birth_date); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($email)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_mail_alt qodef-ts-bio-icon"></span>
						<span itemprop="email" class="qodef-ts-bio-info"><?php echo esc_html__('email: ', 'iver-core').sanitize_email(esc_html($email)); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($phone)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_phone qodef-ts-bio-icon"></span>
						<span class="qodef-ts-bio-info"><?php echo esc_html__('phone: ', 'iver-core').esc_html($phone); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($address)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_building_alt qodef-ts-bio-icon"></span>
						<span class="qodef-ts-bio-info"><?php echo esc_html__('lives in: ', 'iver-core').esc_html($address); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($education)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_ribbon_alt qodef-ts-bio-icon"></span>
						<span class="qodef-ts-bio-info"><?php echo esc_html__('education: ', 'iver-core').esc_html($education); ?></span>
					</div>
				<?php } ?>
				<?php if(!empty($resume)) { ?>
					<div class="qodef-ts-info-row">
						<span aria-hidden="true" class="icon_document_alt qodef-ts-bio-icon"></span>
						<a href="<?php echo esc_url($resume); ?>" download target="_blank"><span class="qodef-ts-bio-info"><?php echo esc_html__('Download Resume', 'iver-core'); ?></span></a>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>