<?php

include_once IVER_CORE_CPT_PATH . '/team/team-register.php';
include_once IVER_CORE_CPT_PATH . '/team/helper-functions.php';