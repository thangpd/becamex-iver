<?php

if ( ! function_exists( 'iver_core_map_team_single_meta' ) ) {
	function iver_core_map_team_single_meta() {
		
		$meta_box = iver_select_create_meta_box(
			array(
				'scope' => 'team-member',
				'title' => esc_html__( 'Team Member Info', 'iver-core' ),
				'name'  => 'team_meta'
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Position', 'iver-core' ),
				'description' => esc_html__( 'The members\'s role within the team', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_birth_date',
				'type'        => 'date',
				'label'       => esc_html__( 'Birth date', 'iver-core' ),
				'description' => esc_html__( 'The members\'s birth date', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_email',
				'type'        => 'text',
				'label'       => esc_html__( 'Email', 'iver-core' ),
				'description' => esc_html__( 'The members\'s email', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_phone',
				'type'        => 'text',
				'label'       => esc_html__( 'Phone', 'iver-core' ),
				'description' => esc_html__( 'The members\'s phone', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_address',
				'type'        => 'text',
				'label'       => esc_html__( 'Address', 'iver-core' ),
				'description' => esc_html__( 'The members\'s addres', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_education',
				'type'        => 'text',
				'label'       => esc_html__( 'Education', 'iver-core' ),
				'description' => esc_html__( 'The members\'s education', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_resume',
				'type'        => 'file',
				'label'       => esc_html__( 'Resume', 'iver-core' ),
				'description' => esc_html__( 'Upload members\'s resume', 'iver-core' ),
				'parent'      => $meta_box
			)
		);
		
		for ( $x = 1; $x < 6; $x ++ ) {
			
			$social_icon_group = iver_select_add_admin_group(
				array(
					'name'   => 'qodef_team_member_social_icon_group' . $x,
					'title'  => esc_html__( 'Social Link ', 'iver-core' ) . $x,
					'parent' => $meta_box
				)
			);
			
			$social_row1 = iver_select_add_admin_row(
				array(
					'name'   => 'qodef_team_member_social_icon_row1' . $x,
					'parent' => $social_icon_group
				)
			);
			
			IverSelectIconCollections::get_instance()->getIconsMetaBoxOrOption(
				array(
					'label'            => esc_html__( 'Icon ', 'iver-core' ) . $x,
					'parent'           => $social_row1,
					'name'             => 'qodef_team_member_social_icon_pack_' . $x,
					'defaul_icon_pack' => '',
					'type'             => 'meta-box',
					'field_type'       => 'simple'
				)
			);
			
			$social_row2 = iver_select_add_admin_row(
				array(
					'name'   => 'qodef_team_member_social_icon_row2' . $x,
					'parent' => $social_icon_group
				)
			);
			
			iver_select_create_meta_box_field(
				array(
					'type'            => 'textsimple',
					'label'           => esc_html__( 'Link', 'iver-core' ),
					'name'            => 'qodef_team_member_social_icon_' . $x . '_link',
					'parent'          => $social_row2,
					'dependency' => array(
						'hide' => array(
							'qodef_team_member_social_icon_pack_'. $x  => ''
						)
					)
				)
			);
			
			iver_select_create_meta_box_field(
				array(
					'type'            => 'selectsimple',
					'label'           => esc_html__( 'Target', 'iver-core' ),
					'name'            => 'qodef_team_member_social_icon_' . $x . '_target',
					'options'         => iver_select_get_link_target_array(),
					'parent'          => $social_row2,
					'dependency' => array(
						'hide' => array(
							'qodef_team_member_social_icon_' . $x . '_link'  => ''
						)
					)
				)
			);
		}
	}
	
	add_action( 'iver_select_meta_boxes_map', 'iver_core_map_team_single_meta', 46 );
}