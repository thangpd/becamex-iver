<?php
require_once 'team-list.php';
require_once 'helper-functions.php';