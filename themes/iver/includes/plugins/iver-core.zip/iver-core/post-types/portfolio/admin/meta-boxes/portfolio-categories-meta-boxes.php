<?php

if ( ! function_exists( 'iver_select_portfolio_category_additional_fields' ) ) {
	function iver_select_portfolio_category_additional_fields() {
		
		$fields = iver_select_add_taxonomy_fields(
			array(
				'scope' => 'portfolio-category',
				'name'  => 'portfolio_category_options'
			)
		);
		
		iver_select_add_taxonomy_field(
			array(
				'name'   => 'qodef_portfolio_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'iver-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'iver_select_custom_taxonomy_fields', 'iver_select_portfolio_category_additional_fields' );
}