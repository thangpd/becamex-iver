<?php

if ( ! function_exists( 'iver_core_map_portfolio_meta' ) ) {
	function iver_core_map_portfolio_meta() {
		global $iver_Framework;
		
		$iver_pages = array();
		$pages      = get_pages();
		foreach ( $pages as $page ) {
			$iver_pages[ $page->ID ] = $page->post_title;
		}
		
		//Portfolio Images
		
		$iver_portfolio_images = new IverSelectMetaBox( 'portfolio-item', esc_html__( 'Portfolio Images (multiple upload)', 'iver-core' ), '', '', 'portfolio_images' );
		$iver_Framework->qodeMetaBoxes->addMetaBox( 'portfolio_images', $iver_portfolio_images );
		
		$iver_portfolio_image_gallery = new IverSelectMultipleImages( 'qodef-portfolio-image-gallery', esc_html__( 'Portfolio Images', 'iver-core' ), esc_html__( 'Choose your portfolio images', 'iver-core' ) );
		$iver_portfolio_images->addChild( 'qodef-portfolio-image-gallery', $iver_portfolio_image_gallery );
		
		//Portfolio Single Upload Images/Videos 
		
		$iver_portfolio_images_videos = iver_select_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Portfolio Images/Videos (single upload)', 'iver-core' ),
				'name'  => 'qodef_portfolio_images_videos'
			)
		);
		iver_select_add_repeater_field(
			array(
				'name'        => 'qodef_portfolio_single_upload',
				'parent'      => $iver_portfolio_images_videos,
				'button_text' => esc_html__( 'Add Image/Video', 'iver-core' ),
				'fields'      => array(
					array(
						'type'        => 'select',
						'name'        => 'file_type',
						'label'       => esc_html__( 'File Type', 'iver-core' ),
						'options' => array(
							'image' => esc_html__('Image','iver-core'),
							'video' => esc_html__('Video','iver-core'),
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'single_image',
						'label'       => esc_html__( 'Image', 'iver-core' ),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'image'
							)
						)
					),
					array(
						'type'        => 'select',
						'name'        => 'video_type',
						'label'       => esc_html__( 'Video Type', 'iver-core' ),
						'options'	  => array(
							'youtube' => esc_html__('YouTube', 'iver-core'),
							'vimeo' => esc_html__('Vimeo', 'iver-core'),
							'self' => esc_html__('Self Hosted', 'iver-core'),
						),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'video'
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_id',
						'label'       => esc_html__( 'Video ID', 'iver-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => array('youtube','vimeo')
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_mp4',
						'label'       => esc_html__( 'Video mp4', 'iver-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'video_cover_image',
						'label'       => esc_html__( 'Video Cover Image', 'iver-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					)
				)
			)
		);
		
		//Portfolio Additional Sidebar Items
		
		$iver_additional_sidebar_items = iver_select_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Additional Portfolio Sidebar Items', 'iver-core' ),
				'name'  => 'portfolio_properties'
			)
		);

		iver_select_add_repeater_field(
			array(
				'name'        => 'qodef_portfolio_properties',
				'parent'      => $iver_additional_sidebar_items,
				'button_text' => esc_html__( 'Add New Item', 'iver-core' ),
				'fields'      => array(
					array(
						'type'        => 'text',
						'name'        => 'item_title',
						'label'       => esc_html__( 'Item Title', 'iver-core' ),
					),
					array(
						'type'        => 'text',
						'name'        => 'item_text',
						'label'       => esc_html__( 'Item Text', 'iver-core' )
					),
					array(
						'type'        => 'text',
						'name'        => 'item_url',
						'label'       => esc_html__( 'Enter Full URL for Item Text Link', 'iver-core' )
					)
				)
			)
		);
	}
	
	add_action( 'iver_select_meta_boxes_map', 'iver_core_map_portfolio_meta', 40 );
}