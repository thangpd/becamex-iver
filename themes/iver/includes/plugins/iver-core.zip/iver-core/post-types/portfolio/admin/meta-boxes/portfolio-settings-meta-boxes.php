<?php

if ( ! function_exists( 'iver_core_map_portfolio_settings_meta' ) ) {
	function iver_core_map_portfolio_settings_meta() {
		$meta_box = iver_select_create_meta_box( array(
			'scope' => 'portfolio-item',
			'title' => esc_html__( 'Portfolio Settings', 'iver-core' ),
			'name'  => 'portfolio_settings_meta_box'
		) );
		
		iver_select_create_meta_box_field( array(
			'name'        => 'qodef_portfolio_single_template_meta',
			'type'        => 'select',
			'label'       => esc_html__( 'Portfolio Type', 'iver-core' ),
			'description' => esc_html__( 'Choose a default type for Single Project pages', 'iver-core' ),
			'parent'      => $meta_box,
			'options'     => array(
				''                  => esc_html__( 'Default', 'iver-core' ),
				'huge-images'       => esc_html__( 'Portfolio Full Width Images', 'iver-core' ),
				'images'            => esc_html__( 'Portfolio Images', 'iver-core' ),
				'small-images'      => esc_html__( 'Portfolio Small Images', 'iver-core' ),
				'slider'            => esc_html__( 'Portfolio Slider', 'iver-core' ),
				'small-slider'      => esc_html__( 'Portfolio Small Slider', 'iver-core' ),
				'gallery'           => esc_html__( 'Portfolio Gallery', 'iver-core' ),
				'small-gallery'     => esc_html__( 'Portfolio Small Gallery', 'iver-core' ),
				'masonry'           => esc_html__( 'Portfolio Masonry', 'iver-core' ),
				'small-masonry'     => esc_html__( 'Portfolio Small Masonry', 'iver-core' ),
				'custom'            => esc_html__( 'Portfolio Custom', 'iver-core' ),
				'full-width-custom' => esc_html__( 'Portfolio Full Width Custom', 'iver-core' )
			)
		) );
		
		/***************** Gallery Layout *****************/
		
		$gallery_type_meta_container = iver_select_add_admin_container(
			array(
				'parent'          => $meta_box,
				'name'            => 'qodef_gallery_type_meta_container',
				'dependency' => array(
					'show' => array(
						'qodef_portfolio_single_template_meta'  => array(
							'gallery',
							'small-gallery'
						)
					)
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_single_gallery_columns_number_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Number of Columns', 'iver-core' ),
				'default_value' => '',
				'description'   => esc_html__( 'Set number of columns for portfolio gallery type', 'iver-core' ),
				'parent'        => $gallery_type_meta_container,
				'options'       => array(
					''      => esc_html__( 'Default', 'iver-core' ),
					'two'   => esc_html__( '2 Columns', 'iver-core' ),
					'three' => esc_html__( '3 Columns', 'iver-core' ),
					'four'  => esc_html__( '4 Columns', 'iver-core' )
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_single_gallery_space_between_items_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'iver-core' ),
				'description'   => esc_html__( 'Set space size between columns for portfolio gallery type', 'iver-core' ),
				'default_value' => '',
				'options'       => iver_select_get_space_between_items_array( true ),
				'parent'        => $gallery_type_meta_container
			)
		);
		
		/***************** Gallery Layout *****************/
		
		/***************** Masonry Layout *****************/
		
		$masonry_type_meta_container = iver_select_add_admin_container(
			array(
				'parent'          => $meta_box,
				'name'            => 'qodef_masonry_type_meta_container',
				'dependency' => array(
					'show' => array(
						'qodef_portfolio_single_template_meta'  => array(
							'masonry',
							'small-masonry'
						)
					)
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_single_masonry_columns_number_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Number of Columns', 'iver-core' ),
				'default_value' => '',
				'description'   => esc_html__( 'Set number of columns for portfolio masonry type', 'iver-core' ),
				'parent'        => $masonry_type_meta_container,
				'options'       => array(
					''      => esc_html__( 'Default', 'iver-core' ),
					'two'   => esc_html__( '2 Columns', 'iver-core' ),
					'three' => esc_html__( '3 Columns', 'iver-core' ),
					'four'  => esc_html__( '4 Columns', 'iver-core' )
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_single_masonry_space_between_items_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'iver-core' ),
				'description'   => esc_html__( 'Set space size between columns for portfolio masonry type', 'iver-core' ),
				'default_value' => '',
				'options'       => iver_select_get_space_between_items_array( true ),
				'parent'        => $masonry_type_meta_container
			)
		);
		
		/***************** Masonry Layout *****************/
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_show_title_area_portfolio_single_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'iver-core' ),
				'description'   => esc_html__( 'Enabling this option will show title area on your single portfolio page', 'iver-core' ),
				'parent'        => $meta_box,
				'options'       => iver_select_get_yes_no_select_array()
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'portfolio_info_top_padding',
				'type'        => 'text',
				'label'       => esc_html__( 'Portfolio Info Top Padding', 'iver-core' ),
				'description' => esc_html__( 'Set top padding for portfolio info elements holder. This option works only for Portfolio Images, Slider, Gallery and Masonry portfolio types', 'iver-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'portfolio_external_link',
				'type'        => 'text',
				'label'       => esc_html__( 'Portfolio External Link', 'iver-core' ),
				'description' => esc_html__( 'Enter URL to link from Portfolio List page', 'iver-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'qodef_portfolio_featured_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Featured Image', 'iver-core' ),
				'description' => esc_html__( 'Choose an image for Portfolio Lists shortcode where Hover Type option is Switch Featured Images', 'iver-core' ),
				'parent'      => $meta_box
			)
		);

        iver_select_create_meta_box_field(
            array(
                'name'          => 'qodef_portfolio_masonry_layout_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Masonry Layout', 'iver-core'),
                'options'       => array(
                    'default'              => esc_html__('Default', 'iver-core'),
                    'description'   => esc_html__('Description', 'iver-core')
                ),
                'description'   => esc_html__( 'Used in Portfolio List Masonry Type when Gallery Overlay Style is enabled', 'iver-core' ),
                'parent'        => $meta_box,
            )
        );
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_masonry_fixed_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Fixed Proportion', 'iver-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type portfolio lists where image proportion is fixed', 'iver-core' ),
				'default_value' => '',
				'parent'        => $meta_box,
				'options'       => array(
					''                   => esc_html__( 'Default', 'iver-core' ),
					'small'              => esc_html__( 'Small', 'iver-core' ),
					'large-width'        => esc_html__( 'Large Width', 'iver-core' ),
					'large-height'       => esc_html__( 'Large Height', 'iver-core' ),
					'large-width-height' => esc_html__( 'Large Width/Height', 'iver-core' )
				)
			)
		);
		
		iver_select_create_meta_box_field(
			array(
				'name'          => 'qodef_portfolio_masonry_original_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Original Proportion', 'iver-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type portfolio lists where image proportion is original', 'iver-core' ),
				'default_value' => 'default',
				'parent'        => $meta_box,
				'options'       => array(
					'default'     => esc_html__( 'Default', 'iver-core' ),
					'large-width' => esc_html__( 'Large Width', 'iver-core' )
				)
			)
		);
		
		$all_pages = array();
		$pages     = get_pages();
		foreach ( $pages as $page ) {
			$all_pages[ $page->ID ] = $page->post_title;
		}
		
		iver_select_create_meta_box_field(
			array(
				'name'        => 'portfolio_single_back_to_link',
				'type'        => 'select',
				'label'       => esc_html__( '"Back To" Link', 'iver-core' ),
				'description' => esc_html__( 'Choose "Back To" page to link from portfolio Single Project page', 'iver-core' ),
				'parent'      => $meta_box,
				'options'     => $all_pages,
				'args'        => array(
					'select2' => true
				)
			)
		);
	}
	
	add_action( 'iver_select_meta_boxes_map', 'iver_core_map_portfolio_settings_meta', 41 );
}