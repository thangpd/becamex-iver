<?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<?php $masonry_layout = get_post_meta(get_the_ID(), 'qodef_portfolio_masonry_layout_meta', true); ?>
<div class="qodef-pli-text-holder">
	<div class="qodef-pli-text-wrapper">
		<div class="qodef-pli-text">
			<?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/title', $item_style, $params); ?>

            <?php if($masonry_layout !== 'description') { ?>

                <?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/category', $item_style, $params); ?>

                <?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/images-count', $item_style, $params); ?>

            <?php } ?>

            <?php if($masonry_layout == 'description') { ?>

                <?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/excerpt-masonry-description', $item_style, $params); ?>

            <?php } else { ?>
			
                <?php echo iver_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/excerpt', $item_style, $params); ?>

            <?php } ?>

            <?php if($masonry_layout == 'description') { ?>

                <?php echo iver_select_get_button_html(array(
                    'link' => $this_object->getItemLink(),
                    'text' => 'Book Now',
                    'type' => 'simple',
                    'size' => 'medium',
                    'target' => $this_object->getItemLinkTarget()
                )); ?>

            <?php } ?>

		</div>
	</div>
</div>