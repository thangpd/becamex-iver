<?php if ($excerpt_length !== '0' && $excerpt_length !== '') {
	$excerpt = ($excerpt_length > 0) ? get_the_excerpt() : get_the_excerpt();
    ?>
	<p itemprop="description" class="qodef-pli-excerpt"><?php echo esc_html($excerpt); ?></p>
<?php } ?>