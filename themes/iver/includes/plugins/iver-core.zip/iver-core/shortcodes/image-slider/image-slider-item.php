<?php
namespace IverCore\CPT\Shortcodes\ImageSliderItem;

use IverCore\Lib;

class ImageSliderItem implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'qodef_image_slider_item';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name'                    => esc_html__('Image Slider Item', 'iver-core'),
                    'base'                    => $this->getBase(),
                    'category'                => esc_html__('by IVER', 'iver-core'),
                    'icon'                    => 'icon-wpb-image-slider-item extended-custom-icon',
                    'as_child'                => array('only' => 'qodef_image_slider'),
                    'as_parent'               => array('except' => 'vc_row'),
                    'show_settings_on_create' => true,
                    'params'                  => array(
                        array(
                            'type'        => 'attach_image',
                            'param_name'  => 'image',
                            'heading'     => esc_html__('Image', 'iver-core'),
                            'description' => esc_html__('Select image from media library', 'iver-core')
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'subtitle',
                            'heading'    => esc_html__('Subtitle', 'iver-core'),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'subtitle_tag',
                            'heading'     => esc_html__('Subtitle Tag', 'iver-core'),
                            'value'       => array_flip(iver_select_get_title_tag(true, array('p', 'span'))),
                            'save_always' => true,
                            'dependency'  => array('element' => 'subtitle', 'not_empty' => true)
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'title',
                            'heading'    => esc_html__('Title', 'iver-core'),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'title_tag',
                            'heading'     => esc_html__('Title Tag', 'iver-core'),
                            'value'       => array_flip(iver_select_get_title_tag(true)),
                            'save_always' => true,
                            'dependency'  => array('element' => 'title', 'not_empty' => true)
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'button_text',
                            'heading'     => esc_html__('Button Text', 'iver-core'),
                            'value'       => esc_html__('READ MORE', 'iver-core'),
                            'save_always' => true
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'link',
                            'heading'    => esc_html__('Button Link', 'iver-core'),
                            'dependency' => array('element' => 'button_text', 'not_empty' => true)
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'image'        => '',
            'subtitle'     => '',
            'subtitle_tag' => 'span',
            'title'        => '',
            'title_tag'    => 'h1',
            'link'         => '',
            'button_text'  => ''
        );
        $params = shortcode_atts($args, $atts);

        $params['subtitle_tag']    = ! empty( $subtitle_tag ) ? $params['subtitle_tag'] : $args['subtitle_tag'];
        $params['title_tag']    = ! empty( $subtitle_tag ) ? $params['title_tag'] : $args['title_tag'];

        $html = iver_core_get_shortcode_module_template_part('templates/image-slider-item', 'image-slider', '', $params);

        return $html;
    }

}