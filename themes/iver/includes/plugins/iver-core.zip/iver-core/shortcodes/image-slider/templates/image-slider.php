<div class="qodef-image-slider-holder">
	<div class="qodef-is-inner qodef-owl-slider" <?php echo iver_select_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>