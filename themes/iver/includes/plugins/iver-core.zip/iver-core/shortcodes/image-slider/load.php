<?php

include_once IVER_CORE_SHORTCODES_PATH . '/image-slider/functions.php';
include_once IVER_CORE_SHORTCODES_PATH . '/image-slider/image-slider.php';
include_once IVER_CORE_SHORTCODES_PATH . '/image-slider/image-slider-item.php';