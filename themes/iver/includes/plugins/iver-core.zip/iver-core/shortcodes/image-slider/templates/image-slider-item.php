<div class="qodef-is-item">
    <div class="qodef-is-image">
        <?php echo wp_get_attachment_image($image, 'full'); ?>
    </div>
    <div class="qodef-is-text-holder">
        <div class="qodef-is-text-outer">
            <div class="qodef-is-text-inner">
                <?php if(!empty($subtitle)) { ?>
                    <<?php echo esc_attr($subtitle_tag); ?> class="qodef-is-subtitle">
                        <?php echo wp_kses($subtitle, array('span' => array('class' => true))); ?>
                    </<?php echo esc_attr($subtitle_tag); ?>>
                <?php } ?>
                <?php if(!empty($title)) { ?>
                    <<?php echo esc_attr($title_tag); ?> class="qodef-is-title">
                        <?php echo wp_kses($title, array('span' => array('class' => true))); ?>
                    </<?php echo esc_attr($title_tag); ?>>
                <?php } ?>
                <?php if(!empty($button_text)) { ?>
                    <?php echo iver_select_get_button_html(array(
                        'link' => $link,
                        'text' => $button_text,
                        'type' => 'simple',
                        'size' => 'medium',
                        'target' => '_blank'
                    )); ?>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php if (!empty($link)) { ?>
        <a itemprop="url" class="qodef-is-link" href="<?php echo esc_url($link); ?>" target="_blank"></a>
    <?php } ?>
</div>