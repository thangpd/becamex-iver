<button type="submit" <?php iver_select_inline_style($button_styles); ?> <?php iver_select_class_attribute($button_classes); ?> <?php echo iver_select_get_inline_attrs($button_data); ?> <?php echo iver_select_get_inline_attrs($button_custom_attrs); ?>>
    <span class="qodef-btn-text-wrapper">
        <span class="qodef-btn-text"><?php echo esc_html($text); ?></span>
        <?php echo iver_select_icon_collections()->renderIcon($icon, $icon_pack); ?>
    </span>
    <span class="qodef-btn-bgrnd-wrapper">
        <span class="qodef-btn-bgrnd-idle" <?php iver_select_inline_style($button_bgrnd_styles) ?>></span>
        <span class="qodef-btn-bgrnd-hover" <?php iver_select_inline_style($button_bgrnd_hover_styles) ?>></span>
    </span>
</button>