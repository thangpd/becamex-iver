<?php

if ( ! function_exists( 'iver_core_add_google_map_shortcodes' ) ) {
	function iver_core_add_google_map_shortcodes( $shortcodes_class_name ) {
		$shortcodes = array(
			'IverCore\CPT\Shortcodes\GoogleMap\GoogleMap'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'iver_core_filter_add_vc_shortcode', 'iver_core_add_google_map_shortcodes' );
}

if ( ! function_exists( 'iver_core_set_google_map_icon_class_name_for_vc_shortcodes' ) ) {
	/**
	 * Function that set custom icon class name for google map shortcode to set our icon for Visual Composer shortcodes panel
	 */
	function iver_core_set_google_map_icon_class_name_for_vc_shortcodes( $shortcodes_icon_class_array ) {
		$shortcodes_icon_class_array[] = '.icon-wpb-google-map';
		
		return $shortcodes_icon_class_array;
	}
	
	add_filter( 'iver_core_filter_add_vc_shortcodes_custom_icon_class', 'iver_core_set_google_map_icon_class_name_for_vc_shortcodes' );
}