<?php

if ( ! function_exists( 'iver_core_reviews_map' ) ) {
	function iver_core_reviews_map() {
		
		$reviews_panel = iver_select_add_admin_panel(
			array(
				'title' => esc_html__( 'Reviews', 'iver-core' ),
				'name'  => 'panel_reviews',
				'page'  => '_page_page'
			)
		);
		
		iver_select_add_admin_field(
			array(
				'parent'      => $reviews_panel,
				'type'        => 'text',
				'name'        => 'reviews_section_title',
				'label'       => esc_html__( 'Reviews Section Title', 'iver-core' ),
				'description' => esc_html__( 'Enter title that you want to show before average rating for each room', 'iver-core' ),
			)
		);
		
		iver_select_add_admin_field(
			array(
				'parent'      => $reviews_panel,
				'type'        => 'textarea',
				'name'        => 'reviews_section_subtitle',
				'label'       => esc_html__( 'Reviews Section Subtitle', 'iver-core' ),
				'description' => esc_html__( 'Enter subtitle that you want to show before average rating for each room', 'iver-core' ),
			)
		);
	}
	
	add_action( 'iver_select_additional_page_options_map', 'iver_core_reviews_map', 75 ); //one after elements
}