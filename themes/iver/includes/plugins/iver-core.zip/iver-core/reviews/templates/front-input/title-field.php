<div class="qodef-comment-input-title">
	<input id="title" name="qodef_comment_title" class="qodef-input-field" type="text" placeholder="<?php echo esc_attr__( 'Title of your Review', 'iver' ) ?>"/>
</div>