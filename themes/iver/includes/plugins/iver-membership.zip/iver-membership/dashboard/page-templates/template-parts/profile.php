<div class="qodef-membership-dashboard-page">
	<div class="qodef-membership-dashboard-page-content">
		<div class="qodef-profile-image">
            <?php echo iver_membership_kses_img( $profile_image ); ?>
        </div>
		<p>
			<span><?php esc_html_e( 'First Name', 'iver-membership' ); ?>:</span>
			<?php echo esc_attr($first_name); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Last Name', 'iver-membership' ); ?>:</span>
			<?php echo esc_attr($last_name); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Email', 'iver-membership' ); ?>:</span>
			<?php echo esc_attr($email); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Desription', 'iver-membership' ); ?>:</span>
			<?php echo esc_attr($description); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Website', 'iver-membership' ); ?>:</span>
			<a href="<?php echo esc_url( $website ); ?>" target="_blank"><?php echo esc_attr($website); ?></a>
		</p>
	</div>
</div>
