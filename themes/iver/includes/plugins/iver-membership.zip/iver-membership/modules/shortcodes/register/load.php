<?php

include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/register/functions.php';
include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/register/register.php';