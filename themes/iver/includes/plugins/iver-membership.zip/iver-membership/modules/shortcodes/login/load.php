<?php

include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/login/functions.php';
include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/login/login.php';