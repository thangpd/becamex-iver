<div class="qodef-register-notice">
	<h4 class="qodef-register-notice-title"><?php echo esc_html($message); ?></h4>
	<a href="#" class="qodef-login-action-btn" data-el="#qodef-login-content" data-title="<?php esc_attr_e('LOGIN', 'iver-membership'); ?>"><?php esc_html_e('LOGIN', 'iver-membership'); ?></a>
</div>