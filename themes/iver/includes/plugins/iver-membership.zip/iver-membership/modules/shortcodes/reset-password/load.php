<?php

include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/functions.php';
include_once IVER_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/reset-password.php';