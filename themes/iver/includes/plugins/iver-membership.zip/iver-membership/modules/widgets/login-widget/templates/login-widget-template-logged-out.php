<a href="#" class="qodef-login-opener">
    <span class="qodef-login-text"><?php esc_html_e('Login', 'iver-membership'); ?></span>
</a>